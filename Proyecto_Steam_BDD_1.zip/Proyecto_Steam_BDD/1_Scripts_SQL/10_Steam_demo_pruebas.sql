-- =====================================================================
--  STEAM SISTEMA v2  -  GUION DE DEMOSTRACIÓN
--  Ejecutar DE A UNA sentencia en HeidiSQL (seleccionar la sentencia + Ctrl+F9) o Workbench (Ctrl+Enter).
--  Las que dicen "ERROR ESPERADO" tienen que fallar: eso prueba la regla.
--  Requiere haber ejecutado antes los archivos 01 a 09
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- ---------------------------------------------------------------------
-- A. VER LOS OBJETOS DE LA BASE
-- ---------------------------------------------------------------------
SHOW FULL TABLES WHERE Table_type = 'VIEW';            -- lista de vistas
SHOW CREATE VIEW vista_juegos_precio_final;            -- código de una vista
SHOW TRIGGERS;                                         -- todos los triggers
SELECT TRIGGER_NAME, EVENT_MANIPULATION AS evento, ACTION_TIMING AS momento,
       EVENT_OBJECT_TABLE AS tabla
FROM information_schema.TRIGGERS
WHERE TRIGGER_SCHEMA = 'steam_sistema' ORDER BY tabla;
SELECT ROUTINE_NAME, ROUTINE_TYPE
FROM information_schema.ROUTINES
WHERE ROUTINE_SCHEMA = 'steam_sistema' ORDER BY ROUTINE_TYPE, ROUTINE_NAME;
SHOW CREATE TRIGGER trg_reembolso_validar;

-- Cantidad de filas por tabla (muestra la carga masiva)
SELECT 'Usuarios' AS tabla, COUNT(*) AS filas FROM Usuarios
UNION ALL SELECT 'Compras', COUNT(*) FROM Compras
UNION ALL SELECT 'Detalle_Compra', COUNT(*) FROM Detalle_Compra
UNION ALL SELECT 'Biblioteca', COUNT(*) FROM Biblioteca
UNION ALL SELECT 'Resenas', COUNT(*) FROM Resenas
UNION ALL SELECT 'Movimientos_Billetera', COUNT(*) FROM Movimientos_Billetera
UNION ALL SELECT 'Publicaciones_Mercado', COUNT(*) FROM Publicaciones_Mercado;

-- ---------------------------------------------------------------------
-- B. VISTAS (se consultan como si fueran tablas)
-- ---------------------------------------------------------------------
SELECT * FROM vista_juegos_completa;
SELECT * FROM vista_promos_activas;
SELECT * FROM vista_juegos_precio_final WHERE porcentaje_descuento > 0;
SELECT * FROM vista_compras_detalles WHERE id_usuario = 1;
SELECT * FROM vista_ventas_desarrolladora ORDER BY ingresos_brutos DESC;
SELECT * FROM vista_reembolsos_detalle;
SELECT * FROM vista_billetera WHERE id_usuario <= 40;
SELECT * FROM vista_mercado_activo;
SELECT * FROM vista_valoracion_juegos ORDER BY total_resenas DESC;
SELECT * FROM vista_deseados_en_oferta;

-- ---------------------------------------------------------------------
-- C. TRIGGERS, UNO POR UNO
-- ---------------------------------------------------------------------

-- C1. trg_fechas_promocion: fecha_fin anterior a fecha_inicio se corrige sola
INSERT INTO Promociones (nombre, fecha_inicio, fecha_fin, porcentaje_descuento)
VALUES ('Prueba trigger fechas', CURDATE(), CURDATE() - INTERVAL 10 DAY, 10);
SELECT * FROM Promociones ORDER BY id_promocion DESC LIMIT 1;   -- fecha_fin = fecha_inicio

-- C2. trg_auditoria_precio: cada cambio de precio queda registrado
UPDATE Juegos SET precio_base = 44.99 WHERE id_juego = 2;
SELECT * FROM Auditoria_Precios;

-- C3/C4. Comprar: el trigger pone el juego en la biblioteca y lo saca de deseados.
--        Elegimos un juego que Mauricio (id 1) todavía no tiene.
SET @juego = (SELECT id_juego FROM Juegos
              WHERE precio_base > 0 AND fecha_lanzamiento <= CURDATE()
                AND id_juego NOT IN (SELECT id_juego FROM Biblioteca WHERE id_usuario = 1)
              ORDER BY fn_descuento_en_fecha(id_juego, CURDATE()) DESC, id_juego LIMIT 1);
SELECT @juego, nombre_juego, precio_base, fn_precio_actual(@juego) AS precio_hoy
FROM Juegos WHERE id_juego = @juego;

CALL sp_recargar_billetera(1, 100.00);      -- trg_movimiento_saldo suma al saldo
CALL sp_comprar_juego(1, @juego, 1);        -- 1 = Billetera Steam
SELECT * FROM vista_biblioteca WHERE id_usuario = 1;
SELECT * FROM vista_billetera WHERE id_usuario = 1;

-- C3. ERROR ESPERADO: comprar dos veces el mismo juego
CALL sp_comprar_juego(1, @juego, 2);

-- C5. ERROR ESPERADO: saldo insuficiente (usuario recién creado, saldo 0)
INSERT INTO Usuarios (nombre_cuenta, nombre, email) VALUES ('sin_saldo', 'Sin Saldo', 'sinsaldo@correo.com');
SET @pobre = LAST_INSERT_ID();
CALL sp_comprar_juego(@pobre, 10, 1);
SELECT COUNT(*) AS compras_del_usuario FROM Compras WHERE id_usuario = @pobre;  -- 0: hubo ROLLBACK

-- C5 bis. ERROR ESPERADO: el CHECK de saldo también frena un movimiento directo
INSERT INTO Movimientos_Billetera (id_usuario, tipo, monto) VALUES (@pobre, 'compra_tienda', -50);

-- C6/C7. ERROR ESPERADO: los movimientos no se modifican ni se borran
UPDATE Movimientos_Billetera SET monto = 1000 WHERE id_movimiento = 1;
DELETE FROM Movimientos_Billetera WHERE id_movimiento = 1;

-- C9/C10. Reembolso automático: se compró recién y tiene 0 horas -> 'aprobado'
SET @detalle = (SELECT MAX(d.id_detalle) FROM Detalle_Compra d JOIN Compras c USING (id_compra)
                WHERE c.id_usuario = 1 AND d.id_juego = @juego);
CALL sp_solicitar_reembolso(@detalle, 'No me convenció', 'billetera');
SELECT * FROM vista_biblioteca WHERE id_usuario = 1 AND nombre_juego =
       (SELECT nombre_juego FROM Juegos WHERE id_juego = @juego);   -- 0 filas: perdió la licencia
SELECT * FROM vista_billetera WHERE id_usuario = 1;                  -- volvió la plata

-- C9. Reembolso fuera de regla (más de 14 días o más de 2 h) -> 'en_revision'
SET @viejo = (SELECT d.id_detalle FROM Detalle_Compra d
              JOIN Compras c USING (id_compra)
              JOIN Biblioteca b ON b.id_usuario = c.id_usuario AND b.id_juego = d.id_juego
              LEFT JOIN Reembolsos r ON r.id_detalle = d.id_detalle
              WHERE r.id_reembolso IS NULL AND d.precio_pagado > 0
                AND c.fecha_compra < NOW() - INTERVAL 30 DAY AND b.horas_jugadas > 2
              ORDER BY d.id_detalle LIMIT 1);
CALL sp_solicitar_reembolso(@viejo, 'Lo jugué y no me gustó', 'medio_original');

-- C12. Un admin lo aprueba: recién ahí se aplica
UPDATE Reembolsos SET estado = 'aprobado' WHERE id_detalle = @viejo;
SELECT * FROM vista_reembolsos_detalle ORDER BY id_reembolso DESC LIMIT 2;

-- C11. ERROR ESPERADO: un reembolso resuelto no puede cambiar
UPDATE Reembolsos SET estado = 'rechazado' WHERE id_detalle = @viejo;

-- C8. ERROR ESPERADO: reseñar un juego que no se tiene
INSERT INTO Resenas (id_usuario, id_juego, recomendado, texto)
VALUES (@pobre, 1, TRUE, 'Nunca lo jugué pero está bueno');

-- C13. Mercado: publicar un ítem propio -> el trigger calcula las comisiones
SET @inv = (SELECT inv.id_inventario FROM Inventario inv
            JOIN Items it ON it.id_item = inv.id_item
            LEFT JOIN Publicaciones_Mercado pm ON pm.id_inventario = inv.id_inventario AND pm.estado = 'activa'
            WHERE it.comerciable AND pm.id_publicacion IS NULL
            ORDER BY inv.id_inventario LIMIT 1);
SET @vendedor = (SELECT id_usuario FROM Inventario WHERE id_inventario = @inv);
CALL sp_publicar_item(@vendedor, @inv, 2.00);   -- comprador paga 2.30 (2.00 + 5 % + 10 %)

-- C13. ERROR ESPERADO: publicar el mismo ítem otra vez
CALL sp_publicar_item(@vendedor, @inv, 3.00);
-- C13. ERROR ESPERADO: publicar un ítem que no es tuyo
CALL sp_publicar_item(@pobre, @inv, 1.00);
-- C13. ERROR ESPERADO: ítem no comerciable
SET @nc = (SELECT inv.id_inventario FROM Inventario inv JOIN Items it USING (id_item)
           WHERE NOT it.comerciable LIMIT 1);
CALL sp_publicar_item((SELECT id_usuario FROM Inventario WHERE id_inventario = @nc), @nc, 5.00);

-- Comprar ese ítem: dinero y propiedad se mueven en una sola transacción
SET @pub = (SELECT MAX(id_publicacion) FROM Publicaciones_Mercado WHERE id_inventario = @inv);
SET @comprador = IF(@vendedor = 1, 2, 1);
CALL sp_recargar_billetera(@comprador, 10.00);
CALL sp_comprar_item_mercado(@pub, @comprador);
SELECT * FROM vista_ventas_mercado WHERE id_publicacion = @pub;
SELECT * FROM vista_billetera WHERE id_usuario IN (@vendedor, @comprador);

-- ERROR ESPERADO: ya se vendió
CALL sp_comprar_item_mercado(@pub, @comprador);

-- ---------------------------------------------------------------------
-- D. INTEGRIDAD REFERENCIAL: RESTRICT, CASCADE, SET NULL
-- ---------------------------------------------------------------------
-- ERROR ESPERADO (RESTRICT): no se borra un usuario con compras
DELETE FROM Usuarios WHERE id_usuario = 1;

-- SET NULL y CASCADE dentro de una transacción que después se deshace
START TRANSACTION;
  DELETE FROM Desarrolladoras WHERE id_desarrolladora = 9;            -- SET NULL
  SELECT id_juego, nombre_juego, id_desarrolladora FROM Juegos WHERE id_juego IN (13, 24, 28);
  DELETE FROM Promociones WHERE id_promocion = 2;                     -- CASCADE
  SELECT COUNT(*) AS filas_promo_2 FROM Juego_Promocion WHERE id_promocion = 2;
ROLLBACK;
SELECT id_juego, id_desarrolladora FROM Juegos WHERE id_juego IN (13, 24, 28);  -- volvió todo

-- ---------------------------------------------------------------------
-- E. ÍNDICES Y OPTIMIZADOR (EXPLAIN)
-- ---------------------------------------------------------------------
EXPLAIN SELECT * FROM Compras WHERE fecha_compra >= CURDATE() - INTERVAL 7 DAY;
-- Mismo filtro obligando a NO usar el índice: compará "type" y "rows"
EXPLAIN SELECT * FROM Compras IGNORE INDEX (idx_compras_fecha)
WHERE fecha_compra >= CURDATE() - INTERVAL 7 DAY;
EXPLAIN SELECT * FROM Usuarios WHERE pais = 'Argentina';

-- ---------------------------------------------------------------------
-- F. CARGA MASIVA (se puede repetir)
-- ---------------------------------------------------------------------
CALL sp_generar_datos_masivos(1000, 10000);

-- ---------------------------------------------------------------------
-- G. ROLES Y PRIVILEGIOS
-- ---------------------------------------------------------------------
SHOW GRANTS FOR 'steam_analista';
SHOW GRANTS FOR 'steam_tienda';
SHOW GRANTS FOR 'analista_demo'@'localhost' USING 'steam_analista';
-- Para probarlo: abrir una conexión nueva en Workbench con
-- usuario analista_demo / contraseña Analista#2026 y ejecutar:
--   SELECT * FROM steam_sistema.vista_valoracion_juegos;   -- funciona
--   SELECT * FROM steam_sistema.Usuarios;                  -- ERROR: sin permiso

-- ---------------------------------------------------------------------
-- H. REGLAS AGREGADAS DESPUÉS DE LA REVISIÓN
-- ---------------------------------------------------------------------
-- H1. Un reembolso pendiente no puede aprobarse por más de lo pagado
SET @det2 = (SELECT d.id_detalle FROM Detalle_Compra d
             JOIN Compras c USING (id_compra)
             JOIN Biblioteca b ON b.id_usuario = c.id_usuario AND b.id_juego = d.id_juego
             LEFT JOIN Reembolsos r ON r.id_detalle = d.id_detalle
             WHERE r.id_reembolso IS NULL AND d.precio_pagado > 0
               AND c.fecha_compra < NOW() - INTERVAL 30 DAY AND b.horas_jugadas > 2
             ORDER BY d.id_detalle LIMIT 1);
CALL sp_solicitar_reembolso(@det2, 'Prueba de reembolso parcial', 'medio_original');  -- queda en_revision
-- ERROR ESPERADO: monto mayor a lo pagado
UPDATE Reembolsos SET monto_devuelto = monto_devuelto + 100, estado = 'aprobado' WHERE id_detalle = @det2;
-- ERROR ESPERADO: no se puede cambiar la compra del reembolso
UPDATE Reembolsos SET id_detalle = @det2 + 1 WHERE id_detalle = @det2;
-- Reembolso parcial válido: se devuelve la mitad
UPDATE Reembolsos SET monto_devuelto = ROUND(monto_devuelto / 2, 2), estado = 'aprobado' WHERE id_detalle = @det2;
SELECT * FROM vista_reembolsos_detalle WHERE nombre_juego IS NOT NULL ORDER BY id_reembolso DESC LIMIT 1;

-- H2. ERROR ESPERADO: la solicitud no puede ser anterior a la compra
SET @det3 = (SELECT d.id_detalle FROM Detalle_Compra d LEFT JOIN Reembolsos r USING (id_detalle)
             WHERE r.id_reembolso IS NULL AND d.precio_pagado > 0 ORDER BY d.id_detalle DESC LIMIT 1);
INSERT INTO Reembolsos (id_detalle, motivo, fecha_solicitud)
SELECT @det3, 'Fecha inválida', c.fecha_compra - INTERVAL 1 DAY
FROM Detalle_Compra d JOIN Compras c USING (id_compra) WHERE d.id_detalle = @det3;

-- H3. ERROR ESPERADO: una compra registrada no se borra ni se modifica
DELETE FROM Detalle_Compra WHERE id_detalle = @det3;
UPDATE Detalle_Compra SET precio_pagado = 0 WHERE id_detalle = @det3;

-- H4. ERROR ESPERADO (UNIQUE): una copia no puede tener dos publicaciones activas
SET @p4   = (SELECT id_publicacion FROM Publicaciones_Mercado WHERE estado = 'activa' ORDER BY id_publicacion LIMIT 1);
SET @inv4 = (SELECT id_inventario FROM Publicaciones_Mercado WHERE id_publicacion = @p4);
SET @v4   = (SELECT id_usuario FROM Inventario WHERE id_inventario = @inv4);
UPDATE Publicaciones_Mercado SET estado = 'cancelada' WHERE id_publicacion = @p4;
CALL sp_publicar_item(@v4, @inv4, 3.00);                                   -- nueva publicación activa
UPDATE Publicaciones_Mercado SET estado = 'activa' WHERE id_publicacion = @p4;  -- la vieja no puede volver

