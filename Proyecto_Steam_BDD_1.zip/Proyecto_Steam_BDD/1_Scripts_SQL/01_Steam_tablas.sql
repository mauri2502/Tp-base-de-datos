-- =====================================================================
--  STEAM SISTEMA v2  -  01. CREACIÓN DE LA BASE, TABLAS E ÍNDICES
--  Tienda oficial + Mercado de la Comunidad
--  MySQL 8.0.16 o superior (usa CHECK, columnas generadas y roles)
--  Orden de ejecución: 01 al 09 (ver LEEME.txt). Este archivo BORRA y recrea la base.
-- =====================================================================
SET NAMES utf8mb4;
DROP DATABASE IF EXISTS steam_sistema;
CREATE DATABASE steam_sistema CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE steam_sistema;

-- =====================================================================
-- TABLAS (DDL)
--    Reglas de FK usadas a propósito:
--      RESTRICT  -> registros económicos (compras, movimientos, mercado):
--                   no se pueden perder por borrar un usuario o un juego.
--      CASCADE   -> datos que solo existen por su "padre" (biblioteca,
--                   reseñas, lista de deseados, géneros y promos de un juego).
--      SET NULL  -> referencias opcionales (desarrolladora, promoción).
-- =====================================================================

-- ---------- Catálogo ----------
CREATE TABLE Desarrolladoras (
  id_desarrolladora INT PRIMARY KEY AUTO_INCREMENT,
  nombre            VARCHAR(100) NOT NULL UNIQUE,
  region            VARCHAR(50)
);

CREATE TABLE Generos (
  id_genero INT PRIMARY KEY AUTO_INCREMENT,
  nombre    VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE Juegos (
  id_juego          INT PRIMARY KEY AUTO_INCREMENT,
  nombre_juego      VARCHAR(150) NOT NULL UNIQUE,
  precio_base       DECIMAL(10,2) NOT NULL,
  fecha_lanzamiento DATE,
  tasa_mercado      DECIMAL(4,2) NOT NULL DEFAULT 10.00, -- % que cobra la editora en el Mercado
  id_desarrolladora INT,
  CONSTRAINT chk_juegos_precio CHECK (precio_base >= 0),
  CONSTRAINT chk_juegos_tasa   CHECK (tasa_mercado BETWEEN 0 AND 30),
  CONSTRAINT fk_juegos_desarrolladora FOREIGN KEY (id_desarrolladora)
    REFERENCES Desarrolladoras(id_desarrolladora) ON DELETE SET NULL
);

-- N:M -> un juego tiene varios géneros (atributo multivaluado -> tabla aparte)
CREATE TABLE Juego_Genero (
  id_juego  INT NOT NULL,
  id_genero INT NOT NULL,
  PRIMARY KEY (id_juego, id_genero),
  FOREIGN KEY (id_juego)  REFERENCES Juegos(id_juego)   ON DELETE CASCADE,
  FOREIGN KEY (id_genero) REFERENCES Generos(id_genero) ON DELETE CASCADE
);

-- ---------- Usuarios ----------
-- Todos los usuarios compran en la tienda y pueden vender ítems en el Mercado,
-- por eso ya no existe el rol "vendedor".
CREATE TABLE Usuarios (
  id_usuario      INT PRIMARY KEY AUTO_INCREMENT,
  nombre_cuenta   VARCHAR(50)  NOT NULL UNIQUE,   -- clave alterna
  nombre          VARCHAR(100) NOT NULL,          -- nombre visible (puede repetirse)
  email           VARCHAR(150) NOT NULL UNIQUE,   -- clave alterna
  pais            VARCHAR(50),
  rol             ENUM('jugador','admin') NOT NULL DEFAULT 'jugador',
  fecha_registro  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  saldo_billetera DECIMAL(10,2) NOT NULL DEFAULT 0, -- desnormalizado: lo mantiene un trigger
  CONSTRAINT chk_usuarios_saldo CHECK (saldo_billetera >= 0)
);

-- ---------- Promociones ----------
-- id_desarrolladora NULL = rebaja de la plataforma (ej. Rebajas de Otoño).
CREATE TABLE Promociones (
  id_promocion         INT PRIMARY KEY AUTO_INCREMENT,
  nombre               VARCHAR(100) NOT NULL,
  fecha_inicio         DATE NOT NULL,
  fecha_fin            DATE NOT NULL,
  porcentaje_descuento DECIMAL(5,2) NOT NULL,
  id_desarrolladora    INT,
  CONSTRAINT chk_promociones_fechas    CHECK (fecha_fin >= fecha_inicio),
  CONSTRAINT chk_promociones_descuento CHECK (porcentaje_descuento BETWEEN 0 AND 100),
  FOREIGN KEY (id_desarrolladora) REFERENCES Desarrolladoras(id_desarrolladora)
    ON DELETE SET NULL
);

CREATE TABLE Juego_Promocion (
  id_promocion INT NOT NULL,
  id_juego     INT NOT NULL,
  PRIMARY KEY (id_promocion, id_juego),
  FOREIGN KEY (id_promocion) REFERENCES Promociones(id_promocion) ON DELETE CASCADE,
  FOREIGN KEY (id_juego)     REFERENCES Juegos(id_juego)          ON DELETE CASCADE
);

-- ---------- Tienda: compras ----------
CREATE TABLE Metodos_Pago (
  id_metodo_pago INT PRIMARY KEY AUTO_INCREMENT,
  nombre         VARCHAR(50) NOT NULL UNIQUE,
  es_billetera   BOOLEAN NOT NULL DEFAULT FALSE
);

-- Cabecera de la compra (un "carrito" pagado). El total NO se guarda:
-- se calcula sumando el detalle (evita redundancia).
CREATE TABLE Compras (
  id_compra      INT PRIMARY KEY AUTO_INCREMENT,
  id_usuario     INT NOT NULL,
  id_metodo_pago INT NOT NULL,
  fecha_compra   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_usuario)     REFERENCES Usuarios(id_usuario)         ON DELETE RESTRICT,
  FOREIGN KEY (id_metodo_pago) REFERENCES Metodos_Pago(id_metodo_pago) ON DELETE RESTRICT
);

-- Cada juego de una compra. precio_pagado es un dato HISTÓRICO real:
-- no cambia aunque después cambie el precio del juego.
CREATE TABLE Detalle_Compra (
  id_detalle    INT PRIMARY KEY AUTO_INCREMENT,
  id_compra     INT NOT NULL,
  id_juego      INT NOT NULL,
  precio_pagado DECIMAL(10,2) NOT NULL,
  id_promocion  INT NULL,  -- promoción aplicada (si hubo)
  CONSTRAINT uq_detalle_compra_juego UNIQUE (id_compra, id_juego),
  CONSTRAINT chk_detalle_precio CHECK (precio_pagado >= 0),
  FOREIGN KEY (id_compra)    REFERENCES Compras(id_compra)         ON DELETE RESTRICT, -- una compra no se borra: se anula con un reembolso
  FOREIGN KEY (id_juego)     REFERENCES Juegos(id_juego)           ON DELETE RESTRICT,
  FOREIGN KEY (id_promocion) REFERENCES Promociones(id_promocion)  ON DELETE SET NULL
);

-- Licencias que posee cada usuario (reemplaza el UNIQUE(usuario,juego) de Compras).
CREATE TABLE Biblioteca (
  id_usuario        INT NOT NULL,
  id_juego          INT NOT NULL,
  fecha_adquisicion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  horas_jugadas     DECIMAL(7,1) NOT NULL DEFAULT 0,
  origen            ENUM('compra','regalo','codigo') NOT NULL DEFAULT 'compra',
  PRIMARY KEY (id_usuario, id_juego),
  CONSTRAINT chk_biblioteca_horas CHECK (horas_jugadas >= 0),
  FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE CASCADE,
  FOREIGN KEY (id_juego)   REFERENCES Juegos(id_juego)     ON DELETE CASCADE
);

-- Un reembolso por línea de compra (se reembolsa un juego, no toda la compra).
CREATE TABLE Reembolsos (
  id_reembolso    INT PRIMARY KEY AUTO_INCREMENT,
  id_detalle      INT NOT NULL UNIQUE,
  motivo          VARCHAR(200),
  fecha_solicitud DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  estado          ENUM('aprobado','en_revision','rechazado') NOT NULL DEFAULT 'en_revision',
  monto_devuelto  DECIMAL(10,2) NULL,  -- si no se informa, el trigger pone lo pagado
  destino         ENUM('billetera','medio_original') NOT NULL DEFAULT 'medio_original',
  CONSTRAINT chk_reembolsos_monto CHECK (monto_devuelto >= 0),
  FOREIGN KEY (id_detalle) REFERENCES Detalle_Compra(id_detalle) ON DELETE RESTRICT
);

CREATE TABLE Lista_Deseados (
  id_usuario     INT NOT NULL,
  id_juego       INT NOT NULL,
  fecha_agregado DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_usuario, id_juego),
  FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE CASCADE,
  FOREIGN KEY (id_juego)   REFERENCES Juegos(id_juego)     ON DELETE CASCADE
);

CREATE TABLE Resenas (
  id_resena   INT PRIMARY KEY AUTO_INCREMENT,
  id_usuario  INT NOT NULL,
  id_juego    INT NOT NULL,
  recomendado BOOLEAN NOT NULL,
  texto       VARCHAR(500),
  fecha       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_resena_usuario_juego UNIQUE (id_usuario, id_juego),
  FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE CASCADE,
  FOREIGN KEY (id_juego)   REFERENCES Juegos(id_juego)     ON DELETE CASCADE
);

-- ---------- Billetera Steam ----------
-- Libro de movimientos: positivo = entra dinero, negativo = sale.
CREATE TABLE Movimientos_Billetera (
  id_movimiento INT PRIMARY KEY AUTO_INCREMENT,
  id_usuario    INT NOT NULL,
  tipo          ENUM('recarga','compra_tienda','reembolso','venta_mercado','compra_mercado') NOT NULL,
  monto         DECIMAL(10,2) NOT NULL,
  fecha         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  referencia    VARCHAR(100),
  CONSTRAINT chk_movimientos_monto CHECK (monto <> 0),
  FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE RESTRICT
);

-- ---------- Mercado de la Comunidad ----------
CREATE TABLE Items (
  id_item     INT PRIMARY KEY AUTO_INCREMENT,
  id_juego    INT NOT NULL,
  nombre      VARCHAR(100) NOT NULL,
  tipo        ENUM('cromo','skin','fondo','emoticono','caja') NOT NULL,
  rareza      ENUM('comun','poco_comun','raro','legendario') NOT NULL DEFAULT 'comun',
  comerciable BOOLEAN NOT NULL DEFAULT TRUE,
  CONSTRAINT uq_items_juego_nombre UNIQUE (id_juego, nombre),
  FOREIGN KEY (id_juego) REFERENCES Juegos(id_juego) ON DELETE CASCADE
);

-- Cada fila es UNA copia concreta de un ítem en poder de un usuario.
CREATE TABLE Inventario (
  id_inventario   INT PRIMARY KEY AUTO_INCREMENT,
  id_usuario      INT NOT NULL,
  id_item         INT NOT NULL,
  fecha_obtencion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE RESTRICT,
  FOREIGN KEY (id_item)    REFERENCES Items(id_item)       ON DELETE RESTRICT
);

-- Reemplaza a la vieja tabla Ventas: lo que venden los usuarios son ÍTEMS.
-- Las comisiones las calcula un trigger; precio_comprador es columna generada.
CREATE TABLE Publicaciones_Mercado (
  id_publicacion    INT PRIMARY KEY AUTO_INCREMENT,
  id_inventario     INT NOT NULL,
  id_vendedor       INT NOT NULL,
  precio_vendedor   DECIMAL(10,2) NOT NULL,           -- lo que recibe el vendedor
  comision_steam    DECIMAL(10,2) NOT NULL DEFAULT 0, -- 5 % (mínimo 0,01)
  comision_juego    DECIMAL(10,2) NOT NULL DEFAULT 0, -- tasa_mercado del juego
  precio_comprador  DECIMAL(10,2) AS (precio_vendedor + comision_steam + comision_juego) STORED,
  estado            ENUM('activa','vendida','cancelada') NOT NULL DEFAULT 'activa',
  fecha_publicacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  id_comprador      INT NULL,
  fecha_venta       DATETIME NULL,
  -- Vale id_inventario solo mientras la publicación está activa (si no, NULL).
  -- Con el UNIQUE, una copia no puede tener dos publicaciones activas, ni
  -- siquiera con dos INSERT simultáneos (UNIQUE admite varios NULL).
  inventario_activo INT AS (IF(estado = 'activa', id_inventario, NULL)) STORED,
  CONSTRAINT uq_pub_una_activa UNIQUE (inventario_activo),
  CONSTRAINT chk_pub_precio CHECK (precio_vendedor > 0),
  CONSTRAINT chk_pub_comprador CHECK (id_comprador IS NULL OR id_comprador <> id_vendedor),
  CONSTRAINT chk_pub_vendida CHECK (estado <> 'vendida' OR (id_comprador IS NOT NULL AND fecha_venta IS NOT NULL)),
  FOREIGN KEY (id_inventario) REFERENCES Inventario(id_inventario) ON DELETE RESTRICT,
  FOREIGN KEY (id_vendedor)   REFERENCES Usuarios(id_usuario)      ON DELETE RESTRICT,
  FOREIGN KEY (id_comprador)  REFERENCES Usuarios(id_usuario)      ON DELETE RESTRICT
);

-- ---------- Auditoría ----------
CREATE TABLE Auditoria_Precios (
  id_auditoria    INT PRIMARY KEY AUTO_INCREMENT,
  id_juego        INT NOT NULL,
  precio_anterior DECIMAL(10,2) NOT NULL,
  precio_nuevo    DECIMAL(10,2) NOT NULL,
  fecha           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  usuario_bd      VARCHAR(100),
  FOREIGN KEY (id_juego) REFERENCES Juegos(id_juego) ON DELETE CASCADE
);

-- =====================================================================
-- ÍNDICES ADICIONALES
--    (InnoDB ya indexa PK, UNIQUE y FK; estos aceleran filtros frecuentes)
-- =====================================================================
CREATE INDEX idx_compras_fecha        ON Compras(fecha_compra);
CREATE INDEX idx_movimientos_usr_fecha ON Movimientos_Billetera(id_usuario, fecha);
CREATE INDEX idx_publicaciones_estado ON Publicaciones_Mercado(estado, fecha_publicacion);
CREATE INDEX idx_promociones_fechas   ON Promociones(fecha_inicio, fecha_fin);
CREATE INDEX idx_usuarios_pais        ON Usuarios(pais);
