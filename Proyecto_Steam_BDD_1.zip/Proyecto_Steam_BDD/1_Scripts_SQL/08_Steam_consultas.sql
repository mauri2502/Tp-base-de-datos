-- =====================================================================
--  STEAM SISTEMA v2  -  08. CONSULTAS
--  15 consultas de negocio sobre tablas y vistas.
--  Probado en MySQL 8 (HeidiSQL o Workbench). Ejecutar el archivo completo (F9 en HeidiSQL).
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- =====================================================================
-- CONSULTAS
-- Criterio para reembolsos (el mismo en vistas y consultas): se admiten
-- devoluciones parciales. Ingresos = lo cobrado menos lo devuelto en reembolsos
-- aprobados. Unidades = licencias vigentes (un reembolso aprobado quita la licencia).
-- =====================================================================

-- 1. Total gastado por usuario (neto de reembolsos aprobados)
SELECT u.id_usuario, u.nombre,
       SUM(d.precio_pagado - COALESCE(r.monto_devuelto, 0)) AS total_gastado
FROM Usuarios u
JOIN Compras c        ON c.id_usuario = u.id_usuario
JOIN Detalle_Compra d ON d.id_compra = c.id_compra
LEFT JOIN Reembolsos r ON r.id_detalle = d.id_detalle AND r.estado = 'aprobado'
GROUP BY u.id_usuario, u.nombre
ORDER BY total_gastado DESC;

-- 2. Juego más vendido (RANK muestra empates, LIMIT 1 los escondería)
SELECT * FROM (
  SELECT j.id_juego, j.nombre_juego, COUNT(*) AS veces_comprado,
         RANK() OVER (ORDER BY COUNT(*) DESC) AS puesto
  FROM Detalle_Compra d
  JOIN Juegos j ON j.id_juego = d.id_juego
  LEFT JOIN Reembolsos r ON r.id_detalle = d.id_detalle AND r.estado = 'aprobado'
  WHERE r.id_reembolso IS NULL
  GROUP BY j.id_juego, j.nombre_juego
) t WHERE puesto = 1;

-- 3. Historial de compras
SELECT comprador, nombre_juego, precio_pagado, promocion, metodo_pago, fecha_compra, reembolso
FROM vista_compras_detalles
ORDER BY fecha_compra DESC;

-- 4. Juegos con promoción activa
SELECT * FROM vista_promos_activas ORDER BY porcentaje_descuento DESC;

-- 5. Usuarios que solicitaron reembolso, con el resultado
SELECT usuario, nombre_juego, dias_desde_compra, monto_devuelto, estado
FROM vista_reembolsos_detalle ORDER BY fecha_solicitud DESC;

-- 6. Top 3 usuarios que más gastaron (neto de reembolsos aprobados)
SELECT u.id_usuario, u.nombre,
       SUM(d.precio_pagado - COALESCE(r.monto_devuelto, 0)) AS total_gastado
FROM Usuarios u
JOIN Compras c        ON c.id_usuario = u.id_usuario
JOIN Detalle_Compra d ON d.id_compra = c.id_compra
LEFT JOIN Reembolsos r ON r.id_detalle = d.id_detalle AND r.estado = 'aprobado'
GROUP BY u.id_usuario, u.nombre
ORDER BY total_gastado DESC LIMIT 3;

-- 7. Ventas e ingresos por desarrolladora
SELECT * FROM vista_ventas_desarrolladora ORDER BY ingresos_brutos DESC;

-- 8. Juegos que nunca se vendieron (LEFT JOIN + IS NULL)
SELECT j.id_juego, j.nombre_juego, j.fecha_lanzamiento
FROM Juegos j
LEFT JOIN Detalle_Compra d ON d.id_juego = j.id_juego
WHERE d.id_detalle IS NULL;

-- 9. Facturación por mes del último año (neta de reembolsos aprobados)
SELECT DATE_FORMAT(c.fecha_compra, '%Y-%m') AS mes,
       SUM(r.id_reembolso IS NULL) AS juegos_vendidos,
       SUM(d.precio_pagado - COALESCE(r.monto_devuelto, 0)) AS facturacion
FROM Compras c
JOIN Detalle_Compra d ON d.id_compra = c.id_compra
LEFT JOIN Reembolsos r ON r.id_detalle = d.id_detalle AND r.estado = 'aprobado'
WHERE c.fecha_compra >= CURDATE() - INTERVAL 12 MONTH
GROUP BY mes ORDER BY mes;

-- 10. Ventas por género, netas de reembolsos (un juego cuenta en cada uno de sus géneros)
SELECT g.nombre AS genero,
       SUM(r.id_reembolso IS NULL) AS unidades,
       SUM(d.precio_pagado - COALESCE(r.monto_devuelto, 0)) AS facturacion
FROM Detalle_Compra d
JOIN Juego_Genero jg ON jg.id_juego = d.id_juego
JOIN Generos g       ON g.id_genero = jg.id_genero
LEFT JOIN Reembolsos r ON r.id_detalle = d.id_detalle AND r.estado = 'aprobado'
GROUP BY g.nombre ORDER BY facturacion DESC;

-- 11. Cuánto ganó Steam: 30 % de la tienda + 5 % de cada venta del Mercado
SELECT (SELECT ROUND(SUM(comision_steam), 2) FROM vista_ventas_desarrolladora) AS comision_tienda,
       (SELECT SUM(comision_steam) FROM Publicaciones_Mercado WHERE estado = 'vendida') AS comision_mercado;

-- 12. Ítems más caros vendidos en el Mercado
SELECT item, rareza, nombre_juego, vendedor, comprador, pago_comprador, fecha_venta
FROM vista_ventas_mercado ORDER BY pago_comprador DESC LIMIT 10;

-- 13. Promociones según su situación (dato real vs. planificado)
SELECT nombre, fecha_inicio, fecha_fin, porcentaje_descuento,
       CASE WHEN CURDATE() < fecha_inicio THEN 'Planificada'
            WHEN CURDATE() > fecha_fin    THEN 'Finalizada'
            ELSE 'Activa' END AS situacion
FROM Promociones ORDER BY fecha_inicio;

-- 14. Usuarios que gastaron más que el promedio (subconsulta)
SELECT u.nombre, SUM(d.precio_pagado) AS gastado
FROM Usuarios u
JOIN Compras c        ON c.id_usuario = u.id_usuario
JOIN Detalle_Compra d ON d.id_compra = c.id_compra
GROUP BY u.id_usuario, u.nombre
HAVING gastado > (SELECT AVG(t.total)
                  FROM (SELECT SUM(d2.precio_pagado) AS total
                        FROM Compras c2 JOIN Detalle_Compra d2 ON d2.id_compra = c2.id_compra
                        GROUP BY c2.id_usuario) t)
ORDER BY gastado DESC;

-- 15. Control de la billetera (debe dar 0 filas)
SELECT * FROM vista_billetera WHERE control <> 'OK';
