-- =====================================================================
--  STEAM SISTEMA v2  -  03. PROCEDIMIENTOS ALMACENADOS
--  Operaciones de negocio con transacciones (COMMIT / ROLLBACK).
--  Probado en MySQL 8 (HeidiSQL o Workbench). Ejecutar el archivo completo (F9 en HeidiSQL).
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- =====================================================================
-- PROCEDIMIENTOS (transacciones ACID)
-- =====================================================================
DELIMITER //

-- Comprar un juego en la tienda oficial.
DROP PROCEDURE IF EXISTS sp_comprar_juego//
CREATE PROCEDURE sp_comprar_juego(IN p_usuario INT, IN p_juego INT, IN p_metodo INT)
BEGIN
  DECLARE v_precio    DECIMAL(10,2);
  DECLARE v_promo     INT;
  DECLARE v_billetera BOOLEAN;
  DECLARE v_saldo     DECIMAL(10,2);
  DECLARE v_compra    INT;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;   -- devuelve el error original al cliente
  END;

  START TRANSACTION;
    SELECT es_billetera INTO v_billetera FROM Metodos_Pago WHERE id_metodo_pago = p_metodo;
    SET v_precio = fn_precio_actual(p_juego);
    SET v_promo  = fn_promo_en_fecha(p_juego, CURDATE());

    IF v_billetera THEN
      -- FOR UPDATE bloquea la fila: dos compras simultáneas no gastan el mismo saldo
      SELECT saldo_billetera INTO v_saldo FROM Usuarios WHERE id_usuario = p_usuario FOR UPDATE;
      IF v_saldo < v_precio THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Saldo insuficiente en la billetera';
      END IF;
    END IF;

    INSERT INTO Compras (id_usuario, id_metodo_pago) VALUES (p_usuario, p_metodo);
    SET v_compra = LAST_INSERT_ID();
    INSERT INTO Detalle_Compra (id_compra, id_juego, precio_pagado, id_promocion)
    VALUES (v_compra, p_juego, v_precio, v_promo);

    IF v_billetera AND v_precio > 0 THEN
      INSERT INTO Movimientos_Billetera (id_usuario, tipo, monto, referencia)
      VALUES (p_usuario, 'compra_tienda', -v_precio, CONCAT('Compra #', v_compra));
    END IF;
  COMMIT;

  SELECT v_compra AS id_compra, p_juego AS id_juego, v_precio AS precio_pagado,
         v_promo AS id_promocion_aplicada;
END//

-- Solicitar reembolso (las reglas las aplican los triggers).
DROP PROCEDURE IF EXISTS sp_solicitar_reembolso//
CREATE PROCEDURE sp_solicitar_reembolso(IN p_detalle INT, IN p_motivo VARCHAR(200),
                                        IN p_destino VARCHAR(20))
BEGIN
  INSERT INTO Reembolsos (id_detalle, motivo, destino)
  VALUES (p_detalle, p_motivo, p_destino);
  SELECT * FROM Reembolsos WHERE id_reembolso = LAST_INSERT_ID();
END//

-- Recargar la billetera.
DROP PROCEDURE IF EXISTS sp_recargar_billetera//
CREATE PROCEDURE sp_recargar_billetera(IN p_usuario INT, IN p_monto DECIMAL(10,2))
BEGIN
  IF p_monto <= 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El monto de recarga debe ser positivo';
  END IF;
  INSERT INTO Movimientos_Billetera (id_usuario, tipo, monto, referencia)
  VALUES (p_usuario, 'recarga', p_monto, 'Recarga de saldo');
  SELECT id_usuario, nombre, saldo_billetera FROM Usuarios WHERE id_usuario = p_usuario;
END//

-- Publicar un ítem del inventario en el Mercado.
DROP PROCEDURE IF EXISTS sp_publicar_item//
CREATE PROCEDURE sp_publicar_item(IN p_vendedor INT, IN p_inventario INT, IN p_precio DECIMAL(10,2))
BEGIN
  INSERT INTO Publicaciones_Mercado (id_inventario, id_vendedor, precio_vendedor)
  VALUES (p_inventario, p_vendedor, p_precio);
  SELECT * FROM Publicaciones_Mercado WHERE id_publicacion = LAST_INSERT_ID();
END//

-- Comprar un ítem del Mercado: mueve dinero y el ítem en UNA transacción.
DROP PROCEDURE IF EXISTS sp_comprar_item_mercado//
CREATE PROCEDURE sp_comprar_item_mercado(IN p_publicacion INT, IN p_comprador INT)
BEGIN
  DECLARE v_estado     VARCHAR(20) DEFAULT NULL;
  DECLARE v_vendedor   INT;
  DECLARE v_inventario INT;
  DECLARE v_precio_c   DECIMAL(10,2);
  DECLARE v_precio_v   DECIMAL(10,2);
  DECLARE v_saldo      DECIMAL(10,2);
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;

  START TRANSACTION;
    SELECT estado, id_vendedor, id_inventario, precio_comprador, precio_vendedor
      INTO v_estado, v_vendedor, v_inventario, v_precio_c, v_precio_v
    FROM Publicaciones_Mercado WHERE id_publicacion = p_publicacion
    FOR UPDATE;

    IF v_estado IS NULL OR v_estado <> 'activa' THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La publicación no está disponible';
    END IF;
    IF v_vendedor = p_comprador THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No podés comprar tu propia publicación';
    END IF;

    SELECT saldo_billetera INTO v_saldo FROM Usuarios WHERE id_usuario = p_comprador FOR UPDATE;
    IF v_saldo < v_precio_c THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Saldo insuficiente en la billetera';
    END IF;

    INSERT INTO Movimientos_Billetera (id_usuario, tipo, monto, referencia) VALUES
      (p_comprador, 'compra_mercado', -v_precio_c, CONCAT('Publicación #', p_publicacion)),
      (v_vendedor,  'venta_mercado',   v_precio_v, CONCAT('Publicación #', p_publicacion));

    UPDATE Inventario SET id_usuario = p_comprador, fecha_obtencion = NOW()
    WHERE id_inventario = v_inventario;

    UPDATE Publicaciones_Mercado
    SET estado = 'vendida', id_comprador = p_comprador, fecha_venta = NOW()
    WHERE id_publicacion = p_publicacion;
  COMMIT;

  SELECT * FROM Publicaciones_Mercado WHERE id_publicacion = p_publicacion;
END//

-- Genera datos masivos: p_usuarios usuarios nuevos y p_compras compras al azar
-- (fechas del último tiempo, precio según la promo vigente ese día, ~30 % deja reseña).
DROP PROCEDURE IF EXISTS sp_generar_datos_masivos//
CREATE PROCEDURE sp_generar_datos_masivos(IN p_usuarios INT, IN p_compras INT)
BEGIN
  DECLARE i            INT DEFAULT 0;
  DECLARE v_base       INT;
  DECLARE v_max_u      INT;
  DECLARE v_max_j      INT;
  DECLARE v_u          INT;
  DECLARE v_j          INT;
  DECLARE v_metodo     INT;
  DECLARE v_registro   DATETIME;
  DECLARE v_lanz       DATE;
  DECLARE v_desde      DATETIME;
  DECLARE v_fecha      DATETIME;
  DECLARE v_compra     INT;
  DECLARE v_hechas     INT DEFAULT 0;
  DECLARE v_saltadas   INT DEFAULT 0;

  SELECT COALESCE(MAX(id_usuario), 0) INTO v_base FROM Usuarios;

  START TRANSACTION;
  WHILE i < p_usuarios DO
    SET i = i + 1;
    INSERT INTO Usuarios (nombre_cuenta, nombre, email, pais, fecha_registro)
    VALUES (CONCAT('jugador_', v_base + i),
            CONCAT(ELT(1 + FLOOR(RAND() * 10), 'Lucas','Sofía','Mateo','Valentina','Thiago',
                       'Camila','Benjamín','Martina','Joaquín','Lucía'), ' ', v_base + i),
            CONCAT('jugador', v_base + i, '@correo.com'),
            ELT(1 + FLOOR(RAND() * 8), 'Argentina','Chile','Uruguay','México',
                'Colombia','España','Perú','Venezuela'),
            NOW() - INTERVAL FLOOR(RAND() * 900) DAY);
  END WHILE;

  SELECT MAX(id_usuario) INTO v_max_u FROM Usuarios;
  SELECT MAX(id_juego)   INTO v_max_j FROM Juegos;

  SET i = 0;
  WHILE i < p_compras DO
    SET i = i + 1;
    SET v_u = 1 + FLOOR(RAND() * v_max_u);
    SET v_j = 1 + FLOOR(RAND() * v_max_j);

    SET v_registro = NULL;
    SELECT fecha_registro INTO v_registro FROM Usuarios WHERE id_usuario = v_u AND rol = 'jugador';
    SELECT fecha_lanzamiento INTO v_lanz FROM Juegos WHERE id_juego = v_j;

    IF v_registro IS NULL OR v_lanz IS NULL OR v_lanz > CURDATE()
       OR EXISTS (SELECT 1 FROM Compras c JOIN Detalle_Compra d ON d.id_compra = c.id_compra
                  WHERE c.id_usuario = v_u AND d.id_juego = v_j) THEN  -- ya lo compró alguna vez
      SET v_saltadas = v_saltadas + 1;
    ELSE
      SET v_desde = GREATEST(v_registro, TIMESTAMP(v_lanz));
      SET v_fecha = v_desde + INTERVAL FLOOR(RAND() * GREATEST(TIMESTAMPDIFF(MINUTE, v_desde, NOW()), 1)) MINUTE;
      SELECT id_metodo_pago INTO v_metodo FROM Metodos_Pago
      WHERE es_billetera = FALSE ORDER BY RAND() LIMIT 1;

      INSERT INTO Compras (id_usuario, id_metodo_pago, fecha_compra) VALUES (v_u, v_metodo, v_fecha);
      SET v_compra = LAST_INSERT_ID();
      INSERT INTO Detalle_Compra (id_compra, id_juego, precio_pagado, id_promocion)
      VALUES (v_compra, v_j, fn_precio_en_fecha(v_j, DATE(v_fecha)), fn_promo_en_fecha(v_j, DATE(v_fecha)));

      UPDATE Biblioteca SET horas_jugadas = ROUND(RAND() * 150, 1)
      WHERE id_usuario = v_u AND id_juego = v_j;

      IF RAND() < 0.30 THEN
        INSERT INTO Resenas (id_usuario, id_juego, recomendado, texto, fecha)
        VALUES (v_u, v_j, RAND() < 0.78, 'Reseña generada automáticamente',
                LEAST(NOW(), v_fecha + INTERVAL FLOOR(1 + RAND() * 20) DAY));
      END IF;
      SET v_hechas = v_hechas + 1;
    END IF;
  END WHILE;
  COMMIT;

  SELECT p_usuarios AS usuarios_creados, v_hechas AS compras_creadas,
         v_saltadas AS intentos_descartados_por_duplicado;
END//

DELIMITER ;

-- Procedimiento interno que usan los triggers de reembolso (por eso este archivo va antes que 04).
DELIMITER //
DROP PROCEDURE IF EXISTS sp_aplicar_reembolso//
CREATE PROCEDURE sp_aplicar_reembolso(p_detalle INT, p_monto DECIMAL(10,2),
                                      p_destino VARCHAR(20), p_fecha DATETIME)
MODIFIES SQL DATA
BEGIN
  DECLARE v_usuario INT;
  DECLARE v_juego   INT;
  SELECT c.id_usuario, d.id_juego INTO v_usuario, v_juego
  FROM Detalle_Compra d JOIN Compras c ON c.id_compra = d.id_compra
  WHERE d.id_detalle = p_detalle;

  -- Se pierde la licencia
  DELETE FROM Biblioteca WHERE id_usuario = v_usuario AND id_juego = v_juego;
  -- Se devuelve el dinero a la billetera si corresponde
  IF p_destino = 'billetera' AND p_monto > 0 THEN
    INSERT INTO Movimientos_Billetera (id_usuario, tipo, monto, fecha, referencia)
    VALUES (v_usuario, 'reembolso', p_monto, p_fecha, CONCAT('Reembolso detalle #', p_detalle));
  END IF;
END//
DELIMITER ;
