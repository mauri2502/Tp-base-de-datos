-- =====================================================================
--  STEAM SISTEMA v2  -  04. TRIGGERS
--  Reglas de negocio automáticas. Requiere 03_Steam_procedimientos.sql.
--  Probado en MySQL 8 (HeidiSQL o Workbench). Ejecutar el archivo completo (F9 en HeidiSQL).
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- =====================================================================
-- TRIGGERS
-- =====================================================================

-- 4.1 (original) Trigger de UNA sentencia: no necesita DELIMITER ni BEGIN/END.
--     Si fecha_fin < fecha_inicio, la iguala a fecha_inicio.
DROP TRIGGER IF EXISTS trg_fechas_promocion;
CREATE TRIGGER trg_fechas_promocion
BEFORE INSERT ON Promociones
FOR EACH ROW
SET NEW.fecha_fin = IF(NEW.fecha_fin < NEW.fecha_inicio, NEW.fecha_inicio, NEW.fecha_fin);

DELIMITER //

-- 4.2 Auditoría: registra cada cambio de precio_base.
DROP TRIGGER IF EXISTS trg_auditoria_precio//
CREATE TRIGGER trg_auditoria_precio
AFTER UPDATE ON Juegos
FOR EACH ROW
BEGIN
  IF OLD.precio_base <> NEW.precio_base THEN
    INSERT INTO Auditoria_Precios (id_juego, precio_anterior, precio_nuevo, usuario_bd)
    VALUES (NEW.id_juego, OLD.precio_base, NEW.precio_base, CURRENT_USER());
  END IF;
END//

-- 4.3 No se puede comprar un juego que ya está en la biblioteca.
DROP TRIGGER IF EXISTS trg_detalle_validar//
CREATE TRIGGER trg_detalle_validar
BEFORE INSERT ON Detalle_Compra
FOR EACH ROW
BEGIN
  IF EXISTS (SELECT 1
             FROM Compras c
             JOIN Biblioteca b ON b.id_usuario = c.id_usuario
             WHERE c.id_compra = NEW.id_compra AND b.id_juego = NEW.id_juego) THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'El usuario ya tiene este juego en su biblioteca';
  END IF;
END//

-- 4.4 Al comprar, el juego entra automáticamente en la biblioteca
--     y se quita de la lista de deseados.
DROP TRIGGER IF EXISTS trg_detalle_biblioteca//
CREATE TRIGGER trg_detalle_biblioteca
AFTER INSERT ON Detalle_Compra
FOR EACH ROW
BEGIN
  INSERT INTO Biblioteca (id_usuario, id_juego, fecha_adquisicion, origen)
  SELECT c.id_usuario, NEW.id_juego, c.fecha_compra, 'compra'
  FROM Compras c WHERE c.id_compra = NEW.id_compra;
  -- Como en Steam: al comprarlo, sale de la lista de deseados
  DELETE ld FROM Lista_Deseados ld
  JOIN Compras c ON c.id_usuario = ld.id_usuario
  WHERE c.id_compra = NEW.id_compra AND ld.id_juego = NEW.id_juego;
END//

-- 4.5 Cada movimiento actualiza el saldo (si queda negativo, el CHECK
--     chk_usuarios_saldo hace fallar toda la operación).
DROP TRIGGER IF EXISTS trg_movimiento_saldo//
CREATE TRIGGER trg_movimiento_saldo
AFTER INSERT ON Movimientos_Billetera
FOR EACH ROW
BEGIN
  UPDATE Usuarios
  SET saldo_billetera = saldo_billetera + NEW.monto
  WHERE id_usuario = NEW.id_usuario;
END//

-- 4.6 / 4.7 El libro de movimientos es inmutable (como un registro contable).
DROP TRIGGER IF EXISTS trg_movimiento_no_update//
CREATE TRIGGER trg_movimiento_no_update
BEFORE UPDATE ON Movimientos_Billetera
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Los movimientos no se modifican: registre un movimiento compensatorio';
END//

DROP TRIGGER IF EXISTS trg_movimiento_no_delete//
CREATE TRIGGER trg_movimiento_no_delete
BEFORE DELETE ON Movimientos_Billetera
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Los movimientos no se borran: registre un movimiento compensatorio';
END//

-- 4.14 / 4.15 El detalle de una compra es historial económico: no se
--      modifica ni se borra (una compra se anula con un reembolso).
DROP TRIGGER IF EXISTS trg_detalle_no_update//
CREATE TRIGGER trg_detalle_no_update
BEFORE UPDATE ON Detalle_Compra
FOR EACH ROW
BEGIN
  IF NEW.id_compra <> OLD.id_compra OR NEW.id_juego <> OLD.id_juego
     OR NEW.precio_pagado <> OLD.precio_pagado THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Una compra registrada no se modifica: se anula con un reembolso';
  END IF;
END//

DROP TRIGGER IF EXISTS trg_detalle_no_delete//
CREATE TRIGGER trg_detalle_no_delete
BEFORE DELETE ON Detalle_Compra
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Una compra registrada no se borra: se anula con un reembolso';
END//

-- 4.8 Solo se reseña un juego que se tiene.
DROP TRIGGER IF EXISTS trg_resena_validar//
CREATE TRIGGER trg_resena_validar
BEFORE INSERT ON Resenas
FOR EACH ROW
BEGIN
  IF NOT EXISTS (SELECT 1 FROM Biblioteca
                 WHERE id_usuario = NEW.id_usuario AND id_juego = NEW.id_juego) THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Solo se puede reseñar un juego que está en la biblioteca';
  END IF;
END//

DELIMITER ;

DELIMITER //

-- 4.9 Regla de Steam: aprobación automática si pasaron <= 14 días
--     y se jugó menos de 2 horas. Si no, queda "en_revision".
DROP TRIGGER IF EXISTS trg_reembolso_validar//
CREATE TRIGGER trg_reembolso_validar
BEFORE INSERT ON Reembolsos
FOR EACH ROW
BEGIN
  DECLARE v_fecha_compra DATETIME;
  DECLARE v_precio       DECIMAL(10,2);
  DECLARE v_usuario      INT;
  DECLARE v_juego        INT;
  DECLARE v_billetera    BOOLEAN;
  DECLARE v_horas        DECIMAL(7,1) DEFAULT NULL;

  SELECT c.fecha_compra, d.precio_pagado, c.id_usuario, d.id_juego, m.es_billetera
    INTO v_fecha_compra, v_precio, v_usuario, v_juego, v_billetera
  FROM Detalle_Compra d
  JOIN Compras c      ON c.id_compra = d.id_compra
  JOIN Metodos_Pago m ON m.id_metodo_pago = c.id_metodo_pago
  WHERE d.id_detalle = NEW.id_detalle;

  SELECT horas_jugadas INTO v_horas
  FROM Biblioteca WHERE id_usuario = v_usuario AND id_juego = v_juego;

  IF v_horas IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El juego ya no está en la biblioteca del usuario';
  END IF;

  IF NEW.monto_devuelto IS NULL THEN
    SET NEW.monto_devuelto = v_precio;
  ELSEIF NEW.monto_devuelto > v_precio THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El reembolso no puede superar lo pagado';
  END IF;

  -- Lo pagado con billetera vuelve siempre a la billetera
  IF v_billetera THEN
    SET NEW.destino = 'billetera';
  END IF;

  IF NEW.fecha_solicitud < v_fecha_compra THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La solicitud no puede ser anterior a la compra';
  END IF;

  -- Plazo exacto: hasta 14 días (con horas y minutos) desde la compra
  IF NEW.fecha_solicitud <= v_fecha_compra + INTERVAL 14 DAY AND v_horas < 2 THEN
    SET NEW.estado = 'aprobado';
  ELSE
    SET NEW.estado = 'en_revision';
  END IF;
END//

-- 4.10 Si el reembolso nace aprobado, se aplica.
DROP TRIGGER IF EXISTS trg_reembolso_aplicar//
CREATE TRIGGER trg_reembolso_aplicar
AFTER INSERT ON Reembolsos
FOR EACH ROW
BEGIN
  IF NEW.estado = 'aprobado' THEN
    CALL sp_aplicar_reembolso(NEW.id_detalle, NEW.monto_devuelto, NEW.destino, NEW.fecha_solicitud);
  END IF;
END//

-- 4.11 Valida toda modificación de un reembolso:
--      - uno resuelto (aprobado o rechazado) no se modifica más;
--      - en uno en revisión no se cambia la compra ni la fecha, el monto no
--        supera lo pagado y lo pagado con billetera vuelve a la billetera.
DROP TRIGGER IF EXISTS trg_reembolso_bloquear//
CREATE TRIGGER trg_reembolso_bloquear
BEFORE UPDATE ON Reembolsos
FOR EACH ROW
BEGIN
  DECLARE v_precio    DECIMAL(10,2);
  DECLARE v_billetera BOOLEAN;

  IF OLD.estado IN ('aprobado','rechazado') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un reembolso ya resuelto no se puede modificar';
  END IF;
  IF NEW.id_detalle <> OLD.id_detalle OR NEW.fecha_solicitud <> OLD.fecha_solicitud THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No se puede cambiar la compra ni la fecha de un reembolso';
  END IF;

  SELECT d.precio_pagado, m.es_billetera INTO v_precio, v_billetera
  FROM Detalle_Compra d
  JOIN Compras c      ON c.id_compra = d.id_compra
  JOIN Metodos_Pago m ON m.id_metodo_pago = c.id_metodo_pago
  WHERE d.id_detalle = OLD.id_detalle;

  IF NEW.monto_devuelto IS NULL OR NEW.monto_devuelto > v_precio THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El reembolso no puede superar lo pagado';
  END IF;
  IF v_billetera AND NEW.destino <> 'billetera' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Lo pagado con billetera se devuelve a la billetera';
  END IF;
END//

-- 4.12 Cuando un admin aprueba uno "en_revision", se aplica.
DROP TRIGGER IF EXISTS trg_reembolso_revision//
CREATE TRIGGER trg_reembolso_revision
AFTER UPDATE ON Reembolsos
FOR EACH ROW
BEGIN
  IF OLD.estado = 'en_revision' AND NEW.estado = 'aprobado' THEN
    CALL sp_aplicar_reembolso(NEW.id_detalle, NEW.monto_devuelto, NEW.destino, NOW());
  END IF;
END//

-- 4.13 Mercado: valida dueño, que sea comerciable, que no esté ya publicado,
--      y calcula comisiones (5 % Steam + tasa del juego, mínimo 0,01 c/u).
DROP TRIGGER IF EXISTS trg_publicacion_validar//
CREATE TRIGGER trg_publicacion_validar
BEFORE INSERT ON Publicaciones_Mercado
FOR EACH ROW
BEGIN
  DECLARE v_duenio      INT DEFAULT NULL;
  DECLARE v_tasa        DECIMAL(4,2);
  DECLARE v_comerciable BOOLEAN;

  SELECT inv.id_usuario, j.tasa_mercado, it.comerciable
    INTO v_duenio, v_tasa, v_comerciable
  FROM Inventario inv
  JOIN Items it ON it.id_item = inv.id_item
  JOIN Juegos j ON j.id_juego = it.id_juego
  WHERE inv.id_inventario = NEW.id_inventario;

  IF v_duenio IS NULL OR v_duenio <> NEW.id_vendedor THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El ítem no pertenece al vendedor';
  END IF;
  IF NOT v_comerciable THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El ítem no es comerciable';
  END IF;
  IF EXISTS (SELECT 1 FROM Publicaciones_Mercado
             WHERE id_inventario = NEW.id_inventario AND estado = 'activa') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El ítem ya tiene una publicación activa';
  END IF;

  SET NEW.comision_steam = GREATEST(0.01, ROUND(NEW.precio_vendedor * 0.05, 2));
  SET NEW.comision_juego = GREATEST(0.01, ROUND(NEW.precio_vendedor * v_tasa / 100, 2));
  SET NEW.estado = 'activa';
  SET NEW.id_comprador = NULL;
  SET NEW.fecha_venta  = NULL;
END//

DELIMITER ;
