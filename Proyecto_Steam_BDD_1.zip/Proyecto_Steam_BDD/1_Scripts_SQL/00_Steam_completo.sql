-- =====================================================================
--  STEAM SISTEMA v2  -  01. CREACIÓN DE LA BASE, TABLAS E ÍNDICES
--  Tienda oficial + Mercado de la Comunidad
--  MySQL 8.0.16 o superior (usa CHECK, columnas generadas y roles)
--  Orden de ejecución: 01 al 09 (ver LEEME.txt). Este archivo BORRA y recrea la base.
-- =====================================================================
SET NAMES utf8mb4;
DROP DATABASE IF EXISTS steam_sistema;
CREATE DATABASE steam_sistema CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE steam_sistema;

-- =====================================================================
-- TABLAS (DDL)
--    Reglas de FK usadas a propósito:
--      RESTRICT  -> registros económicos (compras, movimientos, mercado):
--                   no se pueden perder por borrar un usuario o un juego.
--      CASCADE   -> datos que solo existen por su "padre" (biblioteca,
--                   reseñas, lista de deseados, géneros y promos de un juego).
--      SET NULL  -> referencias opcionales (desarrolladora, promoción).
-- =====================================================================

-- ---------- Catálogo ----------
CREATE TABLE Desarrolladoras (
  id_desarrolladora INT PRIMARY KEY AUTO_INCREMENT,
  nombre            VARCHAR(100) NOT NULL UNIQUE,
  region            VARCHAR(50)
);

CREATE TABLE Generos (
  id_genero INT PRIMARY KEY AUTO_INCREMENT,
  nombre    VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE Juegos (
  id_juego          INT PRIMARY KEY AUTO_INCREMENT,
  nombre_juego      VARCHAR(150) NOT NULL UNIQUE,
  precio_base       DECIMAL(10,2) NOT NULL,
  fecha_lanzamiento DATE,
  tasa_mercado      DECIMAL(4,2) NOT NULL DEFAULT 10.00, -- % que cobra la editora en el Mercado
  id_desarrolladora INT,
  CONSTRAINT chk_juegos_precio CHECK (precio_base >= 0),
  CONSTRAINT chk_juegos_tasa   CHECK (tasa_mercado BETWEEN 0 AND 30),
  CONSTRAINT fk_juegos_desarrolladora FOREIGN KEY (id_desarrolladora)
    REFERENCES Desarrolladoras(id_desarrolladora) ON DELETE SET NULL
);

-- N:M -> un juego tiene varios géneros (atributo multivaluado -> tabla aparte)
CREATE TABLE Juego_Genero (
  id_juego  INT NOT NULL,
  id_genero INT NOT NULL,
  PRIMARY KEY (id_juego, id_genero),
  FOREIGN KEY (id_juego)  REFERENCES Juegos(id_juego)   ON DELETE CASCADE,
  FOREIGN KEY (id_genero) REFERENCES Generos(id_genero) ON DELETE CASCADE
);

-- ---------- Usuarios ----------
-- Todos los usuarios compran en la tienda y pueden vender ítems en el Mercado,
-- por eso ya no existe el rol "vendedor".
CREATE TABLE Usuarios (
  id_usuario      INT PRIMARY KEY AUTO_INCREMENT,
  nombre_cuenta   VARCHAR(50)  NOT NULL UNIQUE,   -- clave alterna
  nombre          VARCHAR(100) NOT NULL,          -- nombre visible (puede repetirse)
  email           VARCHAR(150) NOT NULL UNIQUE,   -- clave alterna
  pais            VARCHAR(50),
  rol             ENUM('jugador','admin') NOT NULL DEFAULT 'jugador',
  fecha_registro  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  saldo_billetera DECIMAL(10,2) NOT NULL DEFAULT 0, -- desnormalizado: lo mantiene un trigger
  CONSTRAINT chk_usuarios_saldo CHECK (saldo_billetera >= 0)
);

-- ---------- Promociones ----------
-- id_desarrolladora NULL = rebaja de la plataforma (ej. Rebajas de Otoño).
CREATE TABLE Promociones (
  id_promocion         INT PRIMARY KEY AUTO_INCREMENT,
  nombre               VARCHAR(100) NOT NULL,
  fecha_inicio         DATE NOT NULL,
  fecha_fin            DATE NOT NULL,
  porcentaje_descuento DECIMAL(5,2) NOT NULL,
  id_desarrolladora    INT,
  CONSTRAINT chk_promociones_fechas    CHECK (fecha_fin >= fecha_inicio),
  CONSTRAINT chk_promociones_descuento CHECK (porcentaje_descuento BETWEEN 0 AND 100),
  FOREIGN KEY (id_desarrolladora) REFERENCES Desarrolladoras(id_desarrolladora)
    ON DELETE SET NULL
);

CREATE TABLE Juego_Promocion (
  id_promocion INT NOT NULL,
  id_juego     INT NOT NULL,
  PRIMARY KEY (id_promocion, id_juego),
  FOREIGN KEY (id_promocion) REFERENCES Promociones(id_promocion) ON DELETE CASCADE,
  FOREIGN KEY (id_juego)     REFERENCES Juegos(id_juego)          ON DELETE CASCADE
);

-- ---------- Tienda: compras ----------
CREATE TABLE Metodos_Pago (
  id_metodo_pago INT PRIMARY KEY AUTO_INCREMENT,
  nombre         VARCHAR(50) NOT NULL UNIQUE,
  es_billetera   BOOLEAN NOT NULL DEFAULT FALSE
);

-- Cabecera de la compra (un "carrito" pagado). El total NO se guarda:
-- se calcula sumando el detalle (evita redundancia).
CREATE TABLE Compras (
  id_compra      INT PRIMARY KEY AUTO_INCREMENT,
  id_usuario     INT NOT NULL,
  id_metodo_pago INT NOT NULL,
  fecha_compra   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_usuario)     REFERENCES Usuarios(id_usuario)         ON DELETE RESTRICT,
  FOREIGN KEY (id_metodo_pago) REFERENCES Metodos_Pago(id_metodo_pago) ON DELETE RESTRICT
);

-- Cada juego de una compra. precio_pagado es un dato HISTÓRICO real:
-- no cambia aunque después cambie el precio del juego.
CREATE TABLE Detalle_Compra (
  id_detalle    INT PRIMARY KEY AUTO_INCREMENT,
  id_compra     INT NOT NULL,
  id_juego      INT NOT NULL,
  precio_pagado DECIMAL(10,2) NOT NULL,
  id_promocion  INT NULL,  -- promoción aplicada (si hubo)
  CONSTRAINT uq_detalle_compra_juego UNIQUE (id_compra, id_juego),
  CONSTRAINT chk_detalle_precio CHECK (precio_pagado >= 0),
  FOREIGN KEY (id_compra)    REFERENCES Compras(id_compra)         ON DELETE RESTRICT, -- una compra no se borra: se anula con un reembolso
  FOREIGN KEY (id_juego)     REFERENCES Juegos(id_juego)           ON DELETE RESTRICT,
  FOREIGN KEY (id_promocion) REFERENCES Promociones(id_promocion)  ON DELETE SET NULL
);

-- Licencias que posee cada usuario (reemplaza el UNIQUE(usuario,juego) de Compras).
CREATE TABLE Biblioteca (
  id_usuario        INT NOT NULL,
  id_juego          INT NOT NULL,
  fecha_adquisicion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  horas_jugadas     DECIMAL(7,1) NOT NULL DEFAULT 0,
  origen            ENUM('compra','regalo','codigo') NOT NULL DEFAULT 'compra',
  PRIMARY KEY (id_usuario, id_juego),
  CONSTRAINT chk_biblioteca_horas CHECK (horas_jugadas >= 0),
  FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE CASCADE,
  FOREIGN KEY (id_juego)   REFERENCES Juegos(id_juego)     ON DELETE CASCADE
);

-- Un reembolso por línea de compra (se reembolsa un juego, no toda la compra).
CREATE TABLE Reembolsos (
  id_reembolso    INT PRIMARY KEY AUTO_INCREMENT,
  id_detalle      INT NOT NULL UNIQUE,
  motivo          VARCHAR(200),
  fecha_solicitud DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  estado          ENUM('aprobado','en_revision','rechazado') NOT NULL DEFAULT 'en_revision',
  monto_devuelto  DECIMAL(10,2) NULL,  -- si no se informa, el trigger pone lo pagado
  destino         ENUM('billetera','medio_original') NOT NULL DEFAULT 'medio_original',
  CONSTRAINT chk_reembolsos_monto CHECK (monto_devuelto >= 0),
  FOREIGN KEY (id_detalle) REFERENCES Detalle_Compra(id_detalle) ON DELETE RESTRICT
);

CREATE TABLE Lista_Deseados (
  id_usuario     INT NOT NULL,
  id_juego       INT NOT NULL,
  fecha_agregado DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_usuario, id_juego),
  FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE CASCADE,
  FOREIGN KEY (id_juego)   REFERENCES Juegos(id_juego)     ON DELETE CASCADE
);

CREATE TABLE Resenas (
  id_resena   INT PRIMARY KEY AUTO_INCREMENT,
  id_usuario  INT NOT NULL,
  id_juego    INT NOT NULL,
  recomendado BOOLEAN NOT NULL,
  texto       VARCHAR(500),
  fecha       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_resena_usuario_juego UNIQUE (id_usuario, id_juego),
  FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE CASCADE,
  FOREIGN KEY (id_juego)   REFERENCES Juegos(id_juego)     ON DELETE CASCADE
);

-- ---------- Billetera Steam ----------
-- Libro de movimientos: positivo = entra dinero, negativo = sale.
CREATE TABLE Movimientos_Billetera (
  id_movimiento INT PRIMARY KEY AUTO_INCREMENT,
  id_usuario    INT NOT NULL,
  tipo          ENUM('recarga','compra_tienda','reembolso','venta_mercado','compra_mercado') NOT NULL,
  monto         DECIMAL(10,2) NOT NULL,
  fecha         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  referencia    VARCHAR(100),
  CONSTRAINT chk_movimientos_monto CHECK (monto <> 0),
  FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE RESTRICT
);

-- ---------- Mercado de la Comunidad ----------
CREATE TABLE Items (
  id_item     INT PRIMARY KEY AUTO_INCREMENT,
  id_juego    INT NOT NULL,
  nombre      VARCHAR(100) NOT NULL,
  tipo        ENUM('cromo','skin','fondo','emoticono','caja') NOT NULL,
  rareza      ENUM('comun','poco_comun','raro','legendario') NOT NULL DEFAULT 'comun',
  comerciable BOOLEAN NOT NULL DEFAULT TRUE,
  CONSTRAINT uq_items_juego_nombre UNIQUE (id_juego, nombre),
  FOREIGN KEY (id_juego) REFERENCES Juegos(id_juego) ON DELETE CASCADE
);

-- Cada fila es UNA copia concreta de un ítem en poder de un usuario.
CREATE TABLE Inventario (
  id_inventario   INT PRIMARY KEY AUTO_INCREMENT,
  id_usuario      INT NOT NULL,
  id_item         INT NOT NULL,
  fecha_obtencion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE RESTRICT,
  FOREIGN KEY (id_item)    REFERENCES Items(id_item)       ON DELETE RESTRICT
);

-- Reemplaza a la vieja tabla Ventas: lo que venden los usuarios son ÍTEMS.
-- Las comisiones las calcula un trigger; precio_comprador es columna generada.
CREATE TABLE Publicaciones_Mercado (
  id_publicacion    INT PRIMARY KEY AUTO_INCREMENT,
  id_inventario     INT NOT NULL,
  id_vendedor       INT NOT NULL,
  precio_vendedor   DECIMAL(10,2) NOT NULL,           -- lo que recibe el vendedor
  comision_steam    DECIMAL(10,2) NOT NULL DEFAULT 0, -- 5 % (mínimo 0,01)
  comision_juego    DECIMAL(10,2) NOT NULL DEFAULT 0, -- tasa_mercado del juego
  precio_comprador  DECIMAL(10,2) AS (precio_vendedor + comision_steam + comision_juego) STORED,
  estado            ENUM('activa','vendida','cancelada') NOT NULL DEFAULT 'activa',
  fecha_publicacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  id_comprador      INT NULL,
  fecha_venta       DATETIME NULL,
  -- Vale id_inventario solo mientras la publicación está activa (si no, NULL).
  -- Con el UNIQUE, una copia no puede tener dos publicaciones activas, ni
  -- siquiera con dos INSERT simultáneos (UNIQUE admite varios NULL).
  inventario_activo INT AS (IF(estado = 'activa', id_inventario, NULL)) STORED,
  CONSTRAINT uq_pub_una_activa UNIQUE (inventario_activo),
  CONSTRAINT chk_pub_precio CHECK (precio_vendedor > 0),
  CONSTRAINT chk_pub_comprador CHECK (id_comprador IS NULL OR id_comprador <> id_vendedor),
  CONSTRAINT chk_pub_vendida CHECK (estado <> 'vendida' OR (id_comprador IS NOT NULL AND fecha_venta IS NOT NULL)),
  FOREIGN KEY (id_inventario) REFERENCES Inventario(id_inventario) ON DELETE RESTRICT,
  FOREIGN KEY (id_vendedor)   REFERENCES Usuarios(id_usuario)      ON DELETE RESTRICT,
  FOREIGN KEY (id_comprador)  REFERENCES Usuarios(id_usuario)      ON DELETE RESTRICT
);

-- ---------- Auditoría ----------
CREATE TABLE Auditoria_Precios (
  id_auditoria    INT PRIMARY KEY AUTO_INCREMENT,
  id_juego        INT NOT NULL,
  precio_anterior DECIMAL(10,2) NOT NULL,
  precio_nuevo    DECIMAL(10,2) NOT NULL,
  fecha           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  usuario_bd      VARCHAR(100),
  FOREIGN KEY (id_juego) REFERENCES Juegos(id_juego) ON DELETE CASCADE
);

-- =====================================================================
-- ÍNDICES ADICIONALES
--    (InnoDB ya indexa PK, UNIQUE y FK; estos aceleran filtros frecuentes)
-- =====================================================================
CREATE INDEX idx_compras_fecha        ON Compras(fecha_compra);
CREATE INDEX idx_movimientos_usr_fecha ON Movimientos_Billetera(id_usuario, fecha);
CREATE INDEX idx_publicaciones_estado ON Publicaciones_Mercado(estado, fecha_publicacion);
CREATE INDEX idx_promociones_fechas   ON Promociones(fecha_inicio, fecha_fin);
CREATE INDEX idx_usuarios_pais        ON Usuarios(pais);
-- =====================================================================
--  STEAM SISTEMA v2  -  02. FUNCIONES
--  Calculan el precio con la promoción vigente en una fecha.
--  Probado en MySQL 8 (HeidiSQL o Workbench). Ejecutar el archivo completo (F9 en HeidiSQL).
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- =====================================================================
-- FUNCIONES
-- =====================================================================
DELIMITER //

-- Mayor descuento vigente de un juego en una fecha (0 si no tiene).
DROP FUNCTION IF EXISTS fn_descuento_en_fecha//
CREATE FUNCTION fn_descuento_en_fecha(p_juego INT, p_fecha DATE)
RETURNS DECIMAL(5,2)
READS SQL DATA
BEGIN
  DECLARE v_desc DECIMAL(5,2);
  SELECT COALESCE(MAX(p.porcentaje_descuento), 0) INTO v_desc
  FROM Juego_Promocion jp
  JOIN Promociones p ON p.id_promocion = jp.id_promocion
  WHERE jp.id_juego = p_juego
    AND p_fecha BETWEEN p.fecha_inicio AND p.fecha_fin;
  RETURN v_desc;
END//

-- Promoción que se aplica (la de mayor descuento) o NULL.
DROP FUNCTION IF EXISTS fn_promo_en_fecha//
CREATE FUNCTION fn_promo_en_fecha(p_juego INT, p_fecha DATE)
RETURNS INT
READS SQL DATA
BEGIN
  DECLARE v_promo INT DEFAULT NULL;
  SELECT p.id_promocion INTO v_promo
  FROM Juego_Promocion jp
  JOIN Promociones p ON p.id_promocion = jp.id_promocion
  WHERE jp.id_juego = p_juego
    AND p_fecha BETWEEN p.fecha_inicio AND p.fecha_fin
  ORDER BY p.porcentaje_descuento DESC, p.id_promocion
  LIMIT 1;
  RETURN v_promo;
END//

DROP FUNCTION IF EXISTS fn_precio_en_fecha//
CREATE FUNCTION fn_precio_en_fecha(p_juego INT, p_fecha DATE)
RETURNS DECIMAL(10,2)
READS SQL DATA
BEGIN
  DECLARE v_base DECIMAL(10,2);
  SELECT precio_base INTO v_base FROM Juegos WHERE id_juego = p_juego;
  RETURN ROUND(v_base * (1 - fn_descuento_en_fecha(p_juego, p_fecha) / 100), 2);
END//

DROP FUNCTION IF EXISTS fn_precio_actual//
CREATE FUNCTION fn_precio_actual(p_juego INT)
RETURNS DECIMAL(10,2)
READS SQL DATA
BEGIN
  RETURN fn_precio_en_fecha(p_juego, CURDATE());
END//

DELIMITER ;
-- =====================================================================
--  STEAM SISTEMA v2  -  03. PROCEDIMIENTOS ALMACENADOS
--  Operaciones de negocio con transacciones (COMMIT / ROLLBACK).
--  Probado en MySQL 8 (HeidiSQL o Workbench). Ejecutar el archivo completo (F9 en HeidiSQL).
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- =====================================================================
-- PROCEDIMIENTOS (transacciones ACID)
-- =====================================================================
DELIMITER //

-- Comprar un juego en la tienda oficial.
DROP PROCEDURE IF EXISTS sp_comprar_juego//
CREATE PROCEDURE sp_comprar_juego(IN p_usuario INT, IN p_juego INT, IN p_metodo INT)
BEGIN
  DECLARE v_precio    DECIMAL(10,2);
  DECLARE v_promo     INT;
  DECLARE v_billetera BOOLEAN;
  DECLARE v_saldo     DECIMAL(10,2);
  DECLARE v_compra    INT;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;   -- devuelve el error original al cliente
  END;

  START TRANSACTION;
    SELECT es_billetera INTO v_billetera FROM Metodos_Pago WHERE id_metodo_pago = p_metodo;
    SET v_precio = fn_precio_actual(p_juego);
    SET v_promo  = fn_promo_en_fecha(p_juego, CURDATE());

    IF v_billetera THEN
      -- FOR UPDATE bloquea la fila: dos compras simultáneas no gastan el mismo saldo
      SELECT saldo_billetera INTO v_saldo FROM Usuarios WHERE id_usuario = p_usuario FOR UPDATE;
      IF v_saldo < v_precio THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Saldo insuficiente en la billetera';
      END IF;
    END IF;

    INSERT INTO Compras (id_usuario, id_metodo_pago) VALUES (p_usuario, p_metodo);
    SET v_compra = LAST_INSERT_ID();
    INSERT INTO Detalle_Compra (id_compra, id_juego, precio_pagado, id_promocion)
    VALUES (v_compra, p_juego, v_precio, v_promo);

    IF v_billetera AND v_precio > 0 THEN
      INSERT INTO Movimientos_Billetera (id_usuario, tipo, monto, referencia)
      VALUES (p_usuario, 'compra_tienda', -v_precio, CONCAT('Compra #', v_compra));
    END IF;
  COMMIT;

  SELECT v_compra AS id_compra, p_juego AS id_juego, v_precio AS precio_pagado,
         v_promo AS id_promocion_aplicada;
END//

-- Solicitar reembolso (las reglas las aplican los triggers).
DROP PROCEDURE IF EXISTS sp_solicitar_reembolso//
CREATE PROCEDURE sp_solicitar_reembolso(IN p_detalle INT, IN p_motivo VARCHAR(200),
                                        IN p_destino VARCHAR(20))
BEGIN
  INSERT INTO Reembolsos (id_detalle, motivo, destino)
  VALUES (p_detalle, p_motivo, p_destino);
  SELECT * FROM Reembolsos WHERE id_reembolso = LAST_INSERT_ID();
END//

-- Recargar la billetera.
DROP PROCEDURE IF EXISTS sp_recargar_billetera//
CREATE PROCEDURE sp_recargar_billetera(IN p_usuario INT, IN p_monto DECIMAL(10,2))
BEGIN
  IF p_monto <= 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El monto de recarga debe ser positivo';
  END IF;
  INSERT INTO Movimientos_Billetera (id_usuario, tipo, monto, referencia)
  VALUES (p_usuario, 'recarga', p_monto, 'Recarga de saldo');
  SELECT id_usuario, nombre, saldo_billetera FROM Usuarios WHERE id_usuario = p_usuario;
END//

-- Publicar un ítem del inventario en el Mercado.
DROP PROCEDURE IF EXISTS sp_publicar_item//
CREATE PROCEDURE sp_publicar_item(IN p_vendedor INT, IN p_inventario INT, IN p_precio DECIMAL(10,2))
BEGIN
  INSERT INTO Publicaciones_Mercado (id_inventario, id_vendedor, precio_vendedor)
  VALUES (p_inventario, p_vendedor, p_precio);
  SELECT * FROM Publicaciones_Mercado WHERE id_publicacion = LAST_INSERT_ID();
END//

-- Comprar un ítem del Mercado: mueve dinero y el ítem en UNA transacción.
DROP PROCEDURE IF EXISTS sp_comprar_item_mercado//
CREATE PROCEDURE sp_comprar_item_mercado(IN p_publicacion INT, IN p_comprador INT)
BEGIN
  DECLARE v_estado     VARCHAR(20) DEFAULT NULL;
  DECLARE v_vendedor   INT;
  DECLARE v_inventario INT;
  DECLARE v_precio_c   DECIMAL(10,2);
  DECLARE v_precio_v   DECIMAL(10,2);
  DECLARE v_saldo      DECIMAL(10,2);
  DECLARE v_duenio     INT DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;

  START TRANSACTION;
    SELECT estado, id_vendedor, id_inventario, precio_comprador, precio_vendedor
      INTO v_estado, v_vendedor, v_inventario, v_precio_c, v_precio_v
    FROM Publicaciones_Mercado WHERE id_publicacion = p_publicacion
    FOR UPDATE;

    IF v_estado IS NULL OR v_estado <> 'activa' THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La publicación no está disponible';
    END IF;
    IF v_vendedor = p_comprador THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No podés comprar tu propia publicación';
    END IF;

    -- Se bloquea la copia y se verifica que el vendedor todavía la tenga
    SELECT id_usuario INTO v_duenio FROM Inventario WHERE id_inventario = v_inventario FOR UPDATE;
    IF v_duenio IS NULL OR v_duenio <> v_vendedor THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El vendedor ya no tiene este ítem';
    END IF;

    SELECT saldo_billetera INTO v_saldo FROM Usuarios WHERE id_usuario = p_comprador FOR UPDATE;
    IF v_saldo < v_precio_c THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Saldo insuficiente en la billetera';
    END IF;

    INSERT INTO Movimientos_Billetera (id_usuario, tipo, monto, referencia) VALUES
      (p_comprador, 'compra_mercado', -v_precio_c, CONCAT('Publicación #', p_publicacion)),
      (v_vendedor,  'venta_mercado',   v_precio_v, CONCAT('Publicación #', p_publicacion));

    UPDATE Inventario SET id_usuario = p_comprador, fecha_obtencion = NOW()
    WHERE id_inventario = v_inventario;

    UPDATE Publicaciones_Mercado
    SET estado = 'vendida', id_comprador = p_comprador, fecha_venta = NOW()
    WHERE id_publicacion = p_publicacion;
  COMMIT;

  SELECT * FROM Publicaciones_Mercado WHERE id_publicacion = p_publicacion;
END//

-- Genera datos masivos: p_usuarios usuarios nuevos y p_compras compras al azar
-- (fechas del último tiempo, precio según la promo vigente ese día, ~30 % deja reseña).
DROP PROCEDURE IF EXISTS sp_generar_datos_masivos//
CREATE PROCEDURE sp_generar_datos_masivos(IN p_usuarios INT, IN p_compras INT)
BEGIN
  DECLARE i            INT DEFAULT 0;
  DECLARE v_base       INT;
  DECLARE v_max_u      INT;
  DECLARE v_max_j      INT;
  DECLARE v_u          INT;
  DECLARE v_j          INT;
  DECLARE v_metodo     INT;
  DECLARE v_registro   DATETIME;
  DECLARE v_lanz       DATE;
  DECLARE v_desde      DATETIME;
  DECLARE v_fecha      DATETIME;
  DECLARE v_compra     INT;
  DECLARE v_hechas     INT DEFAULT 0;
  DECLARE v_saltadas   INT DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;   -- si algo falla a mitad de la carga, no queda nada a medias
    RESIGNAL;
  END;

  SELECT COALESCE(MAX(id_usuario), 0) INTO v_base FROM Usuarios;

  START TRANSACTION;
  WHILE i < p_usuarios DO
    SET i = i + 1;
    INSERT INTO Usuarios (nombre_cuenta, nombre, email, pais, fecha_registro)
    VALUES (CONCAT('jugador_', v_base + i),
            CONCAT(ELT(1 + FLOOR(RAND() * 10), 'Lucas','Sofía','Mateo','Valentina','Thiago',
                       'Camila','Benjamín','Martina','Joaquín','Lucía'), ' ', v_base + i),
            CONCAT('jugador', v_base + i, '@correo.com'),
            ELT(1 + FLOOR(RAND() * 8), 'Argentina','Chile','Uruguay','México',
                'Colombia','España','Perú','Venezuela'),
            NOW() - INTERVAL FLOOR(RAND() * 900) DAY);
  END WHILE;

  SELECT MAX(id_usuario) INTO v_max_u FROM Usuarios;
  SELECT MAX(id_juego)   INTO v_max_j FROM Juegos;

  SET i = 0;
  WHILE i < p_compras DO
    SET i = i + 1;
    SET v_u = 1 + FLOOR(RAND() * v_max_u);
    SET v_j = 1 + FLOOR(RAND() * v_max_j);

    SET v_registro = NULL;
    SELECT fecha_registro INTO v_registro FROM Usuarios WHERE id_usuario = v_u AND rol = 'jugador';
    SELECT fecha_lanzamiento INTO v_lanz FROM Juegos WHERE id_juego = v_j;

    IF v_registro IS NULL OR v_lanz IS NULL OR v_lanz > CURDATE()
       OR EXISTS (SELECT 1 FROM Compras c JOIN Detalle_Compra d ON d.id_compra = c.id_compra
                  WHERE c.id_usuario = v_u AND d.id_juego = v_j) THEN  -- ya lo compró alguna vez
      SET v_saltadas = v_saltadas + 1;
    ELSE
      SET v_desde = GREATEST(v_registro, TIMESTAMP(v_lanz));
      SET v_fecha = v_desde + INTERVAL FLOOR(RAND() * GREATEST(TIMESTAMPDIFF(MINUTE, v_desde, NOW()), 1)) MINUTE;
      SELECT id_metodo_pago INTO v_metodo FROM Metodos_Pago
      WHERE es_billetera = FALSE ORDER BY RAND() LIMIT 1;

      INSERT INTO Compras (id_usuario, id_metodo_pago, fecha_compra) VALUES (v_u, v_metodo, v_fecha);
      SET v_compra = LAST_INSERT_ID();
      INSERT INTO Detalle_Compra (id_compra, id_juego, precio_pagado, id_promocion)
      VALUES (v_compra, v_j, fn_precio_en_fecha(v_j, DATE(v_fecha)), fn_promo_en_fecha(v_j, DATE(v_fecha)));

      UPDATE Biblioteca SET horas_jugadas = ROUND(RAND() * 150, 1)
      WHERE id_usuario = v_u AND id_juego = v_j;

      IF RAND() < 0.30 THEN
        INSERT INTO Resenas (id_usuario, id_juego, recomendado, texto, fecha)
        VALUES (v_u, v_j, RAND() < 0.78, 'Reseña generada automáticamente',
                LEAST(NOW(), v_fecha + INTERVAL FLOOR(1 + RAND() * 20) DAY));
      END IF;
      SET v_hechas = v_hechas + 1;
    END IF;
  END WHILE;
  COMMIT;

  SELECT p_usuarios AS usuarios_creados, v_hechas AS compras_creadas,
         v_saltadas AS intentos_descartados_por_duplicado;
END//

DELIMITER ;

-- Procedimiento interno que usan los triggers de reembolso (por eso este archivo va antes que 04).
DELIMITER //
DROP PROCEDURE IF EXISTS sp_aplicar_reembolso//
CREATE PROCEDURE sp_aplicar_reembolso(p_detalle INT, p_monto DECIMAL(10,2),
                                      p_destino VARCHAR(20), p_fecha DATETIME)
MODIFIES SQL DATA
BEGIN
  DECLARE v_usuario INT;
  DECLARE v_juego   INT;
  SELECT c.id_usuario, d.id_juego INTO v_usuario, v_juego
  FROM Detalle_Compra d JOIN Compras c ON c.id_compra = d.id_compra
  WHERE d.id_detalle = p_detalle;

  -- Se pierde la licencia
  DELETE FROM Biblioteca WHERE id_usuario = v_usuario AND id_juego = v_juego;
  -- Se devuelve el dinero a la billetera si corresponde
  IF p_destino = 'billetera' AND p_monto > 0 THEN
    INSERT INTO Movimientos_Billetera (id_usuario, tipo, monto, fecha, referencia)
    VALUES (v_usuario, 'reembolso', p_monto, p_fecha, CONCAT('Reembolso detalle #', p_detalle));
  END IF;
END//
DELIMITER ;
-- =====================================================================
--  STEAM SISTEMA v2  -  04. TRIGGERS
--  Reglas de negocio automáticas. Requiere 03_Steam_procedimientos.sql.
--  Probado en MySQL 8 (HeidiSQL o Workbench). Ejecutar el archivo completo (F9 en HeidiSQL).
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- =====================================================================
-- TRIGGERS
-- =====================================================================

-- 4.1 (original) Trigger de UNA sentencia: no necesita DELIMITER ni BEGIN/END.
--     Si fecha_fin < fecha_inicio, la iguala a fecha_inicio.
DROP TRIGGER IF EXISTS trg_fechas_promocion;
CREATE TRIGGER trg_fechas_promocion
BEFORE INSERT ON Promociones
FOR EACH ROW
SET NEW.fecha_fin = IF(NEW.fecha_fin < NEW.fecha_inicio, NEW.fecha_inicio, NEW.fecha_fin);

DELIMITER //

-- 4.2 Auditoría: registra cada cambio de precio_base.
DROP TRIGGER IF EXISTS trg_auditoria_precio//
CREATE TRIGGER trg_auditoria_precio
AFTER UPDATE ON Juegos
FOR EACH ROW
BEGIN
  IF OLD.precio_base <> NEW.precio_base THEN
    INSERT INTO Auditoria_Precios (id_juego, precio_anterior, precio_nuevo, usuario_bd)
    VALUES (NEW.id_juego, OLD.precio_base, NEW.precio_base, CURRENT_USER());
  END IF;
END//

-- 4.3 No se puede comprar un juego que ya está en la biblioteca.
DROP TRIGGER IF EXISTS trg_detalle_validar//
CREATE TRIGGER trg_detalle_validar
BEFORE INSERT ON Detalle_Compra
FOR EACH ROW
BEGIN
  IF EXISTS (SELECT 1
             FROM Compras c
             JOIN Biblioteca b ON b.id_usuario = c.id_usuario
             WHERE c.id_compra = NEW.id_compra AND b.id_juego = NEW.id_juego) THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'El usuario ya tiene este juego en su biblioteca';
  END IF;
END//

-- 4.4 Al comprar, el juego entra automáticamente en la biblioteca
--     y se quita de la lista de deseados.
DROP TRIGGER IF EXISTS trg_detalle_biblioteca//
CREATE TRIGGER trg_detalle_biblioteca
AFTER INSERT ON Detalle_Compra
FOR EACH ROW
BEGIN
  INSERT INTO Biblioteca (id_usuario, id_juego, fecha_adquisicion, origen)
  SELECT c.id_usuario, NEW.id_juego, c.fecha_compra, 'compra'
  FROM Compras c WHERE c.id_compra = NEW.id_compra;
  -- Como en Steam: al comprarlo, sale de la lista de deseados
  DELETE ld FROM Lista_Deseados ld
  JOIN Compras c ON c.id_usuario = ld.id_usuario
  WHERE c.id_compra = NEW.id_compra AND ld.id_juego = NEW.id_juego;
END//

-- 4.5 Cada movimiento actualiza el saldo (si queda negativo, el CHECK
--     chk_usuarios_saldo hace fallar toda la operación).
DROP TRIGGER IF EXISTS trg_movimiento_saldo//
CREATE TRIGGER trg_movimiento_saldo
AFTER INSERT ON Movimientos_Billetera
FOR EACH ROW
BEGIN
  UPDATE Usuarios
  SET saldo_billetera = saldo_billetera + NEW.monto
  WHERE id_usuario = NEW.id_usuario;
END//

-- 4.6 / 4.7 El libro de movimientos es inmutable (como un registro contable).
DROP TRIGGER IF EXISTS trg_movimiento_no_update//
CREATE TRIGGER trg_movimiento_no_update
BEFORE UPDATE ON Movimientos_Billetera
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Los movimientos no se modifican: registre un movimiento compensatorio';
END//

DROP TRIGGER IF EXISTS trg_movimiento_no_delete//
CREATE TRIGGER trg_movimiento_no_delete
BEFORE DELETE ON Movimientos_Billetera
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Los movimientos no se borran: registre un movimiento compensatorio';
END//

-- 4.14 / 4.15 El detalle de una compra es historial económico: no se
--      modifica ni se borra (una compra se anula con un reembolso).
DROP TRIGGER IF EXISTS trg_detalle_no_update//
CREATE TRIGGER trg_detalle_no_update
BEFORE UPDATE ON Detalle_Compra
FOR EACH ROW
BEGIN
  IF NEW.id_compra <> OLD.id_compra OR NEW.id_juego <> OLD.id_juego
     OR NEW.precio_pagado <> OLD.precio_pagado THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Una compra registrada no se modifica: se anula con un reembolso';
  END IF;
END//

DROP TRIGGER IF EXISTS trg_detalle_no_delete//
CREATE TRIGGER trg_detalle_no_delete
BEFORE DELETE ON Detalle_Compra
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Una compra registrada no se borra: se anula con un reembolso';
END//

-- 4.8 Solo se reseña un juego que se tiene.
DROP TRIGGER IF EXISTS trg_resena_validar//
CREATE TRIGGER trg_resena_validar
BEFORE INSERT ON Resenas
FOR EACH ROW
BEGIN
  IF NOT EXISTS (SELECT 1 FROM Biblioteca
                 WHERE id_usuario = NEW.id_usuario AND id_juego = NEW.id_juego) THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Solo se puede reseñar un juego que está en la biblioteca';
  END IF;
END//

DELIMITER ;

DELIMITER //

-- 4.9 Regla de Steam: aprobación automática si pasaron <= 14 días
--     y se jugó menos de 2 horas. Si no, queda "en_revision".
DROP TRIGGER IF EXISTS trg_reembolso_validar//
CREATE TRIGGER trg_reembolso_validar
BEFORE INSERT ON Reembolsos
FOR EACH ROW
BEGIN
  DECLARE v_fecha_compra DATETIME;
  DECLARE v_precio       DECIMAL(10,2);
  DECLARE v_usuario      INT;
  DECLARE v_juego        INT;
  DECLARE v_billetera    BOOLEAN;
  DECLARE v_horas        DECIMAL(7,1) DEFAULT NULL;

  SELECT c.fecha_compra, d.precio_pagado, c.id_usuario, d.id_juego, m.es_billetera
    INTO v_fecha_compra, v_precio, v_usuario, v_juego, v_billetera
  FROM Detalle_Compra d
  JOIN Compras c      ON c.id_compra = d.id_compra
  JOIN Metodos_Pago m ON m.id_metodo_pago = c.id_metodo_pago
  WHERE d.id_detalle = NEW.id_detalle;

  SELECT horas_jugadas INTO v_horas
  FROM Biblioteca WHERE id_usuario = v_usuario AND id_juego = v_juego;

  IF v_horas IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El juego ya no está en la biblioteca del usuario';
  END IF;

  IF NEW.monto_devuelto IS NULL THEN
    SET NEW.monto_devuelto = v_precio;
  ELSEIF NEW.monto_devuelto > v_precio THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El reembolso no puede superar lo pagado';
  END IF;

  -- Lo pagado con billetera vuelve siempre a la billetera
  IF v_billetera THEN
    SET NEW.destino = 'billetera';
  END IF;

  IF NEW.fecha_solicitud < v_fecha_compra THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La solicitud no puede ser anterior a la compra';
  END IF;

  -- Plazo exacto: hasta 14 días (con horas y minutos) desde la compra
  IF NEW.fecha_solicitud <= v_fecha_compra + INTERVAL 14 DAY AND v_horas < 2 THEN
    SET NEW.estado = 'aprobado';
  ELSE
    SET NEW.estado = 'en_revision';
  END IF;
END//

-- 4.10 Si el reembolso nace aprobado, se aplica.
DROP TRIGGER IF EXISTS trg_reembolso_aplicar//
CREATE TRIGGER trg_reembolso_aplicar
AFTER INSERT ON Reembolsos
FOR EACH ROW
BEGIN
  IF NEW.estado = 'aprobado' THEN
    CALL sp_aplicar_reembolso(NEW.id_detalle, NEW.monto_devuelto, NEW.destino, NEW.fecha_solicitud);
  END IF;
END//

-- 4.11 Valida toda modificación de un reembolso:
--      - uno resuelto (aprobado o rechazado) no se modifica más;
--      - en uno en revisión no se cambia la compra ni la fecha, el monto no
--        supera lo pagado y lo pagado con billetera vuelve a la billetera.
DROP TRIGGER IF EXISTS trg_reembolso_bloquear//
CREATE TRIGGER trg_reembolso_bloquear
BEFORE UPDATE ON Reembolsos
FOR EACH ROW
BEGIN
  DECLARE v_precio    DECIMAL(10,2);
  DECLARE v_billetera BOOLEAN;

  IF OLD.estado IN ('aprobado','rechazado') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un reembolso ya resuelto no se puede modificar';
  END IF;
  IF NEW.id_detalle <> OLD.id_detalle OR NEW.fecha_solicitud <> OLD.fecha_solicitud THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No se puede cambiar la compra ni la fecha de un reembolso';
  END IF;

  SELECT d.precio_pagado, m.es_billetera INTO v_precio, v_billetera
  FROM Detalle_Compra d
  JOIN Compras c      ON c.id_compra = d.id_compra
  JOIN Metodos_Pago m ON m.id_metodo_pago = c.id_metodo_pago
  WHERE d.id_detalle = OLD.id_detalle;

  IF NEW.monto_devuelto IS NULL OR NEW.monto_devuelto > v_precio THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El reembolso no puede superar lo pagado';
  END IF;
  IF v_billetera AND NEW.destino <> 'billetera' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Lo pagado con billetera se devuelve a la billetera';
  END IF;
END//

-- 4.12 Cuando un admin aprueba uno "en_revision", se aplica.
DROP TRIGGER IF EXISTS trg_reembolso_revision//
CREATE TRIGGER trg_reembolso_revision
AFTER UPDATE ON Reembolsos
FOR EACH ROW
BEGIN
  IF OLD.estado = 'en_revision' AND NEW.estado = 'aprobado' THEN
    CALL sp_aplicar_reembolso(NEW.id_detalle, NEW.monto_devuelto, NEW.destino, NOW());
  END IF;
END//

-- 4.13 Mercado: valida dueño, que sea comerciable, que no esté ya publicado,
--      y calcula comisiones (5 % Steam + tasa del juego, mínimo 0,01 c/u).
DROP TRIGGER IF EXISTS trg_publicacion_validar//
CREATE TRIGGER trg_publicacion_validar
BEFORE INSERT ON Publicaciones_Mercado
FOR EACH ROW
BEGIN
  DECLARE v_duenio      INT DEFAULT NULL;
  DECLARE v_tasa        DECIMAL(4,2);
  DECLARE v_comerciable BOOLEAN;

  SELECT inv.id_usuario, j.tasa_mercado, it.comerciable
    INTO v_duenio, v_tasa, v_comerciable
  FROM Inventario inv
  JOIN Items it ON it.id_item = inv.id_item
  JOIN Juegos j ON j.id_juego = it.id_juego
  WHERE inv.id_inventario = NEW.id_inventario;

  IF v_duenio IS NULL OR v_duenio <> NEW.id_vendedor THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El ítem no pertenece al vendedor';
  END IF;
  IF NOT v_comerciable THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El ítem no es comerciable';
  END IF;
  IF EXISTS (SELECT 1 FROM Publicaciones_Mercado
             WHERE id_inventario = NEW.id_inventario AND estado = 'activa') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El ítem ya tiene una publicación activa';
  END IF;

  SET NEW.comision_steam = GREATEST(0.01, ROUND(NEW.precio_vendedor * 0.05, 2));
  SET NEW.comision_juego = GREATEST(0.01, ROUND(NEW.precio_vendedor * v_tasa / 100, 2));
  SET NEW.estado = 'activa';
  SET NEW.id_comprador = NULL;
  SET NEW.fecha_venta  = NULL;
END//

DELIMITER ;
-- =====================================================================
--  STEAM SISTEMA v2  -  05. DATOS DE PRUEBA (INSERTS)
--  Datos legibles y coherentes. Los triggers llenan Biblioteca y saldos solos.
--  Probado en MySQL 8 (HeidiSQL o Workbench). Ejecutar el archivo completo (F9 en HeidiSQL).
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- =====================================================================
-- DATOS DE PRUEBA LEGIBLES (generados de forma coherente)
--    Todas las fechas son relativas a CURDATE(): siempre hay promociones
--    activas, pasadas y futuras, y reembolsos dentro/fuera de los 14 días.
-- =====================================================================
INSERT INTO Desarrolladoras (id_desarrolladora,nombre,region) VALUES
(1,'Capybara Studios','NA'),
(2,'Moonfire Games','EU'),
(3,'NeonPixel','LATAM'),
(4,'Pampa Interactive','LATAM'),
(5,'Nordlicht Software','EU'),
(6,'Sakura Forge','ASIA'),
(7,'Iron Kettle Games','NA'),
(8,'Andes Byte','LATAM'),
(9,'Polar Owl','EU'),
(10,'Red Lantern Studio','ASIA');

INSERT INTO Generos (id_genero,nombre) VALUES
(1,'Acción'),
(2,'Aventura'),
(3,'RPG'),
(4,'Estrategia'),
(5,'Simulación'),
(6,'Deportes'),
(7,'Carreras'),
(8,'Terror'),
(9,'Indie'),
(10,'Multijugador');

-- Eclipse Protocol (30) todavía no salió: sirve para consultas de 'próximos lanzamientos'.
INSERT INTO Juegos (id_juego,nombre_juego,precio_base,fecha_lanzamiento,tasa_mercado,id_desarrolladora) VALUES
(1,'Shadow Quest',29.99,'2022-03-15',10.00,1),
(2,'Neon Streets',49.99,'2023-05-20',10.00,3),
(3,'Galaxy Run',19.99,'2021-11-02',10.00,2),
(4,'Farm Legends',9.99,'2020-07-10',10.00,NULL),
(5,'Arena of Echoes',0.00,'2021-08-01',10.00,7),
(6,'Pampa Truco Online',4.99,'2022-09-09',10.00,4),
(7,'Mate & Magic',14.99,'2023-02-14',10.00,4),
(8,'Frostbound Kingdoms',39.99,'2022-12-01',10.00,5),
(9,'Hollow Lanterns',24.99,'2023-10-31',10.00,10),
(10,'Kitsune Blade',59.99,'2023-04-12',12.00,6),
(11,'Turbo Andes Rally',29.99,'2022-06-18',10.00,8),
(12,'Cumbre FC 2026',59.99,'2025-09-25',15.00,8),
(13,'Owl Post Tycoon',12.99,'2021-04-22',10.00,9),
(14,'Iron Kettle Tactics',34.99,'2022-02-08',10.00,7),
(15,'Starlight Courier',17.99,'2023-08-03',10.00,2),
(16,'Deep Sea Echo',21.99,'2022-10-13',10.00,5),
(17,'Cyber Mate 2099',44.99,'2024-03-01',10.00,3),
(18,'Ronin Drift',27.99,'2024-06-21',10.00,6),
(19,'Little Capybara Café',9.99,'2023-01-19',10.00,1),
(20,'Legends of the Southern Cross',39.99,'2024-09-10',10.00,8),
(21,'Pixel Gaucho',6.99,'2021-07-07',10.00,4),
(22,'Moonfire Siege',29.99,'2023-11-23',10.00,2),
(23,'Spectral Manor',19.99,'2024-10-25',10.00,10),
(24,'Polar Express Logistics',15.99,'2024-02-02',10.00,9),
(25,'Shadow Quest II',39.99,'2025-03-15',10.00,1),
(26,'Sakura Tennis Club',14.99,'2023-06-06',10.00,6),
(27,'Neon Streets: Overdrive',19.99,'2024-12-12',10.00,3),
(28,'Void Miners',11.99,'2022-05-05',10.00,9),
(29,'Capybara Kart',24.99,'2025-07-17',10.00,1),
(30,'Eclipse Protocol',49.99,'2027-03-12',10.00,7);

INSERT INTO Juego_Genero (id_juego,id_genero) VALUES
(1,1),(1,2),(2,1),(2,7),(3,9),(3,1),(4,5),(4,9),(5,1),(5,10),(6,4),(6,10),(7,3),(7,9),(8,4),(9,8),(9,2),(10,1),(10,3),(11,7),(11,6),(12,6),(12,10),(13,5),(13,4),(14,4),(14,10),(15,2),(15,9),(16,8),(16,9),(17,3),(17,1),(18,7),(19,5),(19,9),(20,3),(20,2),(21,9),(21,2),(22,4),(22,10),(23,8),(24,5),(25,1),(25,2),(26,6),(27,7),(28,9),(28,5),(29,7),(29,10),(30,1),(30,4);

INSERT INTO Metodos_Pago (id_metodo_pago,nombre,es_billetera) VALUES
(1,'Billetera Steam',TRUE),
(2,'Tarjeta de crédito',FALSE),
(3,'Tarjeta de débito',FALSE),
(4,'PayPal',FALSE),
(5,'Mercado Pago',FALSE);

INSERT INTO Usuarios (id_usuario,nombre_cuenta,nombre,email,pais,rol,fecha_registro) VALUES
(1,'mauro_ar','Mauricio','mauro@example.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 900 DAY, '10:00:00')),
(2,'isa_plays','Isabella','isa@example.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 850 DAY, '10:00:00')),
(3,'admin','Admin','admin@steam.com','Estados Unidos','admin',TIMESTAMP(CURDATE() - INTERVAL 1500 DAY, '10:00:00')),
(4,'bruno_gg','Bruno','bruno_gg@correo.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 501 DAY, '10:00:00')),
(5,'jean99','Jean','jean99@correo.com','Venezuela','jugador',TIMESTAMP(CURDATE() - INTERVAL 707 DAY, '10:00:00')),
(6,'valentina_ok','Valentina','valentina_ok@correo.com','Chile','jugador',TIMESTAMP(CURDATE() - INTERVAL 894 DAY, '10:00:00')),
(7,'tomas_pro','Tomás','tomas_pro@correo.com','Uruguay','jugador',TIMESTAMP(CURDATE() - INTERVAL 1354 DAY, '10:00:00')),
(8,'camilax','Camila','camilax@correo.com','México','jugador',TIMESTAMP(CURDATE() - INTERVAL 904 DAY, '10:00:00')),
(9,'diego_7','Diego','diego_7@correo.com','Colombia','jugador',TIMESTAMP(CURDATE() - INTERVAL 1042 DAY, '10:00:00')),
(10,'lucia_uy','Lucía','lucia_uy@correo.com','España','jugador',TIMESTAMP(CURDATE() - INTERVAL 1260 DAY, '10:00:00')),
(11,'martin_mx','Martín','martin_mx@correo.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 1355 DAY, '10:00:00')),
(12,'sofia_zz','Sofía','sofia_zz@correo.com','Perú','jugador',TIMESTAMP(CURDATE() - INTERVAL 485 DAY, '10:00:00')),
(13,'nicolas_go','Nicolás','nicolas_go@correo.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 1285 DAY, '10:00:00')),
(14,'paula_gg','Paula','paula_gg@correo.com','Chile','jugador',TIMESTAMP(CURDATE() - INTERVAL 608 DAY, '10:00:00')),
(15,'joaquin99','Joaquín','joaquin99@correo.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 1296 DAY, '10:00:00')),
(16,'agustina_ok','Agustina','agustina_ok@correo.com','Uruguay','jugador',TIMESTAMP(CURDATE() - INTERVAL 995 DAY, '10:00:00')),
(17,'facundo_pro','Facundo','facundo_pro@correo.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 1016 DAY, '10:00:00')),
(18,'renatax','Renata','renatax@correo.com','México','jugador',TIMESTAMP(CURDATE() - INTERVAL 949 DAY, '10:00:00')),
(19,'emilio_7','Emilio','emilio_7@correo.com','España','jugador',TIMESTAMP(CURDATE() - INTERVAL 810 DAY, '10:00:00')),
(20,'florencia_uy','Florencia','florencia_uy@correo.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 1182 DAY, '10:00:00')),
(21,'gonzalo_mx','Gonzalo','gonzalo_mx@correo.com','Chile','jugador',TIMESTAMP(CURDATE() - INTERVAL 966 DAY, '10:00:00')),
(22,'milagros_zz','Milagros','milagros_zz@correo.com','Perú','jugador',TIMESTAMP(CURDATE() - INTERVAL 940 DAY, '10:00:00')),
(23,'ignacio_go','Ignacio','ignacio_go@correo.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 1242 DAY, '10:00:00')),
(24,'daniela_gg','Daniela','daniela_gg@correo.com','Colombia','jugador',TIMESTAMP(CURDATE() - INTERVAL 1128 DAY, '10:00:00')),
(25,'santiago99','Santiago','santiago99@correo.com','México','jugador',TIMESTAMP(CURDATE() - INTERVAL 1175 DAY, '10:00:00')),
(26,'carolina_ok','Carolina','carolina_ok@correo.com','Venezuela','jugador',TIMESTAMP(CURDATE() - INTERVAL 1166 DAY, '10:00:00')),
(27,'federico_pro','Federico','federico_pro@correo.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 882 DAY, '10:00:00')),
(28,'julietax','Julieta','julietax@correo.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 1149 DAY, '10:00:00')),
(29,'andres_7','Andrés','andres_7@correo.com','Colombia','jugador',TIMESTAMP(CURDATE() - INTERVAL 1171 DAY, '10:00:00')),
(30,'micaela_uy','Micaela','micaela_uy@correo.com','Uruguay','jugador',TIMESTAMP(CURDATE() - INTERVAL 980 DAY, '10:00:00')),
(31,'pablo_mx','Pablo','pablo_mx@correo.com','España','jugador',TIMESTAMP(CURDATE() - INTERVAL 831 DAY, '10:00:00')),
(32,'abril_zz','Abril','abril_zz@correo.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 625 DAY, '10:00:00')),
(33,'lautaro_go','Lautaro','lautaro_go@correo.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 382 DAY, '10:00:00')),
(34,'ximena_gg','Ximena','ximena_gg@correo.com','México','jugador',TIMESTAMP(CURDATE() - INTERVAL 1008 DAY, '10:00:00')),
(35,'rodrigo99','Rodrigo','rodrigo99@correo.com','Chile','jugador',TIMESTAMP(CURDATE() - INTERVAL 462 DAY, '10:00:00')),
(36,'antonella_ok','Antonella','antonella_ok@correo.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 493 DAY, '10:00:00')),
(37,'hernan_pro','Hernán','hernan_pro@correo.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 674 DAY, '10:00:00')),
(38,'lucianax','Luciana','lucianax@correo.com','Venezuela','jugador',TIMESTAMP(CURDATE() - INTERVAL 1216 DAY, '10:00:00')),
(39,'kevin_7','Kevin','kevin_7@correo.com','Perú','jugador',TIMESTAMP(CURDATE() - INTERVAL 480 DAY, '10:00:00')),
(40,'brenda_uy','Brenda','brenda_uy@correo.com','Argentina','jugador',TIMESTAMP(CURDATE() - INTERVAL 840 DAY, '10:00:00'));

-- Promociones: 2 activas hoy, 5 pasadas y 1 planificada (futura).
INSERT INTO Promociones (id_promocion,nombre,fecha_inicio,fecha_fin,porcentaje_descuento,id_desarrolladora) VALUES
(1,'Semana Capybara',CURDATE() - INTERVAL 2 DAY,CURDATE() + INTERVAL 13 DAY,20.00,1),
(2,'Rebajas de Otoño',CURDATE() - INTERVAL 5 DAY,CURDATE() + INTERVAL 20 DAY,35.00,NULL),
(3,'Rebajas de Invierno (edición anterior)',CURDATE() - INTERVAL 330 DAY,CURDATE() - INTERVAL 316 DAY,50.00,NULL),
(4,'Rebajas de Verano',CURDATE() - INTERVAL 145 DAY,CURDATE() - INTERVAL 131 DAY,40.00,NULL),
(5,'Festival Indie',CURDATE() - INTERVAL 60 DAY,CURDATE() - INTERVAL 54 DAY,25.00,NULL),
(6,'Aniversario NeonPixel',CURDATE() - INTERVAL 95 DAY,CURDATE() - INTERVAL 85 DAY,30.00,3),
(7,'Lanzamiento Cumbre FC',CURDATE() - INTERVAL 40 DAY,CURDATE() - INTERVAL 33 DAY,15.00,8),
(8,'Rebajas de Invierno (próxima)',CURDATE() + INTERVAL 33 DAY,CURDATE() + INTERVAL 47 DAY,50.00,NULL);

INSERT INTO Juego_Promocion (id_promocion,id_juego) VALUES
(1,1),(1,19),(1,25),(1,29),(2,2),(2,3),(2,7),(2,8),(2,9),(2,11),(2,13),(2,16),(2,21),(2,24),(2,28),(3,1),(3,3),(3,4),(3,8),(3,10),(3,13),(3,14),(3,16),(3,21),(4,1),(4,2),(4,6),(4,7),(4,9),(4,10),(4,11),(4,15),(4,17),(4,19),(4,22),(5,3),(5,4),(5,7),(5,15),(5,19),(5,21),(5,28),(6,2),(6,17),(6,27),(7,11),(7,12),(7,20),(8,1),(8,2),(8,8),(8,9),(8,10),(8,12),(8,14),(8,17),(8,18),(8,20),(8,22),(8,25);

-- ---------- Historial cronológico: recargas, compras (los triggers llenan
-- ---------- Biblioteca y actualizan el saldo de la billetera)
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (1,9,3,TIMESTAMP(CURDATE() - INTERVAL 364 DAY, '17:22:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (1,1,7,14.99,NULL);  -- Mate & Magic
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (2,1,12,59.99,NULL);  -- Cumbre FC 2026
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (2,20,4,TIMESTAMP(CURDATE() - INTERVAL 358 DAY, '19:26:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (3,2,27,19.99,NULL);  -- Neon Streets: Overdrive
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (4,2,24,15.99,NULL);  -- Polar Express Logistics
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (3,40,5,TIMESTAMP(CURDATE() - INTERVAL 355 DAY, '19:16:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (5,3,7,14.99,NULL);  -- Mate & Magic
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (4,24,4,TIMESTAMP(CURDATE() - INTERVAL 355 DAY, '20:25:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (6,4,27,19.99,NULL);  -- Neon Streets: Overdrive
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (5,38,5,TIMESTAMP(CURDATE() - INTERVAL 354 DAY, '23:16:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (7,5,24,15.99,NULL);  -- Polar Express Logistics
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (6,27,3,TIMESTAMP(CURDATE() - INTERVAL 353 DAY, '16:35:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (8,6,22,29.99,NULL);  -- Moonfire Siege
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (9,6,17,44.99,NULL);  -- Cyber Mate 2099
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (10,6,18,27.99,NULL);  -- Ronin Drift
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (33,'recarga',10,TIMESTAMP(CURDATE() - INTERVAL 352 DAY, '20:45:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (7,4,5,TIMESTAMP(CURDATE() - INTERVAL 351 DAY, '21:09:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (11,7,20,39.99,NULL);  -- Legends of the Southern Cross
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (12,7,3,19.99,NULL);  -- Galaxy Run
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (15,'recarga',10,TIMESTAMP(CURDATE() - INTERVAL 349 DAY, '09:08:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (8,5,4,TIMESTAMP(CURDATE() - INTERVAL 348 DAY, '23:57:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (13,8,20,39.99,NULL);  -- Legends of the Southern Cross
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (14,8,11,29.99,NULL);  -- Turbo Andes Rally
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (9,18,3,TIMESTAMP(CURDATE() - INTERVAL 346 DAY, '17:16:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (15,9,22,29.99,NULL);  -- Moonfire Siege
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (25,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 345 DAY, '12:40:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (30,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 345 DAY, '15:30:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (1,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 344 DAY, '11:43:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (10,15,1,TIMESTAMP(CURDATE() - INTERVAL 344 DAY, '23:58:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (16,10,6,4.99,NULL);  -- Pampa Truco Online
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (15,'compra_tienda',-4.99,TIMESTAMP(CURDATE() - INTERVAL 344 DAY, '23:58:00'),'Compra #10');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (11,36,2,TIMESTAMP(CURDATE() - INTERVAL 343 DAY, '12:06:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (17,11,28,11.99,NULL);  -- Void Miners
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (18,11,26,14.99,NULL);  -- Sakura Tennis Club
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (12,19,5,TIMESTAMP(CURDATE() - INTERVAL 343 DAY, '18:11:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (19,12,28,11.99,NULL);  -- Void Miners
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (13,25,5,TIMESTAMP(CURDATE() - INTERVAL 340 DAY, '14:27:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (20,13,28,11.99,NULL);  -- Void Miners
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (21,13,13,12.99,NULL);  -- Owl Post Tycoon
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (18,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 340 DAY, '21:37:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (14,22,2,TIMESTAMP(CURDATE() - INTERVAL 336 DAY, '12:34:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (22,14,20,39.99,NULL);  -- Legends of the Southern Cross
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (15,29,2,TIMESTAMP(CURDATE() - INTERVAL 333 DAY, '08:02:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (23,15,15,17.99,NULL);  -- Starlight Courier
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (13,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 333 DAY, '18:12:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (34,'recarga',100,TIMESTAMP(CURDATE() - INTERVAL 332 DAY, '15:35:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (16,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 332 DAY, '19:38:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (16,19,5,TIMESTAMP(CURDATE() - INTERVAL 332 DAY, '19:48:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (24,16,14,34.99,NULL);  -- Iron Kettle Tactics
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (25,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 332 DAY, '23:26:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (17,8,2,TIMESTAMP(CURDATE() - INTERVAL 331 DAY, '16:19:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (25,17,5,0.00,NULL);  -- Arena of Echoes
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (26,17,17,44.99,NULL);  -- Cyber Mate 2099
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (15,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 330 DAY, '11:10:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (18,7,5,TIMESTAMP(CURDATE() - INTERVAL 327 DAY, '08:34:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (27,18,25,39.99,NULL);  -- Shadow Quest II
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (19,36,5,TIMESTAMP(CURDATE() - INTERVAL 326 DAY, '08:17:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (28,19,5,0.00,NULL);  -- Arena of Echoes
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (29,19,18,27.99,NULL);  -- Ronin Drift
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (20,17,5,TIMESTAMP(CURDATE() - INTERVAL 321 DAY, '10:51:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (30,20,12,59.99,NULL);  -- Cumbre FC 2026
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (21,15,2,TIMESTAMP(CURDATE() - INTERVAL 319 DAY, '15:53:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (31,21,19,9.99,NULL);  -- Little Capybara Café
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (32,21,21,3.50,3);  -- Pixel Gaucho
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (22,34,1,TIMESTAMP(CURDATE() - INTERVAL 318 DAY, '17:05:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (33,22,20,39.99,NULL);  -- Legends of the Southern Cross
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (34,'compra_tienda',-39.99,TIMESTAMP(CURDATE() - INTERVAL 318 DAY, '17:05:00'),'Compra #22');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (9,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 318 DAY, '21:56:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (23,33,2,TIMESTAMP(CURDATE() - INTERVAL 313 DAY, '15:29:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (34,23,24,15.99,NULL);  -- Polar Express Logistics
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (24,11,5,TIMESTAMP(CURDATE() - INTERVAL 308 DAY, '11:32:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (35,24,26,14.99,NULL);  -- Sakura Tennis Club
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (25,40,5,TIMESTAMP(CURDATE() - INTERVAL 307 DAY, '08:30:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (36,25,2,49.99,NULL);  -- Neon Streets
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (37,25,27,19.99,NULL);  -- Neon Streets: Overdrive
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (26,22,3,TIMESTAMP(CURDATE() - INTERVAL 306 DAY, '16:14:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (38,26,9,24.99,NULL);  -- Hollow Lanterns
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (2,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 302 DAY, '19:20:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (27,39,3,TIMESTAMP(CURDATE() - INTERVAL 302 DAY, '23:08:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (39,27,5,0.00,NULL);  -- Arena of Echoes
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (28,10,2,TIMESTAMP(CURDATE() - INTERVAL 300 DAY, '13:46:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (40,28,23,19.99,NULL);  -- Spectral Manor
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (41,28,12,59.99,NULL);  -- Cumbre FC 2026
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (29,38,2,TIMESTAMP(CURDATE() - INTERVAL 299 DAY, '23:42:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (42,29,6,4.99,NULL);  -- Pampa Truco Online
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (43,29,23,19.99,NULL);  -- Spectral Manor
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (30,9,1,TIMESTAMP(CURDATE() - INTERVAL 296 DAY, '09:47:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (44,30,24,15.99,NULL);  -- Polar Express Logistics
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (9,'compra_tienda',-15.99,TIMESTAMP(CURDATE() - INTERVAL 296 DAY, '09:47:00'),'Compra #30');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (31,13,2,TIMESTAMP(CURDATE() - INTERVAL 295 DAY, '10:24:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (45,31,20,39.99,NULL);  -- Legends of the Southern Cross
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (46,31,16,21.99,NULL);  -- Deep Sea Echo
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (47,31,18,27.99,NULL);  -- Ronin Drift
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (32,38,5,TIMESTAMP(CURDATE() - INTERVAL 295 DAY, '18:21:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (48,32,9,24.99,NULL);  -- Hollow Lanterns
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (30,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 290 DAY, '08:40:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (27,'recarga',100,TIMESTAMP(CURDATE() - INTERVAL 289 DAY, '13:35:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (33,18,2,TIMESTAMP(CURDATE() - INTERVAL 287 DAY, '23:25:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (49,33,18,27.99,NULL);  -- Ronin Drift
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (29,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 286 DAY, '16:21:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (34,7,4,TIMESTAMP(CURDATE() - INTERVAL 286 DAY, '20:34:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (50,34,22,29.99,NULL);  -- Moonfire Siege
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (51,34,24,15.99,NULL);  -- Polar Express Logistics
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (35,25,1,TIMESTAMP(CURDATE() - INTERVAL 286 DAY, '23:58:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (52,35,11,29.99,NULL);  -- Turbo Andes Rally
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (25,'compra_tienda',-29.99,TIMESTAMP(CURDATE() - INTERVAL 286 DAY, '23:58:00'),'Compra #35');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (36,19,2,TIMESTAMP(CURDATE() - INTERVAL 281 DAY, '22:14:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (53,36,2,49.99,NULL);  -- Neon Streets
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (54,36,17,44.99,NULL);  -- Cyber Mate 2099
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (37,33,1,TIMESTAMP(CURDATE() - INTERVAL 280 DAY, '08:06:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (55,37,4,9.99,NULL);  -- Farm Legends
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (33,'compra_tienda',-9.99,TIMESTAMP(CURDATE() - INTERVAL 280 DAY, '08:06:00'),'Compra #37');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (38,18,3,TIMESTAMP(CURDATE() - INTERVAL 280 DAY, '18:27:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (56,38,25,39.99,NULL);  -- Shadow Quest II
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (57,38,29,24.99,NULL);  -- Capybara Kart
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (58,38,9,24.99,NULL);  -- Hollow Lanterns
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (39,38,5,TIMESTAMP(CURDATE() - INTERVAL 280 DAY, '18:53:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (59,39,7,14.99,NULL);  -- Mate & Magic
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (40,35,2,TIMESTAMP(CURDATE() - INTERVAL 280 DAY, '21:45:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (60,40,28,11.99,NULL);  -- Void Miners
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (19,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 274 DAY, '21:24:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (22,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 271 DAY, '12:14:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (41,12,2,TIMESTAMP(CURDATE() - INTERVAL 269 DAY, '19:04:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (61,41,22,29.99,NULL);  -- Moonfire Siege
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (62,41,14,34.99,NULL);  -- Iron Kettle Tactics
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (4,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 268 DAY, '09:59:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (42,15,1,TIMESTAMP(CURDATE() - INTERVAL 268 DAY, '11:22:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (63,42,9,24.99,NULL);  -- Hollow Lanterns
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (15,'compra_tienda',-24.99,TIMESTAMP(CURDATE() - INTERVAL 268 DAY, '11:22:00'),'Compra #42');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (43,23,2,TIMESTAMP(CURDATE() - INTERVAL 268 DAY, '18:09:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (64,43,7,14.99,NULL);  -- Mate & Magic
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (65,43,12,59.99,NULL);  -- Cumbre FC 2026
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (44,13,4,TIMESTAMP(CURDATE() - INTERVAL 266 DAY, '11:20:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (66,44,14,34.99,NULL);  -- Iron Kettle Tactics
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (67,44,27,19.99,NULL);  -- Neon Streets: Overdrive
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (17,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 266 DAY, '17:01:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (45,27,1,TIMESTAMP(CURDATE() - INTERVAL 264 DAY, '16:08:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (68,45,12,59.99,NULL);  -- Cumbre FC 2026
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (69,45,26,14.99,NULL);  -- Sakura Tennis Club
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (27,'compra_tienda',-74.98,TIMESTAMP(CURDATE() - INTERVAL 264 DAY, '16:08:00'),'Compra #45');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (46,7,5,TIMESTAMP(CURDATE() - INTERVAL 263 DAY, '11:57:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (70,46,21,6.99,NULL);  -- Pixel Gaucho
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (47,13,4,TIMESTAMP(CURDATE() - INTERVAL 263 DAY, '15:08:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (71,47,22,29.99,NULL);  -- Moonfire Siege
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (72,47,24,15.99,NULL);  -- Polar Express Logistics
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (48,11,5,TIMESTAMP(CURDATE() - INTERVAL 260 DAY, '08:56:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (73,48,7,14.99,NULL);  -- Mate & Magic
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (49,11,2,TIMESTAMP(CURDATE() - INTERVAL 256 DAY, '08:11:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (74,49,4,9.99,NULL);  -- Farm Legends
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (21,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 256 DAY, '12:11:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (50,30,5,TIMESTAMP(CURDATE() - INTERVAL 256 DAY, '15:40:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (75,50,23,19.99,NULL);  -- Spectral Manor
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (51,25,1,TIMESTAMP(CURDATE() - INTERVAL 255 DAY, '21:21:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (76,51,4,9.99,NULL);  -- Farm Legends
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (25,'compra_tienda',-9.99,TIMESTAMP(CURDATE() - INTERVAL 255 DAY, '21:21:00'),'Compra #51');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (52,38,5,TIMESTAMP(CURDATE() - INTERVAL 252 DAY, '19:20:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (77,52,17,44.99,NULL);  -- Cyber Mate 2099
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (78,52,10,59.99,NULL);  -- Kitsune Blade
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (79,52,1,29.99,NULL);  -- Shadow Quest
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (53,23,5,TIMESTAMP(CURDATE() - INTERVAL 251 DAY, '11:17:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (80,53,23,19.99,NULL);  -- Spectral Manor
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (54,24,5,TIMESTAMP(CURDATE() - INTERVAL 249 DAY, '08:35:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (81,54,10,59.99,NULL);  -- Kitsune Blade
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (15,'recarga',100,TIMESTAMP(CURDATE() - INTERVAL 249 DAY, '11:07:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (55,16,1,TIMESTAMP(CURDATE() - INTERVAL 247 DAY, '19:05:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (82,55,13,12.99,NULL);  -- Owl Post Tycoon
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (16,'compra_tienda',-12.99,TIMESTAMP(CURDATE() - INTERVAL 247 DAY, '19:05:00'),'Compra #55');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (56,13,3,TIMESTAMP(CURDATE() - INTERVAL 246 DAY, '12:38:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (83,56,17,44.99,NULL);  -- Cyber Mate 2099
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (84,56,9,24.99,NULL);  -- Hollow Lanterns
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (57,20,2,TIMESTAMP(CURDATE() - INTERVAL 246 DAY, '20:13:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (85,57,5,0.00,NULL);  -- Arena of Echoes
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (86,57,4,9.99,NULL);  -- Farm Legends
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (58,28,4,TIMESTAMP(CURDATE() - INTERVAL 246 DAY, '23:21:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (87,58,8,39.99,NULL);  -- Frostbound Kingdoms
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (88,58,12,59.99,NULL);  -- Cumbre FC 2026
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (59,39,5,TIMESTAMP(CURDATE() - INTERVAL 243 DAY, '16:02:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (89,59,21,6.99,NULL);  -- Pixel Gaucho
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (90,59,22,29.99,NULL);  -- Moonfire Siege
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (60,18,3,TIMESTAMP(CURDATE() - INTERVAL 241 DAY, '15:10:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (91,60,27,19.99,NULL);  -- Neon Streets: Overdrive
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (61,15,1,TIMESTAMP(CURDATE() - INTERVAL 241 DAY, '22:58:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (92,61,26,14.99,NULL);  -- Sakura Tennis Club
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (15,'compra_tienda',-14.99,TIMESTAMP(CURDATE() - INTERVAL 241 DAY, '22:58:00'),'Compra #61');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (9,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 240 DAY, '19:03:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (62,24,5,TIMESTAMP(CURDATE() - INTERVAL 239 DAY, '18:43:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (93,62,13,12.99,NULL);  -- Owl Post Tycoon
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (94,62,19,9.99,NULL);  -- Little Capybara Café
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (11,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 236 DAY, '11:19:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (63,8,3,TIMESTAMP(CURDATE() - INTERVAL 235 DAY, '12:46:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (95,63,4,9.99,NULL);  -- Farm Legends
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (96,63,29,24.99,NULL);  -- Capybara Kart
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (64,26,2,TIMESTAMP(CURDATE() - INTERVAL 235 DAY, '20:46:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (97,64,2,49.99,NULL);  -- Neon Streets
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (65,18,5,TIMESTAMP(CURDATE() - INTERVAL 234 DAY, '23:49:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (98,65,2,49.99,NULL);  -- Neon Streets
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (99,65,3,19.99,NULL);  -- Galaxy Run
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (66,32,4,TIMESTAMP(CURDATE() - INTERVAL 232 DAY, '14:34:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (100,66,19,9.99,NULL);  -- Little Capybara Café
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (101,66,4,9.99,NULL);  -- Farm Legends
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (67,27,4,TIMESTAMP(CURDATE() - INTERVAL 232 DAY, '21:53:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (102,67,23,19.99,NULL);  -- Spectral Manor
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (103,67,16,21.99,NULL);  -- Deep Sea Echo
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (104,67,24,15.99,NULL);  -- Polar Express Logistics
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (22,'recarga',10,TIMESTAMP(CURDATE() - INTERVAL 229 DAY, '16:50:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (10,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 224 DAY, '18:18:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (68,25,3,TIMESTAMP(CURDATE() - INTERVAL 223 DAY, '11:43:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (105,68,1,29.99,NULL);  -- Shadow Quest
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (106,68,6,4.99,NULL);  -- Pampa Truco Online
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (69,20,2,TIMESTAMP(CURDATE() - INTERVAL 222 DAY, '12:27:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (107,69,1,29.99,NULL);  -- Shadow Quest
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (70,15,1,TIMESTAMP(CURDATE() - INTERVAL 220 DAY, '19:43:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (108,70,3,19.99,NULL);  -- Galaxy Run
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (109,70,7,14.99,NULL);  -- Mate & Magic
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (15,'compra_tienda',-34.98,TIMESTAMP(CURDATE() - INTERVAL 220 DAY, '19:43:00'),'Compra #70');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (71,11,5,TIMESTAMP(CURDATE() - INTERVAL 218 DAY, '12:10:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (110,71,1,29.99,NULL);  -- Shadow Quest
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (72,28,5,TIMESTAMP(CURDATE() - INTERVAL 218 DAY, '23:54:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (111,72,27,19.99,NULL);  -- Neon Streets: Overdrive
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (73,10,3,TIMESTAMP(CURDATE() - INTERVAL 217 DAY, '08:54:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (112,73,4,9.99,NULL);  -- Farm Legends
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (113,73,26,14.99,NULL);  -- Sakura Tennis Club
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (74,12,2,TIMESTAMP(CURDATE() - INTERVAL 216 DAY, '14:34:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (114,74,5,0.00,NULL);  -- Arena of Echoes
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (115,74,10,59.99,NULL);  -- Kitsune Blade
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (116,74,17,44.99,NULL);  -- Cyber Mate 2099
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (75,31,4,TIMESTAMP(CURDATE() - INTERVAL 211 DAY, '08:49:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (117,75,23,19.99,NULL);  -- Spectral Manor
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (25,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 210 DAY, '16:20:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (76,20,3,TIMESTAMP(CURDATE() - INTERVAL 206 DAY, '12:28:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (118,76,11,29.99,NULL);  -- Turbo Andes Rally
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (119,76,16,21.99,NULL);  -- Deep Sea Echo
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (120,76,20,39.99,NULL);  -- Legends of the Southern Cross
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (77,10,2,TIMESTAMP(CURDATE() - INTERVAL 205 DAY, '19:51:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (121,77,2,49.99,NULL);  -- Neon Streets
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (122,77,18,27.99,NULL);  -- Ronin Drift
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (78,12,2,TIMESTAMP(CURDATE() - INTERVAL 204 DAY, '08:53:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (123,78,7,14.99,NULL);  -- Mate & Magic
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (124,78,19,9.99,NULL);  -- Little Capybara Café
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (79,5,4,TIMESTAMP(CURDATE() - INTERVAL 204 DAY, '09:40:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (125,79,21,6.99,NULL);  -- Pixel Gaucho
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (4,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 201 DAY, '22:38:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (4,'recarga',10,TIMESTAMP(CURDATE() - INTERVAL 194 DAY, '20:20:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (80,6,5,TIMESTAMP(CURDATE() - INTERVAL 193 DAY, '16:08:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (126,80,13,12.99,NULL);  -- Owl Post Tycoon
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (127,80,16,21.99,NULL);  -- Deep Sea Echo
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (81,30,4,TIMESTAMP(CURDATE() - INTERVAL 190 DAY, '11:42:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (128,81,16,21.99,NULL);  -- Deep Sea Echo
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (82,9,2,TIMESTAMP(CURDATE() - INTERVAL 189 DAY, '12:24:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (129,82,2,49.99,NULL);  -- Neon Streets
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (130,82,19,9.99,NULL);  -- Little Capybara Café
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (131,82,17,44.99,NULL);  -- Cyber Mate 2099
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (83,9,5,TIMESTAMP(CURDATE() - INTERVAL 187 DAY, '14:47:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (132,83,10,59.99,NULL);  -- Kitsune Blade
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (84,23,4,TIMESTAMP(CURDATE() - INTERVAL 185 DAY, '17:36:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (133,84,10,59.99,NULL);  -- Kitsune Blade
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (33,'recarga',100,TIMESTAMP(CURDATE() - INTERVAL 184 DAY, '19:50:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (85,6,5,TIMESTAMP(CURDATE() - INTERVAL 183 DAY, '17:23:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (134,85,21,6.99,NULL);  -- Pixel Gaucho
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (135,85,1,29.99,NULL);  -- Shadow Quest
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (136,85,12,59.99,NULL);  -- Cumbre FC 2026
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (86,36,2,TIMESTAMP(CURDATE() - INTERVAL 183 DAY, '21:02:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (137,86,7,14.99,NULL);  -- Mate & Magic
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (138,86,19,9.99,NULL);  -- Little Capybara Café
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (6,'recarga',10,TIMESTAMP(CURDATE() - INTERVAL 182 DAY, '11:43:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (87,6,5,TIMESTAMP(CURDATE() - INTERVAL 179 DAY, '13:05:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (139,87,15,17.99,NULL);  -- Starlight Courier
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (140,87,8,39.99,NULL);  -- Frostbound Kingdoms
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (6,'recarga',100,TIMESTAMP(CURDATE() - INTERVAL 179 DAY, '22:27:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (88,7,2,TIMESTAMP(CURDATE() - INTERVAL 175 DAY, '17:36:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (141,88,18,27.99,NULL);  -- Ronin Drift
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (8,'recarga',100,TIMESTAMP(CURDATE() - INTERVAL 169 DAY, '19:55:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (8,'recarga',10,TIMESTAMP(CURDATE() - INTERVAL 168 DAY, '17:52:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (89,26,2,TIMESTAMP(CURDATE() - INTERVAL 163 DAY, '18:03:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (142,89,14,34.99,NULL);  -- Iron Kettle Tactics
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (143,89,27,19.99,NULL);  -- Neon Streets: Overdrive
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (90,5,4,TIMESTAMP(CURDATE() - INTERVAL 161 DAY, '08:22:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (144,90,29,24.99,NULL);  -- Capybara Kart
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (91,37,2,TIMESTAMP(CURDATE() - INTERVAL 161 DAY, '15:58:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (145,91,1,29.99,NULL);  -- Shadow Quest
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (146,91,8,39.99,NULL);  -- Frostbound Kingdoms
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (92,9,2,TIMESTAMP(CURDATE() - INTERVAL 159 DAY, '14:10:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (147,92,13,12.99,NULL);  -- Owl Post Tycoon
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (93,19,2,TIMESTAMP(CURDATE() - INTERVAL 158 DAY, '14:51:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (148,93,10,59.99,NULL);  -- Kitsune Blade
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (149,93,13,12.99,NULL);  -- Owl Post Tycoon
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (8,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 157 DAY, '16:24:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (94,8,2,TIMESTAMP(CURDATE() - INTERVAL 150 DAY, '13:32:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (150,94,8,39.99,NULL);  -- Frostbound Kingdoms
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (21,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 149 DAY, '08:42:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (95,8,5,TIMESTAMP(CURDATE() - INTERVAL 148 DAY, '11:05:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (151,95,27,19.99,NULL);  -- Neon Streets: Overdrive
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (36,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 143 DAY, '16:21:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (22,'recarga',10,TIMESTAMP(CURDATE() - INTERVAL 142 DAY, '08:01:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (19,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 141 DAY, '12:22:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (96,21,1,TIMESTAMP(CURDATE() - INTERVAL 138 DAY, '11:20:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (152,96,4,9.99,NULL);  -- Farm Legends
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (153,96,29,24.99,NULL);  -- Capybara Kart
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (21,'compra_tienda',-34.98,TIMESTAMP(CURDATE() - INTERVAL 138 DAY, '11:20:00'),'Compra #96');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (97,27,5,TIMESTAMP(CURDATE() - INTERVAL 133 DAY, '18:37:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (154,97,2,29.99,4);  -- Neon Streets
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (155,97,13,12.99,NULL);  -- Owl Post Tycoon
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (156,97,19,5.99,4);  -- Little Capybara Café
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (98,12,5,TIMESTAMP(CURDATE() - INTERVAL 133 DAY, '19:19:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (157,98,2,29.99,4);  -- Neon Streets
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (158,98,9,14.99,4);  -- Hollow Lanterns
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (159,98,28,11.99,NULL);  -- Void Miners
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (37,'recarga',10,TIMESTAMP(CURDATE() - INTERVAL 133 DAY, '22:35:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (39,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 133 DAY, '23:57:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (99,18,2,TIMESTAMP(CURDATE() - INTERVAL 129 DAY, '18:20:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (160,99,4,9.99,NULL);  -- Farm Legends
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (161,99,13,12.99,NULL);  -- Owl Post Tycoon
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (100,33,1,TIMESTAMP(CURDATE() - INTERVAL 127 DAY, '13:45:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (162,100,22,29.99,NULL);  -- Moonfire Siege
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (33,'compra_tienda',-29.99,TIMESTAMP(CURDATE() - INTERVAL 127 DAY, '13:45:00'),'Compra #100');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (11,'recarga',100,TIMESTAMP(CURDATE() - INTERVAL 121 DAY, '21:20:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (23,'recarga',10,TIMESTAMP(CURDATE() - INTERVAL 120 DAY, '16:34:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (101,16,1,TIMESTAMP(CURDATE() - INTERVAL 118 DAY, '10:49:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (163,101,1,29.99,NULL);  -- Shadow Quest
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (16,'compra_tienda',-29.99,TIMESTAMP(CURDATE() - INTERVAL 118 DAY, '10:49:00'),'Compra #101');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (29,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 111 DAY, '18:03:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (102,5,2,TIMESTAMP(CURDATE() - INTERVAL 108 DAY, '21:50:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (164,102,2,49.99,NULL);  -- Neon Streets
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (165,102,17,44.99,NULL);  -- Cyber Mate 2099
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (166,102,9,24.99,NULL);  -- Hollow Lanterns
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (103,20,5,TIMESTAMP(CURDATE() - INTERVAL 104 DAY, '16:21:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (167,103,25,39.99,NULL);  -- Shadow Quest II
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (168,103,9,24.99,NULL);  -- Hollow Lanterns
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (169,103,29,24.99,NULL);  -- Capybara Kart
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (104,23,2,TIMESTAMP(CURDATE() - INTERVAL 103 DAY, '22:40:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (170,104,22,29.99,NULL);  -- Moonfire Siege
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (171,104,21,6.99,NULL);  -- Pixel Gaucho
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (105,33,1,TIMESTAMP(CURDATE() - INTERVAL 102 DAY, '14:38:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (172,105,2,49.99,NULL);  -- Neon Streets
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (173,105,19,9.99,NULL);  -- Little Capybara Café
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (33,'compra_tienda',-59.98,TIMESTAMP(CURDATE() - INTERVAL 102 DAY, '14:38:00'),'Compra #105');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (20,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 97 DAY, '21:42:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (21,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 92 DAY, '20:56:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (20,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 91 DAY, '15:49:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (33,'recarga',10,TIMESTAMP(CURDATE() - INTERVAL 89 DAY, '12:59:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (37,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 84 DAY, '19:29:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (27,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 82 DAY, '10:53:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (9,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 80 DAY, '08:18:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (106,31,2,TIMESTAMP(CURDATE() - INTERVAL 75 DAY, '14:50:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (174,106,13,12.99,NULL);  -- Owl Post Tycoon
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (175,106,15,17.99,NULL);  -- Starlight Courier
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (107,8,1,TIMESTAMP(CURDATE() - INTERVAL 73 DAY, '20:21:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (176,107,2,49.99,NULL);  -- Neon Streets
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (8,'compra_tienda',-49.99,TIMESTAMP(CURDATE() - INTERVAL 73 DAY, '20:21:00'),'Compra #107');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (108,38,4,TIMESTAMP(CURDATE() - INTERVAL 70 DAY, '23:56:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (177,108,26,14.99,NULL);  -- Sakura Tennis Club
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (178,108,4,9.99,NULL);  -- Farm Legends
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (109,14,2,TIMESTAMP(CURDATE() - INTERVAL 67 DAY, '16:39:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (179,109,20,39.99,NULL);  -- Legends of the Southern Cross
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (180,109,6,4.99,NULL);  -- Pampa Truco Online
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (181,109,8,39.99,NULL);  -- Frostbound Kingdoms
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (110,11,4,TIMESTAMP(CURDATE() - INTERVAL 60 DAY, '18:34:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (182,110,10,59.99,NULL);  -- Kitsune Blade
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (183,110,20,39.99,NULL);  -- Legends of the Southern Cross
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (28,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 58 DAY, '09:41:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (31,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 53 DAY, '09:14:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (111,15,4,TIMESTAMP(CURDATE() - INTERVAL 53 DAY, '23:07:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (184,111,28,11.99,NULL);  -- Void Miners
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (112,26,3,TIMESTAMP(CURDATE() - INTERVAL 51 DAY, '13:00:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (185,112,1,29.99,NULL);  -- Shadow Quest
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (39,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 51 DAY, '13:40:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (113,30,5,TIMESTAMP(CURDATE() - INTERVAL 50 DAY, '16:20:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (186,113,26,14.99,NULL);  -- Sakura Tennis Club
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (114,32,4,TIMESTAMP(CURDATE() - INTERVAL 48 DAY, '16:39:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (187,114,27,19.99,NULL);  -- Neon Streets: Overdrive
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (188,114,9,24.99,NULL);  -- Hollow Lanterns
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (115,10,2,TIMESTAMP(CURDATE() - INTERVAL 47 DAY, '23:27:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (189,115,7,14.99,NULL);  -- Mate & Magic
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (190,115,28,11.99,NULL);  -- Void Miners
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (191,115,14,34.99,NULL);  -- Iron Kettle Tactics
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (116,7,2,TIMESTAMP(CURDATE() - INTERVAL 46 DAY, '09:25:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (192,116,19,9.99,NULL);  -- Little Capybara Café
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (193,116,4,9.99,NULL);  -- Farm Legends
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (1,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 45 DAY, '17:07:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (117,33,1,TIMESTAMP(CURDATE() - INTERVAL 43 DAY, '12:21:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (194,117,15,17.99,NULL);  -- Starlight Courier
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (33,'compra_tienda',-17.99,TIMESTAMP(CURDATE() - INTERVAL 43 DAY, '12:21:00'),'Compra #117');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (19,'recarga',50,TIMESTAMP(CURDATE() - INTERVAL 42 DAY, '20:15:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (118,7,5,TIMESTAMP(CURDATE() - INTERVAL 40 DAY, '14:54:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (195,118,17,44.99,NULL);  -- Cyber Mate 2099
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (196,118,28,11.99,NULL);  -- Void Miners
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (197,118,15,17.99,NULL);  -- Starlight Courier
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (6,'recarga',10,TIMESTAMP(CURDATE() - INTERVAL 39 DAY, '14:38:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (36,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 34 DAY, '14:23:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (119,14,3,TIMESTAMP(CURDATE() - INTERVAL 26 DAY, '17:41:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (198,119,13,12.99,NULL);  -- Owl Post Tycoon
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (199,119,19,9.99,NULL);  -- Little Capybara Café
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (13,'recarga',100,TIMESTAMP(CURDATE() - INTERVAL 25 DAY, '09:46:00'),'Recarga de saldo');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (13,'recarga',20,TIMESTAMP(CURDATE() - INTERVAL 19 DAY, '08:34:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (120,25,1,TIMESTAMP(CURDATE() - INTERVAL 18 DAY, '19:41:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (200,120,27,19.99,NULL);  -- Neon Streets: Overdrive
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (25,'compra_tienda',-19.99,TIMESTAMP(CURDATE() - INTERVAL 18 DAY, '19:41:00'),'Compra #120');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (121,21,1,TIMESTAMP(CURDATE() - INTERVAL 17 DAY, '22:16:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (201,121,10,59.99,NULL);  -- Kitsune Blade
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (202,121,9,24.99,NULL);  -- Hollow Lanterns
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (203,121,5,0.00,NULL);  -- Arena of Echoes
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (21,'compra_tienda',-84.98,TIMESTAMP(CURDATE() - INTERVAL 17 DAY, '22:16:00'),'Compra #121');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (122,9,1,TIMESTAMP(CURDATE() - INTERVAL 13 DAY, '17:18:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (204,122,15,17.99,NULL);  -- Starlight Courier
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (9,'compra_tienda',-17.99,TIMESTAMP(CURDATE() - INTERVAL 13 DAY, '17:18:00'),'Compra #122');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (123,13,1,TIMESTAMP(CURDATE() - INTERVAL 13 DAY, '23:06:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (205,123,28,11.99,NULL);  -- Void Miners
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (206,123,6,4.99,NULL);  -- Pampa Truco Online
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (13,'compra_tienda',-16.98,TIMESTAMP(CURDATE() - INTERVAL 13 DAY, '23:06:00'),'Compra #123');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (39,'recarga',10,TIMESTAMP(CURDATE() - INTERVAL 9 DAY, '17:12:00'),'Recarga de saldo');
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (124,32,5,TIMESTAMP(CURDATE() - INTERVAL 8 DAY, '22:32:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (207,124,1,29.99,NULL);  -- Shadow Quest
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (208,124,13,12.99,NULL);  -- Owl Post Tycoon
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (125,1,2,TIMESTAMP(CURDATE() - INTERVAL 6 DAY, '20:15:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (209,125,3,19.99,NULL);  -- Galaxy Run
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (126,21,4,TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '16:53:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (210,126,27,19.99,NULL);  -- Neon Streets: Overdrive
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (127,1,2,TIMESTAMP(CURDATE() - INTERVAL 4 DAY, '20:15:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (211,127,1,29.99,NULL);  -- Shadow Quest
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (128,37,5,TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '13:35:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (212,128,5,0.00,NULL);  -- Arena of Echoes
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (213,128,10,59.99,NULL);  -- Kitsune Blade
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (129,2,3,TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '20:15:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (214,129,2,32.49,2);  -- Neon Streets
INSERT INTO Compras (id_compra,id_usuario,id_metodo_pago,fecha_compra) VALUES (130,32,5,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '19:05:00'));
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (215,130,8,25.99,2);  -- Frostbound Kingdoms
INSERT INTO Detalle_Compra (id_detalle,id_compra,id_juego,precio_pagado,id_promocion) VALUES (216,130,25,31.99,1);  -- Shadow Quest II

-- Horas jugadas de cada juego en la biblioteca
UPDATE Biblioteca SET horas_jugadas = 107.1 WHERE id_usuario = 1 AND id_juego = 3;
UPDATE Biblioteca SET horas_jugadas = 133.0 WHERE id_usuario = 1 AND id_juego = 1;
UPDATE Biblioteca SET horas_jugadas = 0.9 WHERE id_usuario = 2 AND id_juego = 2;
UPDATE Biblioteca SET horas_jugadas = 166.2 WHERE id_usuario = 4 AND id_juego = 20;
UPDATE Biblioteca SET horas_jugadas = 45.6 WHERE id_usuario = 4 AND id_juego = 3;
UPDATE Biblioteca SET horas_jugadas = 92.8 WHERE id_usuario = 5 AND id_juego = 20;
UPDATE Biblioteca SET horas_jugadas = 9.1 WHERE id_usuario = 5 AND id_juego = 11;
UPDATE Biblioteca SET horas_jugadas = 59.2 WHERE id_usuario = 5 AND id_juego = 21;
UPDATE Biblioteca SET horas_jugadas = 94.3 WHERE id_usuario = 5 AND id_juego = 29;
UPDATE Biblioteca SET horas_jugadas = 123.2 WHERE id_usuario = 5 AND id_juego = 2;
UPDATE Biblioteca SET horas_jugadas = 106.2 WHERE id_usuario = 5 AND id_juego = 17;
UPDATE Biblioteca SET horas_jugadas = 103.6 WHERE id_usuario = 5 AND id_juego = 9;
UPDATE Biblioteca SET horas_jugadas = 154.8 WHERE id_usuario = 6 AND id_juego = 13;
UPDATE Biblioteca SET horas_jugadas = 156.3 WHERE id_usuario = 6 AND id_juego = 16;
UPDATE Biblioteca SET horas_jugadas = 110.7 WHERE id_usuario = 6 AND id_juego = 21;
UPDATE Biblioteca SET horas_jugadas = 96.1 WHERE id_usuario = 6 AND id_juego = 1;
UPDATE Biblioteca SET horas_jugadas = 54.0 WHERE id_usuario = 6 AND id_juego = 12;
UPDATE Biblioteca SET horas_jugadas = 39.4 WHERE id_usuario = 6 AND id_juego = 15;
UPDATE Biblioteca SET horas_jugadas = 168.0 WHERE id_usuario = 6 AND id_juego = 8;
UPDATE Biblioteca SET horas_jugadas = 62.4 WHERE id_usuario = 7 AND id_juego = 25;
UPDATE Biblioteca SET horas_jugadas = 69.6 WHERE id_usuario = 7 AND id_juego = 22;
UPDATE Biblioteca SET horas_jugadas = 155.8 WHERE id_usuario = 7 AND id_juego = 24;
UPDATE Biblioteca SET horas_jugadas = 76.4 WHERE id_usuario = 7 AND id_juego = 21;
UPDATE Biblioteca SET horas_jugadas = 131.7 WHERE id_usuario = 7 AND id_juego = 18;
UPDATE Biblioteca SET horas_jugadas = 173.1 WHERE id_usuario = 7 AND id_juego = 19;
UPDATE Biblioteca SET horas_jugadas = 98.3 WHERE id_usuario = 7 AND id_juego = 4;
UPDATE Biblioteca SET horas_jugadas = 111.2 WHERE id_usuario = 7 AND id_juego = 17;
UPDATE Biblioteca SET horas_jugadas = 94.1 WHERE id_usuario = 7 AND id_juego = 28;
UPDATE Biblioteca SET horas_jugadas = 112.1 WHERE id_usuario = 7 AND id_juego = 15;
UPDATE Biblioteca SET horas_jugadas = 8.9 WHERE id_usuario = 8 AND id_juego = 5;
UPDATE Biblioteca SET horas_jugadas = 108.4 WHERE id_usuario = 8 AND id_juego = 17;
UPDATE Biblioteca SET horas_jugadas = 18.7 WHERE id_usuario = 8 AND id_juego = 4;
UPDATE Biblioteca SET horas_jugadas = 124.2 WHERE id_usuario = 8 AND id_juego = 29;
UPDATE Biblioteca SET horas_jugadas = 109.2 WHERE id_usuario = 8 AND id_juego = 8;
UPDATE Biblioteca SET horas_jugadas = 62.4 WHERE id_usuario = 8 AND id_juego = 27;
UPDATE Biblioteca SET horas_jugadas = 155.8 WHERE id_usuario = 8 AND id_juego = 2;
UPDATE Biblioteca SET horas_jugadas = 70.9 WHERE id_usuario = 9 AND id_juego = 7;
UPDATE Biblioteca SET horas_jugadas = 109.3 WHERE id_usuario = 9 AND id_juego = 12;
UPDATE Biblioteca SET horas_jugadas = 78.7 WHERE id_usuario = 9 AND id_juego = 24;
UPDATE Biblioteca SET horas_jugadas = 134.1 WHERE id_usuario = 9 AND id_juego = 2;
UPDATE Biblioteca SET horas_jugadas = 109.9 WHERE id_usuario = 9 AND id_juego = 19;
UPDATE Biblioteca SET horas_jugadas = 34.7 WHERE id_usuario = 9 AND id_juego = 17;
UPDATE Biblioteca SET horas_jugadas = 76.9 WHERE id_usuario = 9 AND id_juego = 10;
UPDATE Biblioteca SET horas_jugadas = 157.3 WHERE id_usuario = 9 AND id_juego = 13;
UPDATE Biblioteca SET horas_jugadas = 143.5 WHERE id_usuario = 9 AND id_juego = 15;
UPDATE Biblioteca SET horas_jugadas = 64.8 WHERE id_usuario = 10 AND id_juego = 23;
UPDATE Biblioteca SET horas_jugadas = 71.6 WHERE id_usuario = 10 AND id_juego = 12;
UPDATE Biblioteca SET horas_jugadas = 154.5 WHERE id_usuario = 10 AND id_juego = 4;
UPDATE Biblioteca SET horas_jugadas = 109.4 WHERE id_usuario = 10 AND id_juego = 26;
UPDATE Biblioteca SET horas_jugadas = 75.4 WHERE id_usuario = 10 AND id_juego = 2;
UPDATE Biblioteca SET horas_jugadas = 115.0 WHERE id_usuario = 10 AND id_juego = 18;
UPDATE Biblioteca SET horas_jugadas = 33.8 WHERE id_usuario = 10 AND id_juego = 7;
UPDATE Biblioteca SET horas_jugadas = 128.3 WHERE id_usuario = 10 AND id_juego = 28;
UPDATE Biblioteca SET horas_jugadas = 168.5 WHERE id_usuario = 10 AND id_juego = 14;
UPDATE Biblioteca SET horas_jugadas = 53.2 WHERE id_usuario = 11 AND id_juego = 26;
UPDATE Biblioteca SET horas_jugadas = 19.7 WHERE id_usuario = 11 AND id_juego = 7;
UPDATE Biblioteca SET horas_jugadas = 14.3 WHERE id_usuario = 11 AND id_juego = 4;
UPDATE Biblioteca SET horas_jugadas = 64.6 WHERE id_usuario = 11 AND id_juego = 1;
UPDATE Biblioteca SET horas_jugadas = 48.9 WHERE id_usuario = 11 AND id_juego = 10;
UPDATE Biblioteca SET horas_jugadas = 55.8 WHERE id_usuario = 11 AND id_juego = 20;
UPDATE Biblioteca SET horas_jugadas = 8.0 WHERE id_usuario = 12 AND id_juego = 22;
UPDATE Biblioteca SET horas_jugadas = 17.5 WHERE id_usuario = 12 AND id_juego = 14;
UPDATE Biblioteca SET horas_jugadas = 142.9 WHERE id_usuario = 12 AND id_juego = 5;
UPDATE Biblioteca SET horas_jugadas = 48.3 WHERE id_usuario = 12 AND id_juego = 10;
UPDATE Biblioteca SET horas_jugadas = 144.8 WHERE id_usuario = 12 AND id_juego = 17;
UPDATE Biblioteca SET horas_jugadas = 105.1 WHERE id_usuario = 12 AND id_juego = 7;
UPDATE Biblioteca SET horas_jugadas = 112.2 WHERE id_usuario = 12 AND id_juego = 19;
UPDATE Biblioteca SET horas_jugadas = 77.8 WHERE id_usuario = 12 AND id_juego = 2;
UPDATE Biblioteca SET horas_jugadas = 84.5 WHERE id_usuario = 12 AND id_juego = 9;
UPDATE Biblioteca SET horas_jugadas = 69.3 WHERE id_usuario = 12 AND id_juego = 28;
UPDATE Biblioteca SET horas_jugadas = 113.0 WHERE id_usuario = 13 AND id_juego = 20;
UPDATE Biblioteca SET horas_jugadas = 163.9 WHERE id_usuario = 13 AND id_juego = 16;
UPDATE Biblioteca SET horas_jugadas = 154.1 WHERE id_usuario = 13 AND id_juego = 18;
UPDATE Biblioteca SET horas_jugadas = 109.3 WHERE id_usuario = 13 AND id_juego = 14;
UPDATE Biblioteca SET horas_jugadas = 115.4 WHERE id_usuario = 13 AND id_juego = 27;
UPDATE Biblioteca SET horas_jugadas = 59.5 WHERE id_usuario = 13 AND id_juego = 22;
UPDATE Biblioteca SET horas_jugadas = 161.8 WHERE id_usuario = 13 AND id_juego = 24;
UPDATE Biblioteca SET horas_jugadas = 88.7 WHERE id_usuario = 13 AND id_juego = 17;
UPDATE Biblioteca SET horas_jugadas = 108.0 WHERE id_usuario = 13 AND id_juego = 9;
UPDATE Biblioteca SET horas_jugadas = 15.2 WHERE id_usuario = 13 AND id_juego = 28;
UPDATE Biblioteca SET horas_jugadas = 0.4 WHERE id_usuario = 13 AND id_juego = 6;
UPDATE Biblioteca SET horas_jugadas = 143.3 WHERE id_usuario = 14 AND id_juego = 20;
UPDATE Biblioteca SET horas_jugadas = 23.1 WHERE id_usuario = 14 AND id_juego = 6;
UPDATE Biblioteca SET horas_jugadas = 61.2 WHERE id_usuario = 14 AND id_juego = 8;
UPDATE Biblioteca SET horas_jugadas = 53.8 WHERE id_usuario = 14 AND id_juego = 13;
UPDATE Biblioteca SET horas_jugadas = 21.7 WHERE id_usuario = 14 AND id_juego = 19;
UPDATE Biblioteca SET horas_jugadas = 37.2 WHERE id_usuario = 15 AND id_juego = 6;
UPDATE Biblioteca SET horas_jugadas = 114.2 WHERE id_usuario = 15 AND id_juego = 19;
UPDATE Biblioteca SET horas_jugadas = 97.4 WHERE id_usuario = 15 AND id_juego = 21;
UPDATE Biblioteca SET horas_jugadas = 20.5 WHERE id_usuario = 15 AND id_juego = 9;
UPDATE Biblioteca SET horas_jugadas = 143.7 WHERE id_usuario = 15 AND id_juego = 26;
UPDATE Biblioteca SET horas_jugadas = 95.5 WHERE id_usuario = 15 AND id_juego = 3;
UPDATE Biblioteca SET horas_jugadas = 77.9 WHERE id_usuario = 15 AND id_juego = 7;
UPDATE Biblioteca SET horas_jugadas = 156.0 WHERE id_usuario = 15 AND id_juego = 28;
UPDATE Biblioteca SET horas_jugadas = 100.9 WHERE id_usuario = 16 AND id_juego = 13;
UPDATE Biblioteca SET horas_jugadas = 78.9 WHERE id_usuario = 16 AND id_juego = 1;
UPDATE Biblioteca SET horas_jugadas = 177.2 WHERE id_usuario = 17 AND id_juego = 12;
UPDATE Biblioteca SET horas_jugadas = 112.8 WHERE id_usuario = 18 AND id_juego = 22;
UPDATE Biblioteca SET horas_jugadas = 101.8 WHERE id_usuario = 18 AND id_juego = 18;
UPDATE Biblioteca SET horas_jugadas = 112.2 WHERE id_usuario = 18 AND id_juego = 25;
UPDATE Biblioteca SET horas_jugadas = 86.4 WHERE id_usuario = 18 AND id_juego = 29;
UPDATE Biblioteca SET horas_jugadas = 147.0 WHERE id_usuario = 18 AND id_juego = 9;
UPDATE Biblioteca SET horas_jugadas = 179.7 WHERE id_usuario = 18 AND id_juego = 27;
UPDATE Biblioteca SET horas_jugadas = 178.5 WHERE id_usuario = 18 AND id_juego = 2;
UPDATE Biblioteca SET horas_jugadas = 80.9 WHERE id_usuario = 18 AND id_juego = 3;
UPDATE Biblioteca SET horas_jugadas = 21.4 WHERE id_usuario = 18 AND id_juego = 4;
UPDATE Biblioteca SET horas_jugadas = 68.6 WHERE id_usuario = 18 AND id_juego = 13;
UPDATE Biblioteca SET horas_jugadas = 105.5 WHERE id_usuario = 19 AND id_juego = 28;
UPDATE Biblioteca SET horas_jugadas = 57.0 WHERE id_usuario = 19 AND id_juego = 14;
UPDATE Biblioteca SET horas_jugadas = 7.7 WHERE id_usuario = 19 AND id_juego = 2;
UPDATE Biblioteca SET horas_jugadas = 44.4 WHERE id_usuario = 19 AND id_juego = 17;
UPDATE Biblioteca SET horas_jugadas = 46.3 WHERE id_usuario = 19 AND id_juego = 10;
UPDATE Biblioteca SET horas_jugadas = 165.4 WHERE id_usuario = 19 AND id_juego = 13;
UPDATE Biblioteca SET horas_jugadas = 116.9 WHERE id_usuario = 20 AND id_juego = 27;
UPDATE Biblioteca SET horas_jugadas = 72.5 WHERE id_usuario = 20 AND id_juego = 24;
UPDATE Biblioteca SET horas_jugadas = 24.6 WHERE id_usuario = 20 AND id_juego = 5;
UPDATE Biblioteca SET horas_jugadas = 64.0 WHERE id_usuario = 20 AND id_juego = 4;
UPDATE Biblioteca SET horas_jugadas = 129.0 WHERE id_usuario = 20 AND id_juego = 1;
UPDATE Biblioteca SET horas_jugadas = 125.8 WHERE id_usuario = 20 AND id_juego = 11;
UPDATE Biblioteca SET horas_jugadas = 67.3 WHERE id_usuario = 20 AND id_juego = 16;
UPDATE Biblioteca SET horas_jugadas = 136.1 WHERE id_usuario = 20 AND id_juego = 20;
UPDATE Biblioteca SET horas_jugadas = 66.1 WHERE id_usuario = 20 AND id_juego = 25;
UPDATE Biblioteca SET horas_jugadas = 137.5 WHERE id_usuario = 20 AND id_juego = 9;
UPDATE Biblioteca SET horas_jugadas = 71.1 WHERE id_usuario = 20 AND id_juego = 29;
UPDATE Biblioteca SET horas_jugadas = 59.0 WHERE id_usuario = 21 AND id_juego = 4;
UPDATE Biblioteca SET horas_jugadas = 166.0 WHERE id_usuario = 21 AND id_juego = 29;
UPDATE Biblioteca SET horas_jugadas = 23.2 WHERE id_usuario = 21 AND id_juego = 10;
UPDATE Biblioteca SET horas_jugadas = 179.7 WHERE id_usuario = 21 AND id_juego = 9;
UPDATE Biblioteca SET horas_jugadas = 163.6 WHERE id_usuario = 21 AND id_juego = 5;
UPDATE Biblioteca SET horas_jugadas = 0.4 WHERE id_usuario = 21 AND id_juego = 27;
UPDATE Biblioteca SET horas_jugadas = 90.7 WHERE id_usuario = 22 AND id_juego = 20;
UPDATE Biblioteca SET horas_jugadas = 92.3 WHERE id_usuario = 22 AND id_juego = 9;
UPDATE Biblioteca SET horas_jugadas = 41.1 WHERE id_usuario = 23 AND id_juego = 7;
UPDATE Biblioteca SET horas_jugadas = 24.4 WHERE id_usuario = 23 AND id_juego = 12;
UPDATE Biblioteca SET horas_jugadas = 147.8 WHERE id_usuario = 23 AND id_juego = 23;
UPDATE Biblioteca SET horas_jugadas = 8.5 WHERE id_usuario = 23 AND id_juego = 10;
UPDATE Biblioteca SET horas_jugadas = 64.8 WHERE id_usuario = 23 AND id_juego = 22;
UPDATE Biblioteca SET horas_jugadas = 47.1 WHERE id_usuario = 23 AND id_juego = 21;
UPDATE Biblioteca SET horas_jugadas = 56.3 WHERE id_usuario = 24 AND id_juego = 27;
UPDATE Biblioteca SET horas_jugadas = 157.7 WHERE id_usuario = 24 AND id_juego = 10;
UPDATE Biblioteca SET horas_jugadas = 77.7 WHERE id_usuario = 24 AND id_juego = 13;
UPDATE Biblioteca SET horas_jugadas = 170.6 WHERE id_usuario = 24 AND id_juego = 19;
UPDATE Biblioteca SET horas_jugadas = 81.5 WHERE id_usuario = 25 AND id_juego = 28;
UPDATE Biblioteca SET horas_jugadas = 69.1 WHERE id_usuario = 25 AND id_juego = 13;
UPDATE Biblioteca SET horas_jugadas = 156.0 WHERE id_usuario = 25 AND id_juego = 11;
UPDATE Biblioteca SET horas_jugadas = 29.2 WHERE id_usuario = 25 AND id_juego = 4;
UPDATE Biblioteca SET horas_jugadas = 78.5 WHERE id_usuario = 25 AND id_juego = 1;
UPDATE Biblioteca SET horas_jugadas = 14.7 WHERE id_usuario = 25 AND id_juego = 6;
UPDATE Biblioteca SET horas_jugadas = 76.8 WHERE id_usuario = 25 AND id_juego = 27;
UPDATE Biblioteca SET horas_jugadas = 77.6 WHERE id_usuario = 26 AND id_juego = 2;
UPDATE Biblioteca SET horas_jugadas = 80.9 WHERE id_usuario = 26 AND id_juego = 14;
UPDATE Biblioteca SET horas_jugadas = 66.0 WHERE id_usuario = 26 AND id_juego = 27;
UPDATE Biblioteca SET horas_jugadas = 128.5 WHERE id_usuario = 26 AND id_juego = 1;
UPDATE Biblioteca SET horas_jugadas = 174.8 WHERE id_usuario = 27 AND id_juego = 22;
UPDATE Biblioteca SET horas_jugadas = 125.6 WHERE id_usuario = 27 AND id_juego = 17;
UPDATE Biblioteca SET horas_jugadas = 64.2 WHERE id_usuario = 27 AND id_juego = 18;
UPDATE Biblioteca SET horas_jugadas = 178.9 WHERE id_usuario = 27 AND id_juego = 12;
UPDATE Biblioteca SET horas_jugadas = 113.7 WHERE id_usuario = 27 AND id_juego = 26;
UPDATE Biblioteca SET horas_jugadas = 135.1 WHERE id_usuario = 27 AND id_juego = 23;
UPDATE Biblioteca SET horas_jugadas = 179.6 WHERE id_usuario = 27 AND id_juego = 16;
UPDATE Biblioteca SET horas_jugadas = 74.9 WHERE id_usuario = 27 AND id_juego = 24;
UPDATE Biblioteca SET horas_jugadas = 115.7 WHERE id_usuario = 27 AND id_juego = 2;
UPDATE Biblioteca SET horas_jugadas = 119.8 WHERE id_usuario = 27 AND id_juego = 13;
UPDATE Biblioteca SET horas_jugadas = 74.6 WHERE id_usuario = 27 AND id_juego = 19;
UPDATE Biblioteca SET horas_jugadas = 29.0 WHERE id_usuario = 28 AND id_juego = 8;
UPDATE Biblioteca SET horas_jugadas = 85.3 WHERE id_usuario = 28 AND id_juego = 12;
UPDATE Biblioteca SET horas_jugadas = 32.5 WHERE id_usuario = 28 AND id_juego = 27;
UPDATE Biblioteca SET horas_jugadas = 13.0 WHERE id_usuario = 29 AND id_juego = 15;
UPDATE Biblioteca SET horas_jugadas = 63.2 WHERE id_usuario = 30 AND id_juego = 23;
UPDATE Biblioteca SET horas_jugadas = 57.7 WHERE id_usuario = 30 AND id_juego = 16;
UPDATE Biblioteca SET horas_jugadas = 2.9 WHERE id_usuario = 30 AND id_juego = 26;
UPDATE Biblioteca SET horas_jugadas = 142.0 WHERE id_usuario = 31 AND id_juego = 23;
UPDATE Biblioteca SET horas_jugadas = 85.2 WHERE id_usuario = 31 AND id_juego = 13;
UPDATE Biblioteca SET horas_jugadas = 109.6 WHERE id_usuario = 31 AND id_juego = 15;
UPDATE Biblioteca SET horas_jugadas = 13.4 WHERE id_usuario = 32 AND id_juego = 19;
UPDATE Biblioteca SET horas_jugadas = 86.9 WHERE id_usuario = 32 AND id_juego = 4;
UPDATE Biblioteca SET horas_jugadas = 41.2 WHERE id_usuario = 32 AND id_juego = 27;
UPDATE Biblioteca SET horas_jugadas = 16.3 WHERE id_usuario = 32 AND id_juego = 9;
UPDATE Biblioteca SET horas_jugadas = 1.2 WHERE id_usuario = 32 AND id_juego = 1;
UPDATE Biblioteca SET horas_jugadas = 0.9 WHERE id_usuario = 32 AND id_juego = 13;
UPDATE Biblioteca SET horas_jugadas = 0.6 WHERE id_usuario = 32 AND id_juego = 8;
UPDATE Biblioteca SET horas_jugadas = 0.4 WHERE id_usuario = 32 AND id_juego = 25;
UPDATE Biblioteca SET horas_jugadas = 170.5 WHERE id_usuario = 33 AND id_juego = 24;
UPDATE Biblioteca SET horas_jugadas = 33.5 WHERE id_usuario = 33 AND id_juego = 4;
UPDATE Biblioteca SET horas_jugadas = 148.7 WHERE id_usuario = 33 AND id_juego = 22;
UPDATE Biblioteca SET horas_jugadas = 87.7 WHERE id_usuario = 33 AND id_juego = 2;
UPDATE Biblioteca SET horas_jugadas = 66.4 WHERE id_usuario = 33 AND id_juego = 19;
UPDATE Biblioteca SET horas_jugadas = 20.8 WHERE id_usuario = 33 AND id_juego = 15;
UPDATE Biblioteca SET horas_jugadas = 149.7 WHERE id_usuario = 34 AND id_juego = 20;
UPDATE Biblioteca SET horas_jugadas = 36.1 WHERE id_usuario = 35 AND id_juego = 28;
UPDATE Biblioteca SET horas_jugadas = 32.6 WHERE id_usuario = 36 AND id_juego = 28;
UPDATE Biblioteca SET horas_jugadas = 78.9 WHERE id_usuario = 36 AND id_juego = 26;
UPDATE Biblioteca SET horas_jugadas = 55.4 WHERE id_usuario = 36 AND id_juego = 5;
UPDATE Biblioteca SET horas_jugadas = 76.0 WHERE id_usuario = 36 AND id_juego = 18;
UPDATE Biblioteca SET horas_jugadas = 133.6 WHERE id_usuario = 36 AND id_juego = 7;
UPDATE Biblioteca SET horas_jugadas = 156.8 WHERE id_usuario = 36 AND id_juego = 19;
UPDATE Biblioteca SET horas_jugadas = 171.6 WHERE id_usuario = 37 AND id_juego = 1;
UPDATE Biblioteca SET horas_jugadas = 57.8 WHERE id_usuario = 37 AND id_juego = 8;
UPDATE Biblioteca SET horas_jugadas = 71.4 WHERE id_usuario = 37 AND id_juego = 5;
UPDATE Biblioteca SET horas_jugadas = 98.9 WHERE id_usuario = 38 AND id_juego = 24;
UPDATE Biblioteca SET horas_jugadas = 41.6 WHERE id_usuario = 38 AND id_juego = 6;
UPDATE Biblioteca SET horas_jugadas = 77.3 WHERE id_usuario = 38 AND id_juego = 23;
UPDATE Biblioteca SET horas_jugadas = 144.6 WHERE id_usuario = 38 AND id_juego = 9;
UPDATE Biblioteca SET horas_jugadas = 79.8 WHERE id_usuario = 38 AND id_juego = 7;
UPDATE Biblioteca SET horas_jugadas = 113.9 WHERE id_usuario = 38 AND id_juego = 17;
UPDATE Biblioteca SET horas_jugadas = 20.2 WHERE id_usuario = 38 AND id_juego = 10;
UPDATE Biblioteca SET horas_jugadas = 21.2 WHERE id_usuario = 38 AND id_juego = 1;
UPDATE Biblioteca SET horas_jugadas = 54.7 WHERE id_usuario = 38 AND id_juego = 26;
UPDATE Biblioteca SET horas_jugadas = 175.7 WHERE id_usuario = 38 AND id_juego = 4;
UPDATE Biblioteca SET horas_jugadas = 150.1 WHERE id_usuario = 39 AND id_juego = 5;
UPDATE Biblioteca SET horas_jugadas = 154.2 WHERE id_usuario = 39 AND id_juego = 21;
UPDATE Biblioteca SET horas_jugadas = 20.2 WHERE id_usuario = 39 AND id_juego = 22;
UPDATE Biblioteca SET horas_jugadas = 111.9 WHERE id_usuario = 40 AND id_juego = 7;
UPDATE Biblioteca SET horas_jugadas = 120.5 WHERE id_usuario = 40 AND id_juego = 2;
UPDATE Biblioteca SET horas_jugadas = 172.3 WHERE id_usuario = 40 AND id_juego = 27;

-- ---------- Reembolsos: el trigger decide 'aprobado' (<=14 días y <2 h) o 'en_revision'
INSERT INTO Reembolsos (id_reembolso,id_detalle,motivo,fecha_solicitud,destino) VALUES (1,214,'Compra original del script v1',TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '23:30:00'),'billetera');
INSERT INTO Reembolsos (id_reembolso,id_detalle,motivo,fecha_solicitud,destino) VALUES (2,207,'Compré por error',TIMESTAMP(CURDATE() - INTERVAL 7 DAY, '23:30:00'),'billetera');
INSERT INTO Reembolsos (id_reembolso,id_detalle,motivo,fecha_solicitud,destino) VALUES (3,210,'Problemas con el control',TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '23:30:00'),'medio_original');
INSERT INTO Reembolsos (id_reembolso,id_detalle,motivo,fecha_solicitud,destino) VALUES (4,208,'Rendimiento malo en mi PC',TIMESTAMP(CURDATE() - INTERVAL 6 DAY, '23:30:00'),'medio_original');
INSERT INTO Reembolsos (id_reembolso,id_detalle,motivo,fecha_solicitud,destino) VALUES (5,206,'Compré por error',TIMESTAMP(CURDATE() - INTERVAL 11 DAY, '23:30:00'),'billetera');
INSERT INTO Reembolsos (id_reembolso,id_detalle,motivo,fecha_solicitud,destino) VALUES (6,213,'Compré por error',TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '23:30:00'),'medio_original');
INSERT INTO Reembolsos (id_reembolso,id_detalle,motivo,fecha_solicitud,destino) VALUES (7,216,'Problemas con el control',TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '23:30:00'),'billetera');
INSERT INTO Reembolsos (id_reembolso,id_detalle,motivo,fecha_solicitud,destino) VALUES (8,182,'Lo compré hace mucho y no lo jugué',TIMESTAMP(CURDATE() - INTERVAL 41 DAY, '10:05:00'),'medio_original');
INSERT INTO Reembolsos (id_reembolso,id_detalle,motivo,fecha_solicitud,destino) VALUES (9,192,'El juego tiene bugs graves',TIMESTAMP(CURDATE() - INTERVAL 30 DAY, '10:05:00'),'medio_original');
INSERT INTO Reembolsos (id_reembolso,id_detalle,motivo,fecha_solicitud,destino) VALUES (10,194,'Se cerraba al iniciar',TIMESTAMP(CURDATE() - INTERVAL 27 DAY, '10:05:00'),'billetera');
INSERT INTO Reembolsos (id_reembolso,id_detalle,motivo,fecha_solicitud,destino) VALUES (11,189,'Cambió mucho con la última actualización',TIMESTAMP(CURDATE() - INTERVAL 28 DAY, '10:05:00'),'medio_original');
INSERT INTO Reembolsos (id_reembolso,id_detalle,motivo,fecha_solicitud,destino) VALUES (12,197,'Compra duplicada',TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '10:05:00'),'medio_original');
INSERT INTO Reembolsos (id_reembolso,id_detalle,motivo,fecha_solicitud,destino) VALUES (13,198,'Problemas de servidor',TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '10:05:00'),'medio_original');
-- Decisiones de un administrador sobre los que quedaron en revisión
UPDATE Reembolsos SET estado = 'aprobado' WHERE id_reembolso = 8;  -- un admin lo aprobó (excepción)
UPDATE Reembolsos SET estado = 'aprobado' WHERE id_reembolso = 9;  -- un admin lo aprobó (excepción)
UPDATE Reembolsos SET estado = 'rechazado' WHERE id_reembolso = 10;
UPDATE Reembolsos SET estado = 'rechazado' WHERE id_reembolso = 11;
UPDATE Reembolsos SET estado = 'rechazado' WHERE id_reembolso = 12;

-- ---------- Reseñas (solo de juegos que están en la biblioteca)
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (1,1,TRUE,'La historia me atrapó',NOW() - INTERVAL 1 HOUR);
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (4,3,FALSE,'Demasiado corto para lo que sale',TIMESTAMP(CURDATE() - INTERVAL 338 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (5,20,TRUE,'El online funciona perfecto',TIMESTAMP(CURDATE() - INTERVAL 336 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (5,21,TRUE,'Gráficos hermosos y buena música',TIMESTAMP(CURDATE() - INTERVAL 191 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (5,29,TRUE,'Corre bien en PC modesta',TIMESTAMP(CURDATE() - INTERVAL 153 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (5,2,TRUE,'Muy recomendable, lo terminé dos veces',TIMESTAMP(CURDATE() - INTERVAL 106 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (5,17,TRUE,'Buen precio en oferta',TIMESTAMP(CURDATE() - INTERVAL 103 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (5,9,TRUE,'Excelente para jugar con amigos',TIMESTAMP(CURDATE() - INTERVAL 103 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (6,16,TRUE,'Adictivo, cuidado con las horas',TIMESTAMP(CURDATE() - INTERVAL 184 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (6,12,TRUE,'Excelente para jugar con amigos',TIMESTAMP(CURDATE() - INTERVAL 178 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (6,15,TRUE,'Adictivo, cuidado con las horas',TIMESTAMP(CURDATE() - INTERVAL 171 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (6,8,TRUE,'El online funciona perfecto',TIMESTAMP(CURDATE() - INTERVAL 173 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (7,25,TRUE,'Gráficos hermosos y buena música',TIMESTAMP(CURDATE() - INTERVAL 324 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (7,21,TRUE,'Buen precio en oferta',TIMESTAMP(CURDATE() - INTERVAL 249 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (7,15,TRUE,'Excelente para jugar con amigos',TIMESTAMP(CURDATE() - INTERVAL 25 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (8,5,TRUE,'Corre bien en PC modesta',TIMESTAMP(CURDATE() - INTERVAL 320 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (8,17,TRUE,'La historia me atrapó',TIMESTAMP(CURDATE() - INTERVAL 326 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (8,2,TRUE,'Buen precio en oferta',TIMESTAMP(CURDATE() - INTERVAL 58 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (9,24,FALSE,'Muchos bugs todavía',TIMESTAMP(CURDATE() - INTERVAL 292 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (9,19,TRUE,'Corre bien en PC modesta',TIMESTAMP(CURDATE() - INTERVAL 180 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (9,15,FALSE,'El final me decepcionó',TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (10,4,TRUE,'Adictivo, cuidado con las horas',TIMESTAMP(CURDATE() - INTERVAL 211 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (10,26,FALSE,'Mala optimización',TIMESTAMP(CURDATE() - INTERVAL 208 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (10,2,TRUE,'Excelente para jugar con amigos',TIMESTAMP(CURDATE() - INTERVAL 191 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (10,14,FALSE,'Mala optimización',TIMESTAMP(CURDATE() - INTERVAL 46 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (11,26,TRUE,'El online funciona perfecto',TIMESTAMP(CURDATE() - INTERVAL 297 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (11,7,TRUE,'Adictivo, cuidado con las horas',TIMESTAMP(CURDATE() - INTERVAL 249 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (11,1,TRUE,'Buen precio en oferta',TIMESTAMP(CURDATE() - INTERVAL 214 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (11,20,TRUE,'Muy recomendable, lo terminé dos veces',TIMESTAMP(CURDATE() - INTERVAL 49 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (12,22,TRUE,'El online funciona perfecto',TIMESTAMP(CURDATE() - INTERVAL 260 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (12,14,TRUE,'La historia me atrapó',TIMESTAMP(CURDATE() - INTERVAL 256 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (12,17,TRUE,'Gráficos hermosos y buena música',TIMESTAMP(CURDATE() - INTERVAL 209 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (12,7,TRUE,'Buen precio en oferta',TIMESTAMP(CURDATE() - INTERVAL 197 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (12,19,TRUE,'Buen precio en oferta',TIMESTAMP(CURDATE() - INTERVAL 198 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (13,27,FALSE,'Microtransacciones por todos lados',TIMESTAMP(CURDATE() - INTERVAL 254 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (13,9,TRUE,'Buen precio en oferta',TIMESTAMP(CURDATE() - INTERVAL 242 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (15,26,FALSE,'Microtransacciones por todos lados',TIMESTAMP(CURDATE() - INTERVAL 233 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (15,7,TRUE,'Corre bien en PC modesta',TIMESTAMP(CURDATE() - INTERVAL 211 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (16,13,TRUE,'Gráficos hermosos y buena música',TIMESTAMP(CURDATE() - INTERVAL 236 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (16,1,TRUE,'La historia me atrapó',TIMESTAMP(CURDATE() - INTERVAL 104 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (17,12,TRUE,'Adictivo, cuidado con las horas',TIMESTAMP(CURDATE() - INTERVAL 311 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (18,18,TRUE,'Gráficos hermosos y buena música',TIMESTAMP(CURDATE() - INTERVAL 286 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (18,9,TRUE,'Excelente para jugar con amigos',TIMESTAMP(CURDATE() - INTERVAL 272 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (18,2,FALSE,'Muchos bugs todavía',TIMESTAMP(CURDATE() - INTERVAL 227 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (18,3,FALSE,'Microtransacciones por todos lados',TIMESTAMP(CURDATE() - INTERVAL 224 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (18,4,TRUE,'Muy recomendable, lo terminé dos veces',TIMESTAMP(CURDATE() - INTERVAL 128 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (18,13,FALSE,'Muchos bugs todavía',TIMESTAMP(CURDATE() - INTERVAL 117 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (19,2,TRUE,'Muy recomendable, lo terminé dos veces',TIMESTAMP(CURDATE() - INTERVAL 268 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (19,10,TRUE,'La historia me atrapó',TIMESTAMP(CURDATE() - INTERVAL 154 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (20,24,TRUE,'Muy recomendable, lo terminé dos veces',TIMESTAMP(CURDATE() - INTERVAL 354 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (20,5,FALSE,'El final me decepcionó',TIMESTAMP(CURDATE() - INTERVAL 238 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (20,11,TRUE,'Corre bien en PC modesta',TIMESTAMP(CURDATE() - INTERVAL 194 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (20,25,TRUE,'Excelente para jugar con amigos',TIMESTAMP(CURDATE() - INTERVAL 102 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (20,9,TRUE,'Buen precio en oferta',TIMESTAMP(CURDATE() - INTERVAL 95 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (21,4,TRUE,'Buen precio en oferta',TIMESTAMP(CURDATE() - INTERVAL 127 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (21,29,TRUE,'Corre bien en PC modesta',TIMESTAMP(CURDATE() - INTERVAL 135 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (21,10,TRUE,'Corre bien en PC modesta',TIMESTAMP(CURDATE() - INTERVAL 15 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (21,5,TRUE,'Buen precio en oferta',TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (22,9,FALSE,'El final me decepcionó',TIMESTAMP(CURDATE() - INTERVAL 299 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (23,7,TRUE,'La historia me atrapó',TIMESTAMP(CURDATE() - INTERVAL 255 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (23,10,TRUE,'El online funciona perfecto',TIMESTAMP(CURDATE() - INTERVAL 179 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (23,21,TRUE,'Buen precio en oferta',TIMESTAMP(CURDATE() - INTERVAL 100 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (25,28,TRUE,'El online funciona perfecto',TIMESTAMP(CURDATE() - INTERVAL 337 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (25,11,TRUE,'Excelente para jugar con amigos',TIMESTAMP(CURDATE() - INTERVAL 280 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (25,4,TRUE,'Excelente para jugar con amigos',TIMESTAMP(CURDATE() - INTERVAL 240 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (26,27,TRUE,'Adictivo, cuidado con las horas',TIMESTAMP(CURDATE() - INTERVAL 148 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (26,1,TRUE,'Adictivo, cuidado con las horas',TIMESTAMP(CURDATE() - INTERVAL 47 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (27,22,TRUE,'La historia me atrapó',TIMESTAMP(CURDATE() - INTERVAL 340 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (27,26,TRUE,'La historia me atrapó',TIMESTAMP(CURDATE() - INTERVAL 262 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (27,23,TRUE,'La historia me atrapó',TIMESTAMP(CURDATE() - INTERVAL 217 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (27,16,TRUE,'Corre bien en PC modesta',TIMESTAMP(CURDATE() - INTERVAL 220 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (27,24,TRUE,'La historia me atrapó',TIMESTAMP(CURDATE() - INTERVAL 219 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (28,12,TRUE,'La historia me atrapó',TIMESTAMP(CURDATE() - INTERVAL 231 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (29,15,TRUE,'Gráficos hermosos y buena música',TIMESTAMP(CURDATE() - INTERVAL 332 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (30,23,TRUE,'El online funciona perfecto',TIMESTAMP(CURDATE() - INTERVAL 252 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (30,26,FALSE,'Mala optimización',TIMESTAMP(CURDATE() - INTERVAL 37 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (31,13,TRUE,'Excelente para jugar con amigos',TIMESTAMP(CURDATE() - INTERVAL 60 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (32,27,TRUE,'Excelente para jugar con amigos',TIMESTAMP(CURDATE() - INTERVAL 42 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (33,22,TRUE,'Adictivo, cuidado con las horas',TIMESTAMP(CURDATE() - INTERVAL 124 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (33,19,TRUE,'Corre bien en PC modesta',TIMESTAMP(CURDATE() - INTERVAL 90 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (34,20,TRUE,'La historia me atrapó',TIMESTAMP(CURDATE() - INTERVAL 309 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (36,28,TRUE,'La historia me atrapó',TIMESTAMP(CURDATE() - INTERVAL 334 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (36,26,FALSE,'Muchos bugs todavía',TIMESTAMP(CURDATE() - INTERVAL 336 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (36,5,TRUE,'Corre bien en PC modesta',TIMESTAMP(CURDATE() - INTERVAL 320 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (36,18,TRUE,'La historia me atrapó',TIMESTAMP(CURDATE() - INTERVAL 323 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (36,7,TRUE,'Corre bien en PC modesta',TIMESTAMP(CURDATE() - INTERVAL 170 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (37,1,TRUE,'El online funciona perfecto',TIMESTAMP(CURDATE() - INTERVAL 158 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (37,8,TRUE,'Adictivo, cuidado con las horas',TIMESTAMP(CURDATE() - INTERVAL 155 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (37,5,TRUE,'Adictivo, cuidado con las horas',NOW() - INTERVAL 1 HOUR);
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (38,24,TRUE,'Muy recomendable, lo terminé dos veces',TIMESTAMP(CURDATE() - INTERVAL 341 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (38,6,FALSE,'El final me decepcionó',TIMESTAMP(CURDATE() - INTERVAL 287 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (38,10,TRUE,'Gráficos hermosos y buena música',TIMESTAMP(CURDATE() - INTERVAL 249 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (38,1,TRUE,'Corre bien en PC modesta',TIMESTAMP(CURDATE() - INTERVAL 250 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (38,26,TRUE,'Corre bien en PC modesta',TIMESTAMP(CURDATE() - INTERVAL 60 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (39,5,TRUE,'Buen precio en oferta',TIMESTAMP(CURDATE() - INTERVAL 297 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (39,21,TRUE,'Muy recomendable, lo terminé dos veces',TIMESTAMP(CURDATE() - INTERVAL 239 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (39,22,TRUE,'Excelente para jugar con amigos',TIMESTAMP(CURDATE() - INTERVAL 240 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (40,7,TRUE,'Excelente para jugar con amigos',TIMESTAMP(CURDATE() - INTERVAL 349 DAY, '21:00:00'));
INSERT INTO Resenas (id_usuario,id_juego,recomendado,texto,fecha) VALUES (40,2,TRUE,'Gráficos hermosos y buena música',TIMESTAMP(CURDATE() - INTERVAL 304 DAY, '21:00:00'));

INSERT INTO Lista_Deseados (id_usuario,id_juego,fecha_agregado) VALUES
(1,9,TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '12:00:00')),
(1,12,TIMESTAMP(CURDATE() - INTERVAL 136 DAY, '12:00:00')),
(1,6,TIMESTAMP(CURDATE() - INTERVAL 35 DAY, '12:00:00')),
(1,21,TIMESTAMP(CURDATE() - INTERVAL 55 DAY, '12:00:00')),
(2,13,TIMESTAMP(CURDATE() - INTERVAL 59 DAY, '12:00:00')),
(2,24,TIMESTAMP(CURDATE() - INTERVAL 96 DAY, '12:00:00')),
(2,21,TIMESTAMP(CURDATE() - INTERVAL 34 DAY, '12:00:00')),
(2,3,TIMESTAMP(CURDATE() - INTERVAL 188 DAY, '12:00:00')),
(5,7,TIMESTAMP(CURDATE() - INTERVAL 45 DAY, '12:00:00')),
(6,30,TIMESTAMP(CURDATE() - INTERVAL 134 DAY, '12:00:00')),
(7,8,TIMESTAMP(CURDATE() - INTERVAL 119 DAY, '12:00:00')),
(7,20,TIMESTAMP(CURDATE() - INTERVAL 125 DAY, '12:00:00')),
(7,26,TIMESTAMP(CURDATE() - INTERVAL 102 DAY, '12:00:00')),
(9,1,TIMESTAMP(CURDATE() - INTERVAL 79 DAY, '12:00:00')),
(9,20,TIMESTAMP(CURDATE() - INTERVAL 44 DAY, '12:00:00')),
(10,19,TIMESTAMP(CURDATE() - INTERVAL 177 DAY, '12:00:00')),
(10,24,TIMESTAMP(CURDATE() - INTERVAL 84 DAY, '12:00:00')),
(11,27,TIMESTAMP(CURDATE() - INTERVAL 66 DAY, '12:00:00')),
(11,8,TIMESTAMP(CURDATE() - INTERVAL 36 DAY, '12:00:00')),
(12,23,TIMESTAMP(CURDATE() - INTERVAL 163 DAY, '12:00:00')),
(12,15,TIMESTAMP(CURDATE() - INTERVAL 181 DAY, '12:00:00')),
(12,4,TIMESTAMP(CURDATE() - INTERVAL 41 DAY, '12:00:00')),
(13,23,TIMESTAMP(CURDATE() - INTERVAL 104 DAY, '12:00:00')),
(13,11,TIMESTAMP(CURDATE() - INTERVAL 103 DAY, '12:00:00')),
(13,10,TIMESTAMP(CURDATE() - INTERVAL 11 DAY, '12:00:00')),
(13,21,TIMESTAMP(CURDATE() - INTERVAL 71 DAY, '12:00:00')),
(14,3,TIMESTAMP(CURDATE() - INTERVAL 59 DAY, '12:00:00')),
(14,10,TIMESTAMP(CURDATE() - INTERVAL 101 DAY, '12:00:00')),
(14,25,TIMESTAMP(CURDATE() - INTERVAL 186 DAY, '12:00:00')),
(16,12,TIMESTAMP(CURDATE() - INTERVAL 73 DAY, '12:00:00')),
(16,2,TIMESTAMP(CURDATE() - INTERVAL 148 DAY, '12:00:00')),
(17,13,TIMESTAMP(CURDATE() - INTERVAL 147 DAY, '12:00:00')),
(17,16,TIMESTAMP(CURDATE() - INTERVAL 106 DAY, '12:00:00')),
(17,1,TIMESTAMP(CURDATE() - INTERVAL 13 DAY, '12:00:00')),
(18,20,TIMESTAMP(CURDATE() - INTERVAL 179 DAY, '12:00:00')),
(18,14,TIMESTAMP(CURDATE() - INTERVAL 57 DAY, '12:00:00')),
(19,8,TIMESTAMP(CURDATE() - INTERVAL 131 DAY, '12:00:00')),
(20,10,TIMESTAMP(CURDATE() - INTERVAL 119 DAY, '12:00:00')),
(20,19,TIMESTAMP(CURDATE() - INTERVAL 28 DAY, '12:00:00')),
(20,23,TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '12:00:00')),
(21,30,TIMESTAMP(CURDATE() - INTERVAL 66 DAY, '12:00:00')),
(21,24,TIMESTAMP(CURDATE() - INTERVAL 74 DAY, '12:00:00')),
(21,17,TIMESTAMP(CURDATE() - INTERVAL 103 DAY, '12:00:00')),
(21,14,TIMESTAMP(CURDATE() - INTERVAL 154 DAY, '12:00:00')),
(22,28,TIMESTAMP(CURDATE() - INTERVAL 12 DAY, '12:00:00')),
(22,29,TIMESTAMP(CURDATE() - INTERVAL 63 DAY, '12:00:00')),
(23,6,TIMESTAMP(CURDATE() - INTERVAL 107 DAY, '12:00:00')),
(23,1,TIMESTAMP(CURDATE() - INTERVAL 139 DAY, '12:00:00')),
(23,14,TIMESTAMP(CURDATE() - INTERVAL 63 DAY, '12:00:00')),
(24,16,TIMESTAMP(CURDATE() - INTERVAL 100 DAY, '12:00:00')),
(26,13,TIMESTAMP(CURDATE() - INTERVAL 152 DAY, '12:00:00')),
(26,16,TIMESTAMP(CURDATE() - INTERVAL 98 DAY, '12:00:00')),
(26,20,TIMESTAMP(CURDATE() - INTERVAL 91 DAY, '12:00:00')),
(28,26,TIMESTAMP(CURDATE() - INTERVAL 15 DAY, '12:00:00')),
(28,11,TIMESTAMP(CURDATE() - INTERVAL 128 DAY, '12:00:00')),
(28,20,TIMESTAMP(CURDATE() - INTERVAL 144 DAY, '12:00:00')),
(29,6,TIMESTAMP(CURDATE() - INTERVAL 64 DAY, '12:00:00')),
(29,2,TIMESTAMP(CURDATE() - INTERVAL 147 DAY, '12:00:00')),
(29,23,TIMESTAMP(CURDATE() - INTERVAL 111 DAY, '12:00:00')),
(29,30,TIMESTAMP(CURDATE() - INTERVAL 44 DAY, '12:00:00')),
(30,2,TIMESTAMP(CURDATE() - INTERVAL 149 DAY, '12:00:00')),
(31,17,TIMESTAMP(CURDATE() - INTERVAL 64 DAY, '12:00:00')),
(31,16,TIMESTAMP(CURDATE() - INTERVAL 186 DAY, '12:00:00')),
(31,21,TIMESTAMP(CURDATE() - INTERVAL 184 DAY, '12:00:00')),
(31,11,TIMESTAMP(CURDATE() - INTERVAL 158 DAY, '12:00:00')),
(32,3,TIMESTAMP(CURDATE() - INTERVAL 7 DAY, '12:00:00')),
(32,5,TIMESTAMP(CURDATE() - INTERVAL 200 DAY, '12:00:00')),
(32,1,TIMESTAMP(CURDATE() - INTERVAL 146 DAY, '12:00:00')),
(33,26,TIMESTAMP(CURDATE() - INTERVAL 6 DAY, '12:00:00')),
(33,20,TIMESTAMP(CURDATE() - INTERVAL 8 DAY, '12:00:00')),
(33,17,TIMESTAMP(CURDATE() - INTERVAL 46 DAY, '12:00:00')),
(33,28,TIMESTAMP(CURDATE() - INTERVAL 194 DAY, '12:00:00')),
(34,27,TIMESTAMP(CURDATE() - INTERVAL 4 DAY, '12:00:00')),
(34,5,TIMESTAMP(CURDATE() - INTERVAL 127 DAY, '12:00:00')),
(34,6,TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '12:00:00')),
(34,29,TIMESTAMP(CURDATE() - INTERVAL 23 DAY, '12:00:00')),
(35,20,TIMESTAMP(CURDATE() - INTERVAL 67 DAY, '12:00:00')),
(35,5,TIMESTAMP(CURDATE() - INTERVAL 80 DAY, '12:00:00')),
(35,17,TIMESTAMP(CURDATE() - INTERVAL 48 DAY, '12:00:00')),
(36,21,TIMESTAMP(CURDATE() - INTERVAL 180 DAY, '12:00:00')),
(36,6,TIMESTAMP(CURDATE() - INTERVAL 98 DAY, '12:00:00')),
(36,2,TIMESTAMP(CURDATE() - INTERVAL 188 DAY, '12:00:00')),
(37,12,TIMESTAMP(CURDATE() - INTERVAL 69 DAY, '12:00:00')),
(38,5,TIMESTAMP(CURDATE() - INTERVAL 120 DAY, '12:00:00')),
(39,10,TIMESTAMP(CURDATE() - INTERVAL 99 DAY, '12:00:00')),
(39,15,TIMESTAMP(CURDATE() - INTERVAL 70 DAY, '12:00:00')),
(39,29,TIMESTAMP(CURDATE() - INTERVAL 54 DAY, '12:00:00')),
(40,23,TIMESTAMP(CURDATE() - INTERVAL 54 DAY, '12:00:00'));

-- ---------- Mercado de la Comunidad
-- El ítem 30 es una recompensa NO comerciable (sirve para probar el trigger).
INSERT INTO Items (id_item,id_juego,nombre,tipo,rareza,comerciable) VALUES
(1,5,'Caja Eco','caja','comun',TRUE),
(2,5,'Rifle Aurora','skin','raro',TRUE),
(3,5,'Cuchillo Prisma','skin','legendario',TRUE),
(4,5,'Guantes Ceniza','skin','poco_comun',TRUE),
(5,5,'Casco Neón','skin','poco_comun',TRUE),
(6,5,'Emote Victoria','emoticono','comun',TRUE),
(7,1,'Cromo: La Sombra','cromo','comun',TRUE),
(8,1,'Cromo: El Guardián','cromo','comun',TRUE),
(9,1,'Fondo: Ruinas al anochecer','fondo','poco_comun',TRUE),
(10,1,'Emoticono: Calavera','emoticono','comun',TRUE),
(11,2,'Cromo: Distrito 9','cromo','comun',TRUE),
(12,2,'Cromo: La Corredora','cromo','comun',TRUE),
(13,2,'Pintura Holográfica','skin','raro',TRUE),
(14,2,'Fondo: Lluvia de neón','fondo','poco_comun',TRUE),
(15,3,'Cromo: Cometa','cromo','comun',TRUE),
(16,3,'Cromo: Nebulosa','cromo','comun',TRUE),
(17,3,'Fondo: Órbita','fondo','poco_comun',TRUE),
(18,10,'Katana Zorro de Fuego','skin','legendario',TRUE),
(19,10,'Máscara Kitsune','skin','raro',TRUE),
(20,10,'Cromo: Nueve colas','cromo','comun',TRUE),
(21,12,'Camiseta Retro 86','skin','raro',TRUE),
(22,12,'Botines Dorados','skin','legendario',TRUE),
(23,12,'Cromo: El Capitán','cromo','comun',TRUE),
(24,9,'Cromo: Farol rojo','cromo','comun',TRUE),
(25,9,'Fondo: Pantano','fondo','poco_comun',TRUE),
(26,17,'Implante Cromado','skin','raro',TRUE),
(27,17,'Cromo: Mate 2099','cromo','comun',TRUE),
(28,6,'Mazo Gauchesco','skin','poco_comun',TRUE),
(29,6,'Emoticono: Ancho de espadas','emoticono','comun',TRUE),
(30,5,'Medalla Temporada 1','emoticono','raro',FALSE);

INSERT INTO Inventario (id_inventario,id_usuario,id_item,fecha_obtencion) VALUES
(1,21,1,TIMESTAMP(CURDATE() - INTERVAL 16 DAY, '09:00:00')),
(2,21,1,TIMESTAMP(CURDATE() - INTERVAL 15 DAY, '09:00:00')),
(3,8,2,TIMESTAMP(CURDATE() - INTERVAL 147 DAY, '09:00:00')),
(4,8,2,TIMESTAMP(CURDATE() - INTERVAL 191 DAY, '09:00:00')),
(5,39,2,TIMESTAMP(CURDATE() - INTERVAL 111 DAY, '09:00:00')),
(6,20,3,TIMESTAMP(CURDATE() - INTERVAL 114 DAY, '09:00:00')),
(7,37,3,TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '09:00:00')),
(8,37,3,TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '09:00:00')),
(9,21,3,TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '09:00:00')),
(10,39,4,TIMESTAMP(CURDATE() - INTERVAL 89 DAY, '09:00:00')),
(11,8,4,TIMESTAMP(CURDATE() - INTERVAL 273 DAY, '09:00:00')),
(12,36,4,TIMESTAMP(CURDATE() - INTERVAL 295 DAY, '09:00:00')),
(13,8,4,TIMESTAMP(CURDATE() - INTERVAL 108 DAY, '09:00:00')),
(14,12,5,TIMESTAMP(CURDATE() - INTERVAL 19 DAY, '09:00:00')),
(15,12,5,TIMESTAMP(CURDATE() - INTERVAL 187 DAY, '09:00:00')),
(16,21,5,TIMESTAMP(CURDATE() - INTERVAL 13 DAY, '09:00:00')),
(17,36,6,TIMESTAMP(CURDATE() - INTERVAL 81 DAY, '09:00:00')),
(18,12,6,TIMESTAMP(CURDATE() - INTERVAL 120 DAY, '09:00:00')),
(19,39,6,TIMESTAMP(CURDATE() - INTERVAL 46 DAY, '09:00:00')),
(20,12,6,TIMESTAMP(CURDATE() - INTERVAL 135 DAY, '09:00:00')),
(21,12,6,TIMESTAMP(CURDATE() - INTERVAL 198 DAY, '09:00:00')),
(22,11,7,TIMESTAMP(CURDATE() - INTERVAL 145 DAY, '09:00:00')),
(23,20,7,TIMESTAMP(CURDATE() - INTERVAL 191 DAY, '09:00:00')),
(24,6,8,TIMESTAMP(CURDATE() - INTERVAL 96 DAY, '09:00:00')),
(25,1,8,TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '09:00:00')),
(26,25,8,TIMESTAMP(CURDATE() - INTERVAL 39 DAY, '09:00:00')),
(27,11,8,TIMESTAMP(CURDATE() - INTERVAL 15 DAY, '09:00:00')),
(28,37,8,TIMESTAMP(CURDATE() - INTERVAL 76 DAY, '09:00:00')),
(29,25,9,TIMESTAMP(CURDATE() - INTERVAL 99 DAY, '09:00:00')),
(30,25,9,TIMESTAMP(CURDATE() - INTERVAL 127 DAY, '09:00:00')),
(31,38,9,TIMESTAMP(CURDATE() - INTERVAL 49 DAY, '09:00:00')),
(32,6,10,TIMESTAMP(CURDATE() - INTERVAL 125 DAY, '09:00:00')),
(33,26,10,TIMESTAMP(CURDATE() - INTERVAL 14 DAY, '09:00:00')),
(34,20,10,TIMESTAMP(CURDATE() - INTERVAL 84 DAY, '09:00:00')),
(35,11,10,TIMESTAMP(CURDATE() - INTERVAL 111 DAY, '09:00:00')),
(36,1,10,TIMESTAMP(CURDATE() - INTERVAL 4 DAY, '09:00:00')),
(37,18,11,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '09:00:00')),
(38,8,11,TIMESTAMP(CURDATE() - INTERVAL 10 DAY, '09:00:00')),
(39,12,11,TIMESTAMP(CURDATE() - INTERVAL 96 DAY, '09:00:00')),
(40,33,11,TIMESTAMP(CURDATE() - INTERVAL 97 DAY, '09:00:00')),
(41,19,12,TIMESTAMP(CURDATE() - INTERVAL 17 DAY, '09:00:00')),
(42,33,12,TIMESTAMP(CURDATE() - INTERVAL 56 DAY, '09:00:00')),
(43,18,12,TIMESTAMP(CURDATE() - INTERVAL 215 DAY, '09:00:00')),
(44,40,12,TIMESTAMP(CURDATE() - INTERVAL 273 DAY, '09:00:00')),
(45,18,13,TIMESTAMP(CURDATE() - INTERVAL 190 DAY, '09:00:00')),
(46,5,13,TIMESTAMP(CURDATE() - INTERVAL 4 DAY, '09:00:00')),
(47,26,13,TIMESTAMP(CURDATE() - INTERVAL 162 DAY, '09:00:00')),
(48,12,13,TIMESTAMP(CURDATE() - INTERVAL 83 DAY, '09:00:00')),
(49,12,14,TIMESTAMP(CURDATE() - INTERVAL 30 DAY, '09:00:00')),
(50,5,14,TIMESTAMP(CURDATE() - INTERVAL 15 DAY, '09:00:00')),
(51,4,15,TIMESTAMP(CURDATE() - INTERVAL 33 DAY, '09:00:00')),
(52,15,15,TIMESTAMP(CURDATE() - INTERVAL 110 DAY, '09:00:00')),
(53,1,15,TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '09:00:00')),
(54,4,16,TIMESTAMP(CURDATE() - INTERVAL 238 DAY, '09:00:00')),
(55,1,16,TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '09:00:00')),
(56,18,17,TIMESTAMP(CURDATE() - INTERVAL 17 DAY, '09:00:00')),
(57,1,17,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '09:00:00')),
(58,1,17,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '09:00:00')),
(59,15,17,TIMESTAMP(CURDATE() - INTERVAL 183 DAY, '09:00:00')),
(60,19,18,TIMESTAMP(CURDATE() - INTERVAL 80 DAY, '09:00:00')),
(61,21,18,TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '09:00:00')),
(62,19,18,TIMESTAMP(CURDATE() - INTERVAL 27 DAY, '09:00:00')),
(63,19,18,TIMESTAMP(CURDATE() - INTERVAL 125 DAY, '09:00:00')),
(64,24,19,TIMESTAMP(CURDATE() - INTERVAL 172 DAY, '09:00:00')),
(65,12,19,TIMESTAMP(CURDATE() - INTERVAL 159 DAY, '09:00:00')),
(66,24,19,TIMESTAMP(CURDATE() - INTERVAL 163 DAY, '09:00:00')),
(67,12,19,TIMESTAMP(CURDATE() - INTERVAL 194 DAY, '09:00:00')),
(68,9,20,TIMESTAMP(CURDATE() - INTERVAL 172 DAY, '09:00:00')),
(69,12,20,TIMESTAMP(CURDATE() - INTERVAL 90 DAY, '09:00:00')),
(70,23,21,TIMESTAMP(CURDATE() - INTERVAL 20 DAY, '09:00:00')),
(71,28,21,TIMESTAMP(CURDATE() - INTERVAL 161 DAY, '09:00:00')),
(72,23,21,TIMESTAMP(CURDATE() - INTERVAL 85 DAY, '09:00:00')),
(73,27,21,TIMESTAMP(CURDATE() - INTERVAL 34 DAY, '09:00:00')),
(74,10,22,TIMESTAMP(CURDATE() - INTERVAL 300 DAY, '09:00:00')),
(75,23,22,TIMESTAMP(CURDATE() - INTERVAL 170 DAY, '09:00:00')),
(76,6,23,TIMESTAMP(CURDATE() - INTERVAL 77 DAY, '09:00:00')),
(77,9,23,TIMESTAMP(CURDATE() - INTERVAL 114 DAY, '09:00:00')),
(78,17,23,TIMESTAMP(CURDATE() - INTERVAL 321 DAY, '09:00:00')),
(79,15,24,TIMESTAMP(CURDATE() - INTERVAL 196 DAY, '09:00:00')),
(80,38,24,TIMESTAMP(CURDATE() - INTERVAL 228 DAY, '09:00:00')),
(81,38,24,TIMESTAMP(CURDATE() - INTERVAL 164 DAY, '09:00:00')),
(82,21,25,TIMESTAMP(CURDATE() - INTERVAL 17 DAY, '09:00:00')),
(83,20,25,TIMESTAMP(CURDATE() - INTERVAL 37 DAY, '09:00:00')),
(84,12,26,TIMESTAMP(CURDATE() - INTERVAL 119 DAY, '09:00:00')),
(85,12,26,TIMESTAMP(CURDATE() - INTERVAL 68 DAY, '09:00:00')),
(86,38,26,TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '09:00:00')),
(87,12,27,TIMESTAMP(CURDATE() - INTERVAL 156 DAY, '09:00:00')),
(88,38,27,TIMESTAMP(CURDATE() - INTERVAL 12 DAY, '09:00:00')),
(89,19,27,TIMESTAMP(CURDATE() - INTERVAL 190 DAY, '09:00:00')),
(90,13,27,TIMESTAMP(CURDATE() - INTERVAL 134 DAY, '09:00:00')),
(91,38,28,TIMESTAMP(CURDATE() - INTERVAL 71 DAY, '09:00:00')),
(92,25,28,TIMESTAMP(CURDATE() - INTERVAL 47 DAY, '09:00:00')),
(93,25,28,TIMESTAMP(CURDATE() - INTERVAL 83 DAY, '09:00:00')),
(94,38,28,TIMESTAMP(CURDATE() - INTERVAL 39 DAY, '09:00:00')),
(95,15,29,TIMESTAMP(CURDATE() - INTERVAL 134 DAY, '09:00:00')),
(96,14,29,TIMESTAMP(CURDATE() - INTERVAL 45 DAY, '09:00:00')),
(97,38,29,TIMESTAMP(CURDATE() - INTERVAL 42 DAY, '09:00:00')),
(98,15,29,TIMESTAMP(CURDATE() - INTERVAL 191 DAY, '09:00:00')),
(99,38,29,TIMESTAMP(CURDATE() - INTERVAL 186 DAY, '09:00:00')),
(100,21,30,TIMESTAMP(CURDATE() - INTERVAL 10 DAY, '09:00:00')),
(101,12,30,TIMESTAMP(CURDATE() - INTERVAL 107 DAY, '09:00:00'));

-- Publicaciones: el trigger calcula comisiones; las ventas mueven saldo e ítem.
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (1,74,10,35.56,TIMESTAMP(CURDATE() - INTERVAL 198 DAY, '10:30:00'));  -- Botines Dorados
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (2,54,4,0.18,TIMESTAMP(CURDATE() - INTERVAL 197 DAY, '10:30:00'));  -- Cromo: Nebulosa
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (3,43,18,0.37,TIMESTAMP(CURDATE() - INTERVAL 186 DAY, '10:30:00'));  -- Cromo: La Corredora
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (9,'compra_mercado',-0.43,TIMESTAMP(CURDATE() - INTERVAL 134 DAY, '18:45:00'),'Publicación #3');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (18,'venta_mercado',0.37,TIMESTAMP(CURDATE() - INTERVAL 134 DAY, '18:45:00'),'Publicación #3');
UPDATE Inventario SET id_usuario = 9, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 134 DAY, '18:45:00') WHERE id_inventario = 43;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 9, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 134 DAY, '18:45:00') WHERE id_publicacion = 3;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (4,44,40,0.24,TIMESTAMP(CURDATE() - INTERVAL 177 DAY, '10:30:00'));  -- Cromo: La Corredora
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (39,'compra_mercado',-0.27,TIMESTAMP(CURDATE() - INTERVAL 53 DAY, '18:45:00'),'Publicación #4');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (40,'venta_mercado',0.24,TIMESTAMP(CURDATE() - INTERVAL 53 DAY, '18:45:00'),'Publicación #4');
UPDATE Inventario SET id_usuario = 39, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 53 DAY, '18:45:00') WHERE id_inventario = 44;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 39, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 53 DAY, '18:45:00') WHERE id_publicacion = 4;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (5,12,36,0.84,TIMESTAMP(CURDATE() - INTERVAL 174 DAY, '10:30:00'));  -- Guantes Ceniza
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (6,75,23,109.45,TIMESTAMP(CURDATE() - INTERVAL 164 DAY, '10:30:00'));  -- Botines Dorados
UPDATE Publicaciones_Mercado SET estado = 'cancelada' WHERE id_publicacion = 6;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (7,71,28,6.58,TIMESTAMP(CURDATE() - INTERVAL 151 DAY, '10:30:00'));  -- Camiseta Retro 86
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (8,23,20,0.25,TIMESTAMP(CURDATE() - INTERVAL 148 DAY, '10:30:00'));  -- Cromo: La Sombra
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (28,'compra_mercado',-0.29,TIMESTAMP(CURDATE() - INTERVAL 24 DAY, '18:45:00'),'Publicación #8');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (20,'venta_mercado',0.25,TIMESTAMP(CURDATE() - INTERVAL 24 DAY, '18:45:00'),'Publicación #8');
UPDATE Inventario SET id_usuario = 28, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 24 DAY, '18:45:00') WHERE id_inventario = 23;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 28, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 24 DAY, '18:45:00') WHERE id_publicacion = 8;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (9,66,24,8.65,TIMESTAMP(CURDATE() - INTERVAL 147 DAY, '10:30:00'));  -- Máscara Kitsune
UPDATE Publicaciones_Mercado SET estado = 'cancelada' WHERE id_publicacion = 9;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (10,81,38,0.31,TIMESTAMP(CURDATE() - INTERVAL 136 DAY, '10:30:00'));  -- Cromo: Farol rojo
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (33,'compra_mercado',-0.36,TIMESTAMP(CURDATE() - INTERVAL 53 DAY, '18:45:00'),'Publicación #10');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (38,'venta_mercado',0.31,TIMESTAMP(CURDATE() - INTERVAL 53 DAY, '18:45:00'),'Publicación #10');
UPDATE Inventario SET id_usuario = 33, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 53 DAY, '18:45:00') WHERE id_inventario = 81;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 33, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 53 DAY, '18:45:00') WHERE id_publicacion = 10;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (11,20,12,0.24,TIMESTAMP(CURDATE() - INTERVAL 127 DAY, '10:30:00'));  -- Emote Victoria
UPDATE Publicaciones_Mercado SET estado = 'cancelada' WHERE id_publicacion = 11;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (12,3,8,13.66,TIMESTAMP(CURDATE() - INTERVAL 125 DAY, '10:30:00'));  -- Rifle Aurora
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (17,'compra_mercado',-15.71,TIMESTAMP(CURDATE() - INTERVAL 90 DAY, '18:45:00'),'Publicación #12');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (8,'venta_mercado',13.66,TIMESTAMP(CURDATE() - INTERVAL 90 DAY, '18:45:00'),'Publicación #12');
UPDATE Inventario SET id_usuario = 17, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 90 DAY, '18:45:00') WHERE id_inventario = 3;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 17, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 90 DAY, '18:45:00') WHERE id_publicacion = 12;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (13,90,13,0.34,TIMESTAMP(CURDATE() - INTERVAL 120 DAY, '10:30:00'));  -- Cromo: Mate 2099
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (14,47,26,8.37,TIMESTAMP(CURDATE() - INTERVAL 118 DAY, '10:30:00'));  -- Pintura Holográfica
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (25,'compra_mercado',-9.63,TIMESTAMP(CURDATE() - INTERVAL 37 DAY, '18:45:00'),'Publicación #14');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (26,'venta_mercado',8.37,TIMESTAMP(CURDATE() - INTERVAL 37 DAY, '18:45:00'),'Publicación #14');
UPDATE Inventario SET id_usuario = 25, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 37 DAY, '18:45:00') WHERE id_inventario = 47;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 25, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 37 DAY, '18:45:00') WHERE id_publicacion = 14;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (15,45,18,11.97,TIMESTAMP(CURDATE() - INTERVAL 117 DAY, '10:30:00'));  -- Pintura Holográfica
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (16,64,24,2.88,TIMESTAMP(CURDATE() - INTERVAL 116 DAY, '10:30:00'));  -- Máscara Kitsune
UPDATE Publicaciones_Mercado SET estado = 'cancelada' WHERE id_publicacion = 16;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (17,68,9,0.25,TIMESTAMP(CURDATE() - INTERVAL 104 DAY, '10:30:00'));  -- Cromo: Nueve colas
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (34,'compra_mercado',-0.29,TIMESTAMP(CURDATE() - INTERVAL 42 DAY, '18:45:00'),'Publicación #17');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (9,'venta_mercado',0.25,TIMESTAMP(CURDATE() - INTERVAL 42 DAY, '18:45:00'),'Publicación #17');
UPDATE Inventario SET id_usuario = 34, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 42 DAY, '18:45:00') WHERE id_inventario = 68;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 34, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 42 DAY, '18:45:00') WHERE id_publicacion = 17;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (18,18,12,0.12,TIMESTAMP(CURDATE() - INTERVAL 82 DAY, '10:30:00'));  -- Emote Victoria
UPDATE Publicaciones_Mercado SET estado = 'cancelada' WHERE id_publicacion = 18;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (19,21,12,0.22,TIMESTAMP(CURDATE() - INTERVAL 79 DAY, '10:30:00'));  -- Emote Victoria
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (9,'compra_mercado',-0.25,TIMESTAMP(CURDATE() - INTERVAL 61 DAY, '18:45:00'),'Publicación #19');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (12,'venta_mercado',0.22,TIMESTAMP(CURDATE() - INTERVAL 61 DAY, '18:45:00'),'Publicación #19');
UPDATE Inventario SET id_usuario = 9, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 61 DAY, '18:45:00') WHERE id_inventario = 21;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 9, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 61 DAY, '18:45:00') WHERE id_publicacion = 19;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (20,99,38,0.14,TIMESTAMP(CURDATE() - INTERVAL 78 DAY, '10:30:00'));  -- Emoticono: Ancho de espadas
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (12,'compra_mercado',-0.16,TIMESTAMP(CURDATE() - INTERVAL 47 DAY, '18:45:00'),'Publicación #20');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (38,'venta_mercado',0.14,TIMESTAMP(CURDATE() - INTERVAL 47 DAY, '18:45:00'),'Publicación #20');
UPDATE Inventario SET id_usuario = 12, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 47 DAY, '18:45:00') WHERE id_inventario = 99;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 12, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 47 DAY, '18:45:00') WHERE id_publicacion = 20;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (21,13,8,0.50,TIMESTAMP(CURDATE() - INTERVAL 74 DAY, '10:30:00'));  -- Guantes Ceniza
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (22,34,20,0.36,TIMESTAMP(CURDATE() - INTERVAL 59 DAY, '10:30:00'));  -- Emoticono: Calavera
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (34,'compra_mercado',-0.42,TIMESTAMP(CURDATE() - INTERVAL 47 DAY, '18:45:00'),'Publicación #22');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (20,'venta_mercado',0.36,TIMESTAMP(CURDATE() - INTERVAL 47 DAY, '18:45:00'),'Publicación #22');
UPDATE Inventario SET id_usuario = 34, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 47 DAY, '18:45:00') WHERE id_inventario = 34;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 34, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 47 DAY, '18:45:00') WHERE id_publicacion = 22;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (23,77,9,0.11,TIMESTAMP(CURDATE() - INTERVAL 58 DAY, '10:30:00'));  -- Cromo: El Capitán
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (24,15,12,0.32,TIMESTAMP(CURDATE() - INTERVAL 58 DAY, '10:30:00'));  -- Casco Neón
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (25,89,19,0.27,TIMESTAMP(CURDATE() - INTERVAL 53 DAY, '10:30:00'));  -- Cromo: Mate 2099
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (38,'compra_mercado',-0.31,TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '18:45:00'),'Publicación #25');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (19,'venta_mercado',0.27,TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '18:45:00'),'Publicación #25');
UPDATE Inventario SET id_usuario = 38, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '18:45:00') WHERE id_inventario = 89;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 38, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '18:45:00') WHERE id_publicacion = 25;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (26,42,33,0.14,TIMESTAMP(CURDATE() - INTERVAL 51 DAY, '10:30:00'));  -- Cromo: La Corredora
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (29,'compra_mercado',-0.16,TIMESTAMP(CURDATE() - INTERVAL 44 DAY, '18:45:00'),'Publicación #26');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (33,'venta_mercado',0.14,TIMESTAMP(CURDATE() - INTERVAL 44 DAY, '18:45:00'),'Publicación #26');
UPDATE Inventario SET id_usuario = 29, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 44 DAY, '18:45:00') WHERE id_inventario = 42;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 29, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 44 DAY, '18:45:00') WHERE id_publicacion = 26;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (27,22,11,0.07,TIMESTAMP(CURDATE() - INTERVAL 48 DAY, '10:30:00'));  -- Cromo: La Sombra
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (28,30,25,0.88,TIMESTAMP(CURDATE() - INTERVAL 41 DAY, '10:30:00'));  -- Fondo: Ruinas al anochecer
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (29,39,12,0.39,TIMESTAMP(CURDATE() - INTERVAL 38 DAY, '10:30:00'));  -- Cromo: Distrito 9
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (37,'compra_mercado',-0.45,TIMESTAMP(CURDATE() - INTERVAL 22 DAY, '18:45:00'),'Publicación #29');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (12,'venta_mercado',0.39,TIMESTAMP(CURDATE() - INTERVAL 22 DAY, '18:45:00'),'Publicación #29');
UPDATE Inventario SET id_usuario = 37, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 22 DAY, '18:45:00') WHERE id_inventario = 39;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 37, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 22 DAY, '18:45:00') WHERE id_publicacion = 29;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (30,65,12,7.76,TIMESTAMP(CURDATE() - INTERVAL 36 DAY, '10:30:00'));  -- Máscara Kitsune
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (19,'compra_mercado',-9.08,TIMESTAMP(CURDATE() - INTERVAL 4 DAY, '18:45:00'),'Publicación #30');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (12,'venta_mercado',7.76,TIMESTAMP(CURDATE() - INTERVAL 4 DAY, '18:45:00'),'Publicación #30');
UPDATE Inventario SET id_usuario = 19, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 4 DAY, '18:45:00') WHERE id_inventario = 65;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 19, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 4 DAY, '18:45:00') WHERE id_publicacion = 30;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (31,24,6,0.39,TIMESTAMP(CURDATE() - INTERVAL 36 DAY, '10:30:00'));  -- Cromo: El Guardián
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (33,'compra_mercado',-0.45,TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '18:45:00'),'Publicación #31');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (6,'venta_mercado',0.39,TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '18:45:00'),'Publicación #31');
UPDATE Inventario SET id_usuario = 33, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '18:45:00') WHERE id_inventario = 24;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 33, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '18:45:00') WHERE id_publicacion = 31;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (32,28,37,0.11,TIMESTAMP(CURDATE() - INTERVAL 35 DAY, '10:30:00'));  -- Cromo: El Guardián
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (30,'compra_mercado',-0.13,TIMESTAMP(CURDATE() - INTERVAL 10 DAY, '18:45:00'),'Publicación #32');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (37,'venta_mercado',0.11,TIMESTAMP(CURDATE() - INTERVAL 10 DAY, '18:45:00'),'Publicación #32');
UPDATE Inventario SET id_usuario = 30, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 10 DAY, '18:45:00') WHERE id_inventario = 28;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 30, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 10 DAY, '18:45:00') WHERE id_publicacion = 32;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (33,49,12,0.74,TIMESTAMP(CURDATE() - INTERVAL 29 DAY, '10:30:00'));  -- Fondo: Lluvia de neón
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (32,'compra_mercado',-0.85,TIMESTAMP(CURDATE() - INTERVAL 13 DAY, '18:45:00'),'Publicación #33');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (12,'venta_mercado',0.74,TIMESTAMP(CURDATE() - INTERVAL 13 DAY, '18:45:00'),'Publicación #33');
UPDATE Inventario SET id_usuario = 32, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 13 DAY, '18:45:00') WHERE id_inventario = 49;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 32, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 13 DAY, '18:45:00') WHERE id_publicacion = 33;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (34,17,36,0.22,TIMESTAMP(CURDATE() - INTERVAL 29 DAY, '10:30:00'));  -- Emote Victoria
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (25,'compra_mercado',-0.25,TIMESTAMP(CURDATE() - INTERVAL 10 DAY, '18:45:00'),'Publicación #34');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (36,'venta_mercado',0.22,TIMESTAMP(CURDATE() - INTERVAL 10 DAY, '18:45:00'),'Publicación #34');
UPDATE Inventario SET id_usuario = 25, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 10 DAY, '18:45:00') WHERE id_inventario = 17;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 25, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 10 DAY, '18:45:00') WHERE id_publicacion = 34;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (35,62,19,73.13,TIMESTAMP(CURDATE() - INTERVAL 26 DAY, '10:30:00'));  -- Katana Zorro de Fuego
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (9,'compra_mercado',-85.57,TIMESTAMP(CURDATE() - INTERVAL 12 DAY, '18:45:00'),'Publicación #35');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (19,'venta_mercado',73.13,TIMESTAMP(CURDATE() - INTERVAL 12 DAY, '18:45:00'),'Publicación #35');
UPDATE Inventario SET id_usuario = 9, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 12 DAY, '18:45:00') WHERE id_inventario = 62;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 9, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 12 DAY, '18:45:00') WHERE id_publicacion = 35;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (36,51,4,0.31,TIMESTAMP(CURDATE() - INTERVAL 24 DAY, '10:30:00'));  -- Cromo: Cometa
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (36,'compra_mercado',-0.36,TIMESTAMP(CURDATE() - INTERVAL 21 DAY, '18:45:00'),'Publicación #36');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (4,'venta_mercado',0.31,TIMESTAMP(CURDATE() - INTERVAL 21 DAY, '18:45:00'),'Publicación #36');
UPDATE Inventario SET id_usuario = 36, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 21 DAY, '18:45:00') WHERE id_inventario = 51;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 36, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 21 DAY, '18:45:00') WHERE id_publicacion = 36;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (37,6,20,102.97,TIMESTAMP(CURDATE() - INTERVAL 18 DAY, '10:30:00'));  -- Cuchillo Prisma
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (6,'compra_mercado',-118.42,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00'),'Publicación #37');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (20,'venta_mercado',102.97,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00'),'Publicación #37');
UPDATE Inventario SET id_usuario = 6, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00') WHERE id_inventario = 6;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 6, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00') WHERE id_publicacion = 37;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (38,26,25,0.36,TIMESTAMP(CURDATE() - INTERVAL 18 DAY, '10:30:00'));  -- Cromo: El Guardián
UPDATE Publicaciones_Mercado SET estado = 'cancelada' WHERE id_publicacion = 38;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (39,48,12,12.05,TIMESTAMP(CURDATE() - INTERVAL 16 DAY, '10:30:00'));  -- Pintura Holográfica
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (40,19,39,0.23,TIMESTAMP(CURDATE() - INTERVAL 13 DAY, '10:30:00'));  -- Emote Victoria
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (15,'compra_mercado',-0.26,TIMESTAMP(CURDATE() - INTERVAL 7 DAY, '18:45:00'),'Publicación #40');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (39,'venta_mercado',0.23,TIMESTAMP(CURDATE() - INTERVAL 7 DAY, '18:45:00'),'Publicación #40');
UPDATE Inventario SET id_usuario = 15, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 7 DAY, '18:45:00') WHERE id_inventario = 19;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 15, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 7 DAY, '18:45:00') WHERE id_publicacion = 40;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (41,76,6,0.19,TIMESTAMP(CURDATE() - INTERVAL 8 DAY, '10:30:00'));  -- Cromo: El Capitán
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (18,'compra_mercado',-0.23,TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '18:45:00'),'Publicación #41');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (6,'venta_mercado',0.19,TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '18:45:00'),'Publicación #41');
UPDATE Inventario SET id_usuario = 18, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '18:45:00') WHERE id_inventario = 76;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 18, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '18:45:00') WHERE id_publicacion = 41;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (42,33,26,0.12,TIMESTAMP(CURDATE() - INTERVAL 8 DAY, '10:30:00'));  -- Emoticono: Calavera
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (10,'compra_mercado',-0.14,TIMESTAMP(CURDATE() - INTERVAL 6 DAY, '18:45:00'),'Publicación #42');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (26,'venta_mercado',0.12,TIMESTAMP(CURDATE() - INTERVAL 6 DAY, '18:45:00'),'Publicación #42');
UPDATE Inventario SET id_usuario = 10, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 6 DAY, '18:45:00') WHERE id_inventario = 33;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 10, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 6 DAY, '18:45:00') WHERE id_publicacion = 42;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (43,14,12,1.39,TIMESTAMP(CURDATE() - INTERVAL 7 DAY, '10:30:00'));  -- Casco Neón
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (39,'compra_mercado',-1.60,TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '18:45:00'),'Publicación #43');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (12,'venta_mercado',1.39,TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '18:45:00'),'Publicación #43');
UPDATE Inventario SET id_usuario = 39, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '18:45:00') WHERE id_inventario = 14;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 39, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '18:45:00') WHERE id_publicacion = 43;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (44,1,21,0.38,TIMESTAMP(CURDATE() - INTERVAL 7 DAY, '10:30:00'));  -- Caja Eco
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (23,'compra_mercado',-0.44,TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '18:45:00'),'Publicación #44');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (21,'venta_mercado',0.38,TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '18:45:00'),'Publicación #44');
UPDATE Inventario SET id_usuario = 23, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '18:45:00') WHERE id_inventario = 1;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 23, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '18:45:00') WHERE id_publicacion = 44;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (45,82,21,0.60,TIMESTAMP(CURDATE() - INTERVAL 7 DAY, '10:30:00'));  -- Fondo: Pantano
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (32,'compra_mercado',-0.69,TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '18:45:00'),'Publicación #45');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (21,'venta_mercado',0.60,TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '18:45:00'),'Publicación #45');
UPDATE Inventario SET id_usuario = 32, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '18:45:00') WHERE id_inventario = 82;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 32, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '18:45:00') WHERE id_publicacion = 45;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (46,41,19,0.39,TIMESTAMP(CURDATE() - INTERVAL 7 DAY, '10:30:00'));  -- Cromo: La Corredora
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (30,'compra_mercado',-0.45,TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '18:45:00'),'Publicación #46');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (19,'venta_mercado',0.39,TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '18:45:00'),'Publicación #46');
UPDATE Inventario SET id_usuario = 30, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '18:45:00') WHERE id_inventario = 41;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 30, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '18:45:00') WHERE id_publicacion = 46;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (47,73,27,3.80,TIMESTAMP(CURDATE() - INTERVAL 6 DAY, '10:30:00'));  -- Camiseta Retro 86
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (39,'compra_mercado',-4.56,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00'),'Publicación #47');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (27,'venta_mercado',3.80,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00'),'Publicación #47');
UPDATE Inventario SET id_usuario = 39, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00') WHERE id_inventario = 73;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 39, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00') WHERE id_publicacion = 47;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (48,88,38,0.17,TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '10:30:00'));  -- Cromo: Mate 2099
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (16,'compra_mercado',-0.20,TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '18:45:00'),'Publicación #48');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (38,'venta_mercado',0.17,TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '18:45:00'),'Publicación #48');
UPDATE Inventario SET id_usuario = 16, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '18:45:00') WHERE id_inventario = 88;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 16, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '18:45:00') WHERE id_publicacion = 48;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (49,9,21,75.45,TIMESTAMP(CURDATE() - INTERVAL 4 DAY, '10:30:00'));  -- Cuchillo Prisma
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (13,'compra_mercado',-86.77,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00'),'Publicación #49');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (21,'venta_mercado',75.45,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00'),'Publicación #49');
UPDATE Inventario SET id_usuario = 13, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00') WHERE id_inventario = 9;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 13, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00') WHERE id_publicacion = 49;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (50,31,38,1.38,TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '10:30:00'));  -- Fondo: Ruinas al anochecer
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (16,'compra_mercado',-1.59,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00'),'Publicación #50');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (38,'venta_mercado',1.38,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00'),'Publicación #50');
UPDATE Inventario SET id_usuario = 16, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00') WHERE id_inventario = 31;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 16, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00') WHERE id_publicacion = 50;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (51,93,25,1.00,TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '10:30:00'));  -- Mazo Gauchesco
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (52,38,8,0.12,TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '10:30:00'));  -- Cromo: Distrito 9
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (15,'compra_mercado',-0.14,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00'),'Publicación #52');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (8,'venta_mercado',0.12,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00'),'Publicación #52');
UPDATE Inventario SET id_usuario = 15, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00') WHERE id_inventario = 38;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 15, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00') WHERE id_publicacion = 52;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (53,61,21,63.40,TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '10:30:00'));  -- Katana Zorro de Fuego
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (54,86,38,12.04,TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '10:30:00'));  -- Implante Cromado
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (15,'compra_mercado',-13.84,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00'),'Publicación #54');
INSERT INTO Movimientos_Billetera (id_usuario,tipo,monto,fecha,referencia) VALUES (38,'venta_mercado',12.04,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00'),'Publicación #54');
UPDATE Inventario SET id_usuario = 15, fecha_obtencion = TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00') WHERE id_inventario = 86;
UPDATE Publicaciones_Mercado SET estado = 'vendida', id_comprador = 15, fecha_venta = TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:45:00') WHERE id_publicacion = 54;
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (55,55,1,0.05,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '10:30:00'));  -- Cromo: Nebulosa
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (56,37,18,0.08,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '10:30:00'));  -- Cromo: Distrito 9
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (57,8,37,33.45,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '10:30:00'));  -- Cuchillo Prisma
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (58,46,5,6.09,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '10:30:00'));  -- Pintura Holográfica
INSERT INTO Publicaciones_Mercado (id_publicacion,id_inventario,id_vendedor,precio_vendedor,fecha_publicacion) VALUES (59,7,37,73.87,TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '10:30:00'));  -- Cuchillo Prisma
-- =====================================================================
--  STEAM SISTEMA v2  -  06. CARGA MASIVA
--  Usuarios y compras generados al azar con un procedimiento. Se puede repetir.
--  Probado en MySQL 8 (HeidiSQL o Workbench). Ejecutar el archivo completo (F9 en HeidiSQL).
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- =====================================================================
-- CARGA MASIVA
--    Agrega usuarios y compras al azar sobre los datos legibles.
--    Para más volumen: CALL sp_generar_datos_masivos(2000, 20000);
-- =====================================================================
CALL sp_generar_datos_masivos(300, 2500);

-- Resultado
SELECT (SELECT COUNT(*) FROM Usuarios) AS usuarios, (SELECT COUNT(*) FROM Compras) AS compras,
       (SELECT COUNT(*) FROM Detalle_Compra) AS juegos_vendidos, (SELECT COUNT(*) FROM Resenas) AS resenas;
-- =====================================================================
--  STEAM SISTEMA v2  -  07. VISTAS
--  Consultas guardadas. Se usan con SELECT * FROM vista_...
--  Probado en MySQL 8 (HeidiSQL o Workbench). Ejecutar el archivo completo (F9 en HeidiSQL).
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- =====================================================================
-- VISTAS
-- =====================================================================

-- Catálogo con precio actual, géneros y estado de lanzamiento.
CREATE OR REPLACE VIEW vista_juegos_completa AS
SELECT j.id_juego,
       j.nombre_juego,
       j.precio_base,
       fn_descuento_en_fecha(j.id_juego, CURDATE()) AS descuento_actual,
       fn_precio_actual(j.id_juego)                 AS precio_actual,
       d.nombre AS desarrolladora,
       d.region,
       (SELECT GROUP_CONCAT(g.nombre ORDER BY g.nombre SEPARATOR ', ')
          FROM Juego_Genero jg JOIN Generos g ON g.id_genero = jg.id_genero
         WHERE jg.id_juego = j.id_juego) AS generos,
       j.fecha_lanzamiento,
       IF(j.fecha_lanzamiento > CURDATE(), 'Próximamente', 'Disponible') AS estado
FROM Juegos j
LEFT JOIN Desarrolladoras d ON d.id_desarrolladora = j.id_desarrolladora;

-- Promociones vigentes hoy (una fila por juego en promoción).
CREATE OR REPLACE VIEW vista_promos_activas AS
SELECT p.id_promocion, p.nombre AS promocion, p.porcentaje_descuento,
       p.fecha_inicio, p.fecha_fin, DATEDIFF(p.fecha_fin, CURDATE()) AS dias_restantes,
       j.id_juego, j.nombre_juego
FROM Promociones p
JOIN Juego_Promocion jp ON p.id_promocion = jp.id_promocion
JOIN Juegos j           ON jp.id_juego = j.id_juego
WHERE CURDATE() BETWEEN p.fecha_inicio AND p.fecha_fin;

-- Precio final de cada juego (corrige la versión anterior, que duplicaba
-- filas cuando un juego estaba en más de una promoción).
CREATE OR REPLACE VIEW vista_juegos_precio_final AS
SELECT j.id_juego, j.nombre_juego, j.precio_base,
       fn_descuento_en_fecha(j.id_juego, CURDATE()) AS porcentaje_descuento,
       fn_precio_actual(j.id_juego)                 AS precio_final
FROM Juegos j;

-- Cada juego comprado, con promo, método de pago y estado de reembolso.
CREATE OR REPLACE VIEW vista_compras_detalles AS
SELECT c.id_compra, d.id_detalle, u.id_usuario, u.nombre AS comprador,
       j.nombre_juego, d.precio_pagado, p.nombre AS promocion,
       m.nombre AS metodo_pago, c.fecha_compra,
       COALESCE(r.estado, 'sin reembolso') AS reembolso
FROM Detalle_Compra d
JOIN Compras c       ON c.id_compra = d.id_compra
JOIN Usuarios u      ON u.id_usuario = c.id_usuario
JOIN Juegos j        ON j.id_juego = d.id_juego
JOIN Metodos_Pago m  ON m.id_metodo_pago = c.id_metodo_pago
LEFT JOIN Promociones p ON p.id_promocion = d.id_promocion
LEFT JOIN Reembolsos r  ON r.id_detalle = d.id_detalle;

-- Total de cada compra (el total se calcula, no se guarda).
CREATE OR REPLACE VIEW vista_compras_totales AS
SELECT c.id_compra, u.nombre AS comprador, c.fecha_compra, m.nombre AS metodo_pago,
       COUNT(*) AS cantidad_juegos, SUM(d.precio_pagado) AS total
FROM Compras c
JOIN Usuarios u       ON u.id_usuario = c.id_usuario
JOIN Metodos_Pago m   ON m.id_metodo_pago = c.id_metodo_pago
JOIN Detalle_Compra d ON d.id_compra = c.id_compra
GROUP BY c.id_compra, u.nombre, c.fecha_compra, m.nombre;

-- Criterio para reembolsos (el mismo en vistas y consultas): se admiten
-- devoluciones parciales. Ingresos = lo cobrado menos lo devuelto en reembolsos
-- aprobados. Unidades = licencias vigentes (un reembolso aprobado quita la licencia).
-- Reemplaza a la vieja tabla Ventas: lo que vendió cada desarrolladora.
-- ingresos_brutos = antes de la comisión de Steam, ya descontados los reembolsos.
-- Comisión simplificada al 30 % (en Steam real baja a 25 % y 20 % después de
-- USD 10 M y 50 M por juego).
CREATE OR REPLACE VIEW vista_ventas_desarrolladora AS
SELECT COALESCE(dv.nombre, 'Sin desarrolladora') AS desarrolladora,
       SUM(r.id_reembolso IS NULL)                 AS unidades_vendidas,
       SUM(d.precio_pagado - COALESCE(r.monto_devuelto, 0))                 AS ingresos_brutos,
       ROUND(SUM(d.precio_pagado - COALESCE(r.monto_devuelto, 0)) * 0.30, 2) AS comision_steam,
       ROUND(SUM(d.precio_pagado - COALESCE(r.monto_devuelto, 0)) * 0.70, 2) AS neto_desarrolladora
FROM Detalle_Compra d
JOIN Juegos j ON j.id_juego = d.id_juego
LEFT JOIN Desarrolladoras dv ON dv.id_desarrolladora = j.id_desarrolladora
LEFT JOIN Reembolsos r ON r.id_detalle = d.id_detalle AND r.estado = 'aprobado'
GROUP BY COALESCE(dv.nombre, 'Sin desarrolladora');

CREATE OR REPLACE VIEW vista_biblioteca AS
SELECT u.id_usuario, u.nombre AS usuario, j.nombre_juego,
       b.fecha_adquisicion, b.horas_jugadas, b.origen
FROM Biblioteca b
JOIN Usuarios u ON u.id_usuario = b.id_usuario
JOIN Juegos j   ON j.id_juego = b.id_juego;

CREATE OR REPLACE VIEW vista_reembolsos_detalle AS
SELECT r.id_reembolso, u.nombre AS usuario, j.nombre_juego,
       c.fecha_compra, r.fecha_solicitud,
       DATEDIFF(r.fecha_solicitud, c.fecha_compra) AS dias_desde_compra,
       d.precio_pagado, r.monto_devuelto, r.estado, r.destino, r.motivo
FROM Reembolsos r
JOIN Detalle_Compra d ON d.id_detalle = r.id_detalle
JOIN Compras c        ON c.id_compra = d.id_compra
JOIN Usuarios u       ON u.id_usuario = c.id_usuario
JOIN Juegos j         ON j.id_juego = d.id_juego;

-- Billetera: el saldo guardado (desnormalizado) contra la suma de movimientos.
-- La columna "control" debe dar siempre 'OK'.
CREATE OR REPLACE VIEW vista_billetera AS
SELECT u.id_usuario, u.nombre, u.saldo_billetera,
       COALESCE(SUM(CASE WHEN m.tipo = 'recarga'        THEN m.monto END), 0) AS recargado,
       COALESCE(SUM(CASE WHEN m.tipo = 'compra_tienda'  THEN m.monto END), 0) AS gastado_tienda,
       COALESCE(SUM(CASE WHEN m.tipo = 'compra_mercado' THEN m.monto END), 0) AS gastado_mercado,
       COALESCE(SUM(CASE WHEN m.tipo = 'venta_mercado'  THEN m.monto END), 0) AS ganado_mercado,
       COALESCE(SUM(CASE WHEN m.tipo = 'reembolso'      THEN m.monto END), 0) AS reembolsado,
       IF(u.saldo_billetera = COALESCE(SUM(m.monto), 0), 'OK', 'DESCUADRE') AS control
FROM Usuarios u
LEFT JOIN Movimientos_Billetera m ON m.id_usuario = u.id_usuario
GROUP BY u.id_usuario, u.nombre, u.saldo_billetera;

CREATE OR REPLACE VIEW vista_mercado_activo AS
SELECT pm.id_publicacion, it.nombre AS item, it.tipo, it.rareza, j.nombre_juego,
       u.nombre AS vendedor, pm.precio_vendedor, pm.comision_steam, pm.comision_juego,
       pm.precio_comprador, pm.fecha_publicacion
FROM Publicaciones_Mercado pm
JOIN Inventario inv ON inv.id_inventario = pm.id_inventario
JOIN Items it       ON it.id_item = inv.id_item
JOIN Juegos j       ON j.id_juego = it.id_juego
JOIN Usuarios u     ON u.id_usuario = pm.id_vendedor
WHERE pm.estado = 'activa';

CREATE OR REPLACE VIEW vista_ventas_mercado AS
SELECT pm.id_publicacion, it.nombre AS item, it.rareza, j.nombre_juego,
       v.nombre AS vendedor, c.nombre AS comprador,
       pm.precio_comprador AS pago_comprador, pm.precio_vendedor AS recibe_vendedor,
       pm.comision_steam, pm.comision_juego, pm.fecha_venta
FROM Publicaciones_Mercado pm
JOIN Inventario inv ON inv.id_inventario = pm.id_inventario
JOIN Items it       ON it.id_item = inv.id_item
JOIN Juegos j       ON j.id_juego = it.id_juego
JOIN Usuarios v     ON v.id_usuario = pm.id_vendedor
JOIN Usuarios c     ON c.id_usuario = pm.id_comprador
WHERE pm.estado = 'vendida';

-- Valoración estilo Steam (versión simplificada de sus etiquetas).
CREATE OR REPLACE VIEW vista_valoracion_juegos AS
SELECT j.id_juego, j.nombre_juego,
       COUNT(r.id_resena) AS total_resenas,
       ROUND(100 * AVG(r.recomendado), 1) AS porcentaje_positivas,
       CASE
         WHEN COUNT(r.id_resena) < 10              THEN 'Pocas reseñas'
         WHEN AVG(r.recomendado) >= 0.95 AND COUNT(r.id_resena) >= 500 THEN 'Extremadamente positivas'
         WHEN AVG(r.recomendado) >= 0.80 AND COUNT(r.id_resena) >= 50  THEN 'Muy positivas'
         WHEN AVG(r.recomendado) >= 0.80           THEN 'Positivas'
         WHEN AVG(r.recomendado) >= 0.70           THEN 'Mayormente positivas'
         WHEN AVG(r.recomendado) >= 0.40           THEN 'Variadas'
         WHEN AVG(r.recomendado) >= 0.20           THEN 'Mayormente negativas'
         ELSE 'Negativas'
       END AS valoracion
FROM Juegos j
LEFT JOIN Resenas r ON r.id_juego = j.id_juego
GROUP BY j.id_juego, j.nombre_juego;

-- Lo que Steam le "avisaría" a cada usuario: juegos de su lista en oferta.
CREATE OR REPLACE VIEW vista_deseados_en_oferta AS
SELECT u.id_usuario, u.nombre AS usuario, j.nombre_juego,
       j.precio_base, fn_precio_actual(j.id_juego) AS precio_oferta,
       fn_descuento_en_fecha(j.id_juego, CURDATE()) AS descuento
FROM Lista_Deseados ld
JOIN Usuarios u ON u.id_usuario = ld.id_usuario
JOIN Juegos j   ON j.id_juego = ld.id_juego
WHERE fn_descuento_en_fecha(j.id_juego, CURDATE()) > 0;
-- =====================================================================
--  STEAM SISTEMA v2  -  08. CONSULTAS
--  15 consultas de negocio sobre tablas y vistas.
--  Probado en MySQL 8 (HeidiSQL o Workbench). Ejecutar el archivo completo (F9 en HeidiSQL).
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- =====================================================================
-- CONSULTAS
-- Criterio para reembolsos (el mismo en vistas y consultas): se admiten
-- devoluciones parciales. Ingresos = lo cobrado menos lo devuelto en reembolsos
-- aprobados. Unidades = licencias vigentes (un reembolso aprobado quita la licencia).
-- =====================================================================

-- 1. Total gastado por usuario (neto de reembolsos aprobados)
SELECT u.id_usuario, u.nombre,
       SUM(d.precio_pagado - COALESCE(r.monto_devuelto, 0)) AS total_gastado
FROM Usuarios u
JOIN Compras c        ON c.id_usuario = u.id_usuario
JOIN Detalle_Compra d ON d.id_compra = c.id_compra
LEFT JOIN Reembolsos r ON r.id_detalle = d.id_detalle AND r.estado = 'aprobado'
GROUP BY u.id_usuario, u.nombre
ORDER BY total_gastado DESC;

-- 2. Juego más vendido (RANK muestra empates, LIMIT 1 los escondería)
SELECT * FROM (
  SELECT j.id_juego, j.nombre_juego, COUNT(*) AS veces_comprado,
         RANK() OVER (ORDER BY COUNT(*) DESC) AS puesto
  FROM Detalle_Compra d
  JOIN Juegos j ON j.id_juego = d.id_juego
  LEFT JOIN Reembolsos r ON r.id_detalle = d.id_detalle AND r.estado = 'aprobado'
  WHERE r.id_reembolso IS NULL
  GROUP BY j.id_juego, j.nombre_juego
) t WHERE puesto = 1;

-- 3. Historial de compras
SELECT comprador, nombre_juego, precio_pagado, promocion, metodo_pago, fecha_compra, reembolso
FROM vista_compras_detalles
ORDER BY fecha_compra DESC;

-- 4. Juegos con promoción activa
SELECT * FROM vista_promos_activas ORDER BY porcentaje_descuento DESC;

-- 5. Usuarios que solicitaron reembolso, con el resultado
SELECT usuario, nombre_juego, dias_desde_compra, monto_devuelto, estado
FROM vista_reembolsos_detalle ORDER BY fecha_solicitud DESC;

-- 6. Top 3 usuarios que más gastaron (neto de reembolsos aprobados)
SELECT u.id_usuario, u.nombre,
       SUM(d.precio_pagado - COALESCE(r.monto_devuelto, 0)) AS total_gastado
FROM Usuarios u
JOIN Compras c        ON c.id_usuario = u.id_usuario
JOIN Detalle_Compra d ON d.id_compra = c.id_compra
LEFT JOIN Reembolsos r ON r.id_detalle = d.id_detalle AND r.estado = 'aprobado'
GROUP BY u.id_usuario, u.nombre
ORDER BY total_gastado DESC LIMIT 3;

-- 7. Ventas e ingresos por desarrolladora
SELECT * FROM vista_ventas_desarrolladora ORDER BY ingresos_brutos DESC;

-- 8. Juegos que nunca se vendieron (LEFT JOIN + IS NULL)
SELECT j.id_juego, j.nombre_juego, j.fecha_lanzamiento
FROM Juegos j
LEFT JOIN Detalle_Compra d ON d.id_juego = j.id_juego
WHERE d.id_detalle IS NULL;

-- 9. Facturación por mes del último año (neta de reembolsos aprobados)
SELECT DATE_FORMAT(c.fecha_compra, '%Y-%m') AS mes,
       SUM(r.id_reembolso IS NULL) AS juegos_vendidos,
       SUM(d.precio_pagado - COALESCE(r.monto_devuelto, 0)) AS facturacion
FROM Compras c
JOIN Detalle_Compra d ON d.id_compra = c.id_compra
LEFT JOIN Reembolsos r ON r.id_detalle = d.id_detalle AND r.estado = 'aprobado'
WHERE c.fecha_compra >= CURDATE() - INTERVAL 12 MONTH
GROUP BY mes ORDER BY mes;

-- 10. Ventas por género, netas de reembolsos (un juego cuenta en cada uno de sus géneros)
SELECT g.nombre AS genero,
       SUM(r.id_reembolso IS NULL) AS unidades,
       SUM(d.precio_pagado - COALESCE(r.monto_devuelto, 0)) AS facturacion
FROM Detalle_Compra d
JOIN Juego_Genero jg ON jg.id_juego = d.id_juego
JOIN Generos g       ON g.id_genero = jg.id_genero
LEFT JOIN Reembolsos r ON r.id_detalle = d.id_detalle AND r.estado = 'aprobado'
GROUP BY g.nombre ORDER BY facturacion DESC;

-- 11. Cuánto ganó Steam: 30 % de la tienda + 5 % de cada venta del Mercado
SELECT (SELECT ROUND(SUM(comision_steam), 2) FROM vista_ventas_desarrolladora) AS comision_tienda,
       (SELECT SUM(comision_steam) FROM Publicaciones_Mercado WHERE estado = 'vendida') AS comision_mercado;

-- 12. Ítems más caros vendidos en el Mercado
SELECT item, rareza, nombre_juego, vendedor, comprador, pago_comprador, fecha_venta
FROM vista_ventas_mercado ORDER BY pago_comprador DESC LIMIT 10;

-- 13. Promociones según su situación (dato real vs. planificado)
SELECT nombre, fecha_inicio, fecha_fin, porcentaje_descuento,
       CASE WHEN CURDATE() < fecha_inicio THEN 'Planificada'
            WHEN CURDATE() > fecha_fin    THEN 'Finalizada'
            ELSE 'Activa' END AS situacion
FROM Promociones ORDER BY fecha_inicio;

-- 14. Usuarios que gastaron más que el promedio (subconsulta)
SELECT u.nombre, SUM(d.precio_pagado) AS gastado
FROM Usuarios u
JOIN Compras c        ON c.id_usuario = u.id_usuario
JOIN Detalle_Compra d ON d.id_compra = c.id_compra
GROUP BY u.id_usuario, u.nombre
HAVING gastado > (SELECT AVG(t.total)
                  FROM (SELECT SUM(d2.precio_pagado) AS total
                        FROM Compras c2 JOIN Detalle_Compra d2 ON d2.id_compra = c2.id_compra
                        GROUP BY c2.id_usuario) t)
ORDER BY gastado DESC;

-- 15. Control de la billetera (debe dar 0 filas)
SELECT * FROM vista_billetera WHERE control <> 'OK';
-- =====================================================================
--  STEAM SISTEMA v2  -  09. SEGURIDAD: ROLES Y PRIVILEGIOS (DCL)
--  Requiere un usuario con permiso para crear roles (por ejemplo root).
--  Probado en MySQL 8 (HeidiSQL o Workbench). Ejecutar el archivo completo (F9 en HeidiSQL).
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- =====================================================================
-- ROLES Y PRIVILEGIOS
--     Requiere un usuario con permiso para crear roles (por ejemplo root).
-- =====================================================================
CREATE ROLE IF NOT EXISTS 'steam_admin', 'steam_analista', 'steam_tienda';

GRANT ALL PRIVILEGES ON steam_sistema.* TO 'steam_admin';

-- El analista solo lee vistas: no ve emails ni tablas crudas.
GRANT SELECT ON steam_sistema.vista_juegos_completa       TO 'steam_analista';
GRANT SELECT ON steam_sistema.vista_ventas_desarrolladora TO 'steam_analista';
GRANT SELECT ON steam_sistema.vista_valoracion_juegos     TO 'steam_analista';
GRANT SELECT ON steam_sistema.vista_ventas_mercado        TO 'steam_analista';
GRANT SELECT ON steam_sistema.vista_promos_activas        TO 'steam_analista';

-- La aplicación de la tienda opera solo a través de procedimientos.
GRANT EXECUTE ON PROCEDURE steam_sistema.sp_comprar_juego        TO 'steam_tienda';
GRANT EXECUTE ON PROCEDURE steam_sistema.sp_solicitar_reembolso  TO 'steam_tienda';
GRANT EXECUTE ON PROCEDURE steam_sistema.sp_recargar_billetera   TO 'steam_tienda';
GRANT EXECUTE ON PROCEDURE steam_sistema.sp_publicar_item        TO 'steam_tienda';
GRANT EXECUTE ON PROCEDURE steam_sistema.sp_comprar_item_mercado TO 'steam_tienda';
GRANT SELECT ON steam_sistema.vista_juegos_completa TO 'steam_tienda';

CREATE USER IF NOT EXISTS 'analista_demo'@'localhost' IDENTIFIED BY 'Analista#2026';
GRANT 'steam_analista' TO 'analista_demo'@'localhost';
SET DEFAULT ROLE 'steam_analista' TO 'analista_demo'@'localhost';
