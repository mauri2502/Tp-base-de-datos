-- =====================================================================
--  STEAM SISTEMA v2  -  02. FUNCIONES
--  Calculan el precio con la promoción vigente en una fecha.
--  Probado en MySQL 8 (HeidiSQL o Workbench). Ejecutar el archivo completo (F9 en HeidiSQL).
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- =====================================================================
-- FUNCIONES
-- =====================================================================
DELIMITER //

-- Mayor descuento vigente de un juego en una fecha (0 si no tiene).
DROP FUNCTION IF EXISTS fn_descuento_en_fecha//
CREATE FUNCTION fn_descuento_en_fecha(p_juego INT, p_fecha DATE)
RETURNS DECIMAL(5,2)
READS SQL DATA
BEGIN
  DECLARE v_desc DECIMAL(5,2);
  SELECT COALESCE(MAX(p.porcentaje_descuento), 0) INTO v_desc
  FROM Juego_Promocion jp
  JOIN Promociones p ON p.id_promocion = jp.id_promocion
  WHERE jp.id_juego = p_juego
    AND p_fecha BETWEEN p.fecha_inicio AND p.fecha_fin;
  RETURN v_desc;
END//

-- Promoción que se aplica (la de mayor descuento) o NULL.
DROP FUNCTION IF EXISTS fn_promo_en_fecha//
CREATE FUNCTION fn_promo_en_fecha(p_juego INT, p_fecha DATE)
RETURNS INT
READS SQL DATA
BEGIN
  DECLARE v_promo INT DEFAULT NULL;
  SELECT p.id_promocion INTO v_promo
  FROM Juego_Promocion jp
  JOIN Promociones p ON p.id_promocion = jp.id_promocion
  WHERE jp.id_juego = p_juego
    AND p_fecha BETWEEN p.fecha_inicio AND p.fecha_fin
  ORDER BY p.porcentaje_descuento DESC, p.id_promocion
  LIMIT 1;
  RETURN v_promo;
END//

DROP FUNCTION IF EXISTS fn_precio_en_fecha//
CREATE FUNCTION fn_precio_en_fecha(p_juego INT, p_fecha DATE)
RETURNS DECIMAL(10,2)
READS SQL DATA
BEGIN
  DECLARE v_base DECIMAL(10,2);
  SELECT precio_base INTO v_base FROM Juegos WHERE id_juego = p_juego;
  RETURN ROUND(v_base * (1 - fn_descuento_en_fecha(p_juego, p_fecha) / 100), 2);
END//

DROP FUNCTION IF EXISTS fn_precio_actual//
CREATE FUNCTION fn_precio_actual(p_juego INT)
RETURNS DECIMAL(10,2)
READS SQL DATA
BEGIN
  RETURN fn_precio_en_fecha(p_juego, CURDATE());
END//

DELIMITER ;
