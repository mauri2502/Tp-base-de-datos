-- =====================================================================
--  STEAM SISTEMA v2  -  07. VISTAS
--  Consultas guardadas. Se usan con SELECT * FROM vista_...
--  Probado en MySQL 8 (HeidiSQL o Workbench). Ejecutar el archivo completo (F9 en HeidiSQL).
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- =====================================================================
-- VISTAS
-- =====================================================================

-- Catálogo con precio actual, géneros y estado de lanzamiento.
CREATE OR REPLACE VIEW vista_juegos_completa AS
SELECT j.id_juego,
       j.nombre_juego,
       j.precio_base,
       fn_descuento_en_fecha(j.id_juego, CURDATE()) AS descuento_actual,
       fn_precio_actual(j.id_juego)                 AS precio_actual,
       d.nombre AS desarrolladora,
       d.region,
       (SELECT GROUP_CONCAT(g.nombre ORDER BY g.nombre SEPARATOR ', ')
          FROM Juego_Genero jg JOIN Generos g ON g.id_genero = jg.id_genero
         WHERE jg.id_juego = j.id_juego) AS generos,
       j.fecha_lanzamiento,
       IF(j.fecha_lanzamiento > CURDATE(), 'Próximamente', 'Disponible') AS estado
FROM Juegos j
LEFT JOIN Desarrolladoras d ON d.id_desarrolladora = j.id_desarrolladora;

-- Promociones vigentes hoy (una fila por juego en promoción).
CREATE OR REPLACE VIEW vista_promos_activas AS
SELECT p.id_promocion, p.nombre AS promocion, p.porcentaje_descuento,
       p.fecha_inicio, p.fecha_fin, DATEDIFF(p.fecha_fin, CURDATE()) AS dias_restantes,
       j.id_juego, j.nombre_juego
FROM Promociones p
JOIN Juego_Promocion jp ON p.id_promocion = jp.id_promocion
JOIN Juegos j           ON jp.id_juego = j.id_juego
WHERE CURDATE() BETWEEN p.fecha_inicio AND p.fecha_fin;

-- Precio final de cada juego (corrige la versión anterior, que duplicaba
-- filas cuando un juego estaba en más de una promoción).
CREATE OR REPLACE VIEW vista_juegos_precio_final AS
SELECT j.id_juego, j.nombre_juego, j.precio_base,
       fn_descuento_en_fecha(j.id_juego, CURDATE()) AS porcentaje_descuento,
       fn_precio_actual(j.id_juego)                 AS precio_final
FROM Juegos j;

-- Cada juego comprado, con promo, método de pago y estado de reembolso.
CREATE OR REPLACE VIEW vista_compras_detalles AS
SELECT c.id_compra, d.id_detalle, u.id_usuario, u.nombre AS comprador,
       j.nombre_juego, d.precio_pagado, p.nombre AS promocion,
       m.nombre AS metodo_pago, c.fecha_compra,
       COALESCE(r.estado, 'sin reembolso') AS reembolso
FROM Detalle_Compra d
JOIN Compras c       ON c.id_compra = d.id_compra
JOIN Usuarios u      ON u.id_usuario = c.id_usuario
JOIN Juegos j        ON j.id_juego = d.id_juego
JOIN Metodos_Pago m  ON m.id_metodo_pago = c.id_metodo_pago
LEFT JOIN Promociones p ON p.id_promocion = d.id_promocion
LEFT JOIN Reembolsos r  ON r.id_detalle = d.id_detalle;

-- Total de cada compra (el total se calcula, no se guarda).
CREATE OR REPLACE VIEW vista_compras_totales AS
SELECT c.id_compra, u.nombre AS comprador, c.fecha_compra, m.nombre AS metodo_pago,
       COUNT(*) AS cantidad_juegos, SUM(d.precio_pagado) AS total
FROM Compras c
JOIN Usuarios u       ON u.id_usuario = c.id_usuario
JOIN Metodos_Pago m   ON m.id_metodo_pago = c.id_metodo_pago
JOIN Detalle_Compra d ON d.id_compra = c.id_compra
GROUP BY c.id_compra, u.nombre, c.fecha_compra, m.nombre;

-- Reemplaza a la vieja tabla Ventas: lo que vendió cada desarrolladora.
-- Se descuentan los reembolsos aprobados. Comisión de Steam simplificada al 30 %
-- (en Steam real baja a 25 % y 20 % recién después de USD 10 M y 50 M por juego).
CREATE OR REPLACE VIEW vista_ventas_desarrolladora AS
SELECT COALESCE(dv.nombre, 'Sin desarrolladora') AS desarrolladora,
       COUNT(*)                                    AS unidades_vendidas,
       SUM(d.precio_pagado)                        AS ingresos_brutos,
       ROUND(SUM(d.precio_pagado) * 0.30, 2)       AS comision_steam,
       ROUND(SUM(d.precio_pagado) * 0.70, 2)       AS neto_desarrolladora
FROM Detalle_Compra d
JOIN Juegos j ON j.id_juego = d.id_juego
LEFT JOIN Desarrolladoras dv ON dv.id_desarrolladora = j.id_desarrolladora
LEFT JOIN Reembolsos r ON r.id_detalle = d.id_detalle AND r.estado = 'aprobado'
WHERE r.id_reembolso IS NULL
GROUP BY COALESCE(dv.nombre, 'Sin desarrolladora');

CREATE OR REPLACE VIEW vista_biblioteca AS
SELECT u.id_usuario, u.nombre AS usuario, j.nombre_juego,
       b.fecha_adquisicion, b.horas_jugadas, b.origen
FROM Biblioteca b
JOIN Usuarios u ON u.id_usuario = b.id_usuario
JOIN Juegos j   ON j.id_juego = b.id_juego;

CREATE OR REPLACE VIEW vista_reembolsos_detalle AS
SELECT r.id_reembolso, u.nombre AS usuario, j.nombre_juego,
       c.fecha_compra, r.fecha_solicitud,
       DATEDIFF(r.fecha_solicitud, c.fecha_compra) AS dias_desde_compra,
       d.precio_pagado, r.monto_devuelto, r.estado, r.destino, r.motivo
FROM Reembolsos r
JOIN Detalle_Compra d ON d.id_detalle = r.id_detalle
JOIN Compras c        ON c.id_compra = d.id_compra
JOIN Usuarios u       ON u.id_usuario = c.id_usuario
JOIN Juegos j         ON j.id_juego = d.id_juego;

-- Billetera: el saldo guardado (desnormalizado) contra la suma de movimientos.
-- La columna "control" debe dar siempre 'OK'.
CREATE OR REPLACE VIEW vista_billetera AS
SELECT u.id_usuario, u.nombre, u.saldo_billetera,
       COALESCE(SUM(CASE WHEN m.tipo = 'recarga'        THEN m.monto END), 0) AS recargado,
       COALESCE(SUM(CASE WHEN m.tipo = 'compra_tienda'  THEN m.monto END), 0) AS gastado_tienda,
       COALESCE(SUM(CASE WHEN m.tipo = 'compra_mercado' THEN m.monto END), 0) AS gastado_mercado,
       COALESCE(SUM(CASE WHEN m.tipo = 'venta_mercado'  THEN m.monto END), 0) AS ganado_mercado,
       COALESCE(SUM(CASE WHEN m.tipo = 'reembolso'      THEN m.monto END), 0) AS reembolsado,
       IF(u.saldo_billetera = COALESCE(SUM(m.monto), 0), 'OK', 'DESCUADRE') AS control
FROM Usuarios u
LEFT JOIN Movimientos_Billetera m ON m.id_usuario = u.id_usuario
GROUP BY u.id_usuario, u.nombre, u.saldo_billetera;

CREATE OR REPLACE VIEW vista_mercado_activo AS
SELECT pm.id_publicacion, it.nombre AS item, it.tipo, it.rareza, j.nombre_juego,
       u.nombre AS vendedor, pm.precio_vendedor, pm.comision_steam, pm.comision_juego,
       pm.precio_comprador, pm.fecha_publicacion
FROM Publicaciones_Mercado pm
JOIN Inventario inv ON inv.id_inventario = pm.id_inventario
JOIN Items it       ON it.id_item = inv.id_item
JOIN Juegos j       ON j.id_juego = it.id_juego
JOIN Usuarios u     ON u.id_usuario = pm.id_vendedor
WHERE pm.estado = 'activa';

CREATE OR REPLACE VIEW vista_ventas_mercado AS
SELECT pm.id_publicacion, it.nombre AS item, it.rareza, j.nombre_juego,
       v.nombre AS vendedor, c.nombre AS comprador,
       pm.precio_comprador AS pago_comprador, pm.precio_vendedor AS recibe_vendedor,
       pm.comision_steam, pm.comision_juego, pm.fecha_venta
FROM Publicaciones_Mercado pm
JOIN Inventario inv ON inv.id_inventario = pm.id_inventario
JOIN Items it       ON it.id_item = inv.id_item
JOIN Juegos j       ON j.id_juego = it.id_juego
JOIN Usuarios v     ON v.id_usuario = pm.id_vendedor
JOIN Usuarios c     ON c.id_usuario = pm.id_comprador
WHERE pm.estado = 'vendida';

-- Valoración estilo Steam (versión simplificada de sus etiquetas).
CREATE OR REPLACE VIEW vista_valoracion_juegos AS
SELECT j.id_juego, j.nombre_juego,
       COUNT(r.id_resena) AS total_resenas,
       ROUND(100 * AVG(r.recomendado), 1) AS porcentaje_positivas,
       CASE
         WHEN COUNT(r.id_resena) < 10              THEN 'Pocas reseñas'
         WHEN AVG(r.recomendado) >= 0.95 AND COUNT(r.id_resena) >= 500 THEN 'Extremadamente positivas'
         WHEN AVG(r.recomendado) >= 0.80 AND COUNT(r.id_resena) >= 50  THEN 'Muy positivas'
         WHEN AVG(r.recomendado) >= 0.80           THEN 'Positivas'
         WHEN AVG(r.recomendado) >= 0.70           THEN 'Mayormente positivas'
         WHEN AVG(r.recomendado) >= 0.40           THEN 'Variadas'
         WHEN AVG(r.recomendado) >= 0.20           THEN 'Mayormente negativas'
         ELSE 'Negativas'
       END AS valoracion
FROM Juegos j
LEFT JOIN Resenas r ON r.id_juego = j.id_juego
GROUP BY j.id_juego, j.nombre_juego;

-- Lo que Steam le "avisaría" a cada usuario: juegos de su lista en oferta.
CREATE OR REPLACE VIEW vista_deseados_en_oferta AS
SELECT u.id_usuario, u.nombre AS usuario, j.nombre_juego,
       j.precio_base, fn_precio_actual(j.id_juego) AS precio_oferta,
       fn_descuento_en_fecha(j.id_juego, CURDATE()) AS descuento
FROM Lista_Deseados ld
JOIN Usuarios u ON u.id_usuario = ld.id_usuario
JOIN Juegos j   ON j.id_juego = ld.id_juego
WHERE fn_descuento_en_fecha(j.id_juego, CURDATE()) > 0;
