-- =====================================================================
--  STEAM SISTEMA v2  -  09. SEGURIDAD: ROLES Y PRIVILEGIOS (DCL)
--  Requiere un usuario con permiso para crear roles (por ejemplo root).
--  Probado en MySQL 8 (HeidiSQL o Workbench). Ejecutar el archivo completo (F9 en HeidiSQL).
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- =====================================================================
-- ROLES Y PRIVILEGIOS
--     Requiere un usuario con permiso para crear roles (por ejemplo root).
-- =====================================================================
CREATE ROLE IF NOT EXISTS 'steam_admin', 'steam_analista', 'steam_tienda';

GRANT ALL PRIVILEGES ON steam_sistema.* TO 'steam_admin';

-- El analista solo lee vistas: no ve emails ni tablas crudas.
GRANT SELECT ON steam_sistema.vista_juegos_completa       TO 'steam_analista';
GRANT SELECT ON steam_sistema.vista_ventas_desarrolladora TO 'steam_analista';
GRANT SELECT ON steam_sistema.vista_valoracion_juegos     TO 'steam_analista';
GRANT SELECT ON steam_sistema.vista_ventas_mercado        TO 'steam_analista';
GRANT SELECT ON steam_sistema.vista_promos_activas        TO 'steam_analista';

-- La aplicación de la tienda opera solo a través de procedimientos.
GRANT EXECUTE ON PROCEDURE steam_sistema.sp_comprar_juego        TO 'steam_tienda';
GRANT EXECUTE ON PROCEDURE steam_sistema.sp_solicitar_reembolso  TO 'steam_tienda';
GRANT EXECUTE ON PROCEDURE steam_sistema.sp_recargar_billetera   TO 'steam_tienda';
GRANT EXECUTE ON PROCEDURE steam_sistema.sp_publicar_item        TO 'steam_tienda';
GRANT EXECUTE ON PROCEDURE steam_sistema.sp_comprar_item_mercado TO 'steam_tienda';
GRANT SELECT ON steam_sistema.vista_juegos_completa TO 'steam_tienda';

CREATE USER IF NOT EXISTS 'analista_demo'@'localhost' IDENTIFIED BY 'Analista#2026';
GRANT 'steam_analista' TO 'analista_demo'@'localhost';
SET DEFAULT ROLE 'steam_analista' TO 'analista_demo'@'localhost';
