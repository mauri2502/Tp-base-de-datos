-- =====================================================================
--  STEAM SISTEMA v2  -  06. CARGA MASIVA
--  Usuarios y compras generados al azar con un procedimiento. Se puede repetir.
--  Probado en MySQL 8 (HeidiSQL o Workbench). Ejecutar el archivo completo (F9 en HeidiSQL).
-- =====================================================================
SET NAMES utf8mb4;
USE steam_sistema;

-- =====================================================================
-- CARGA MASIVA
--    Agrega usuarios y compras al azar sobre los datos legibles.
--    Para más volumen: CALL sp_generar_datos_masivos(2000, 20000);
-- =====================================================================
CALL sp_generar_datos_masivos(300, 2500);

-- Resultado
SELECT (SELECT COUNT(*) FROM Usuarios) AS usuarios, (SELECT COUNT(*) FROM Compras) AS compras,
       (SELECT COUNT(*) FROM Detalle_Compra) AS juegos_vendidos, (SELECT COUNT(*) FROM Resenas) AS resenas;
